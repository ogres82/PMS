create view v_rep_room_charge_info as
select `a`.`room_id`          AS `room_id`,
       `a`.`amount`           AS `amount`,
       `a`.`charge_date`      AS `charge_date`,
       `b`.`charge_type_no`   AS `charge_type_no`,
       `b`.`charge_type_name` AS `charge_type_name`,
       `b`.`charge_price`     AS `charge_price`
from (`pms_product`.`t_charge_type_room_rela` `a`
         join `pms_product`.`t_charge_type_setting` `b`)
where ((`a`.`charge_type_id` = `b`.`charge_type_id`) and (`a`.`charge_type_no` = `b`.`charge_type_no`));

-- comment on column v_rep_room_charge_info.amount not supported: 余额

-- comment on column v_rep_room_charge_info.charge_date not supported: 收费开始时间

