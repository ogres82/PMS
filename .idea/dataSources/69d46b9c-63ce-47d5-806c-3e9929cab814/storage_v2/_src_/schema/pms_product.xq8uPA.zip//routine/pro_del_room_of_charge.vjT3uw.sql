create
    definer = pms_admin@`%` procedure pro_del_room_of_charge(IN in_room_id varchar(50), IN in_charge_id varchar(50),
                                                             IN in_oper_id varchar(50))
BEGIN 

	DECLARE v_paid_amout DECIMAL(10.2) DEFAULT 0.00;
	DECLARE v_paid_mode DECIMAL(10.2) DEFAULT 0.00;

	-- 如sql异常,将errno设置为1且后续执行退出
	DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; END; -- COMMIT;-- 出错处理	

	#手动提交事务
  SET autocommit=0;	
	-- 开启事务
	START TRANSACTION;
	
	if exists( select 1 from t_charge_info where room_id = in_room_id and charge_id = in_charge_id ) then
		begin
			select paid_amout,paid_mode into v_paid_amout,v_paid_mode from t_charge_info where room_id = in_room_id and charge_id = in_charge_id;
			
		end;
	else
		begin
			select 2222;
		end;
  end if;
	
	select v_paid_amout,v_paid_mode;
  -- 关闭游标
	COMMIT;
END;

