create definer = pms_admin@`%` trigger serialNoCreate_copy2
    before insert
    on t_charge_serial_info_190806
    for each row
begin
if new.charge_type = '01' then
	set @v_str = 'SF';
elseif  new.charge_type = '02' then
	set @v_str = 'YJ';
elseif  new.charge_type = '03' then
	set @v_str = 'YS';
          if new.state = '01' then
              UPDATE t_charge_type_room_rela r set r.amount=r.amount+new.paid_amount where r.room_id=new.room_id and r.charge_type_no=new.charge_type_no;
         elseif new.state = '02' then
               set @v_str = 'YS';
         else
              set @v_str = 'YS';
         end if;
else 
              set @v_str = 'SF';
end if;

set new.serial_no=CONCAT(@v_str,DATE_FORMAT(now(),'%Y%m%d'),LPAD(seq_nextval('serial_seq'),6,'0'));
end;

