create view v_r_t_assign_visit as
select `t`.`rpt_kid`                                                                                         AS `rpt_kid`,
       `t`.`rpt_id`                                                                                          AS `rpt_id`,
       `t`.`rpt_name`                                                                                        AS `rpt_name`,
       `t`.`in_call`                                                                                         AS `in_call`,
       `t`.`address`                                                                                         AS `addres`,
       `t`.`event_type`                                                                                      AS `event_type`,
       `t`.`event_source`                                                                                    AS `event_source`,
       (select `di`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `di`
        where ((`di`.`code_detail` = `t`.`event_type`) and
               (`di`.`code` = 'main_event_type')))                                                           AS `event_type_name`,
       (select `di`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `di`
        where ((`di`.`code_detail` = `t`.`event_source`) and
               (`di`.`code` = 'main_event_source')))                                                         AS `event_source_name`,
       `d`.`dispatch_status`                                                                                 AS `dispatch_status`,
       `d`.`dispatch_handle_id`                                                                              AS `dispatch_handle_id`,
       `d`.`dispatch_id`                                                                                     AS `dispatch_id`,
       `t`.`createby`                                                                                        AS `createby`,
       `b`.`CNAME_`                                                                                          AS `createby_name`,
       (select `di`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `di`
        where ((`di`.`code_detail` = `d`.`dispatch_status`) and
               (`di`.`code` = 'main_mtn_dispatch_status')))                                                  AS `dispatch_status_name`,
       date_format(`t`.`createTime`, '%Y-%m-%d %H:%i:%S')                                                    AS `createTime`,
       `d`.`dispatch_result`                                                                                 AS `dispatch_result`
from ((`pms_product`.`t_r_maintain` `t` join `pms_product`.`t_r_maintain_dispatch` `d`)
         join `pms_product`.`bdf2_user` `b`)
where ((`t`.`rpt_id` = `d`.`mtn_id`) and (`d`.`dispatch_status` >= 3) and (`t`.`createby` = `b`.`USERNAME_`))
union
select `t`.`rpt_kid`                                                                                     AS `rpt_kid`,
       `t`.`rpt_id`                                                                                      AS `rpt_id`,
       `t`.`rpt_name`                                                                                    AS `rpt_name`,
       `t`.`in_call`                                                                                     AS `in_call`,
       `t`.`address`                                                                                     AS `addres`,
       `t`.`event_type`                                                                                  AS `event_type`,
       `t`.`event_source`                                                                                AS `event_source`,
       (select `di`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `di`
        where ((`di`.`code_detail` = `t`.`event_type`) and
               (`di`.`code` = 'main_event_type')))                                                       AS `event_type_name`,
       (select `di`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `di`
        where ((`di`.`code_detail` = `t`.`event_source`) and
               (`di`.`code` = 'main_event_source')))                                                     AS `event_source_name`,
       `c`.`comp_status`                                                                                 AS `comp_status`,
       `c`.`comp_operator_id`                                                                            AS `comp_operator_id`,
       `c`.`comp_id`                                                                                     AS `comp_id`,
       `t`.`createby`                                                                                    AS `createby`,
       `e`.`CNAME_`                                                                                      AS `createby_name`,
       (select `di`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `di`
        where ((`di`.`code_detail` = `c`.`comp_status`) and
               (`di`.`code` = 'main_mtn_dispatch_status')))                                              AS `dispatch_status_name`,
       date_format(`t`.`createTime`, '%Y-%m-%d %H:%i:%S')                                                AS `createTime`,
       ''                                                                                                AS `dispatch_result`
from ((`pms_product`.`t_r_maintain` `t` join `pms_product`.`t_r_maintain_complaint` `c`)
         join `pms_product`.`bdf2_user` `e`)
where ((`t`.`rpt_id` = `c`.`mtn_id`) and (`c`.`comp_status` >= 3) and (`t`.`createby` = `e`.`USERNAME_`));

