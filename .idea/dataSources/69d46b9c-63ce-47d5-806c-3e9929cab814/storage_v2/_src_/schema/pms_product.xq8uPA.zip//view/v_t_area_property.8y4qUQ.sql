create view v_t_area_property as
select `b`.`build_name`      AS `build_name`,
       `a`.`community_id`    AS `community_id`,
       `a`.`community_name`  AS `community_name`,
       `a`.`belong_build_id` AS `belong_build_id`,
       `a`.`remark`          AS `remark`,
       `a`.`lz_id`           AS `lz_id`,
       `b`.`lz_id`           AS `lz_build_id`
from (`pms_product`.`t_area_property` `a`
         left join `pms_product`.`t_all_area` `b` on ((`a`.`belong_build_id` = `b`.`build_id`)));

-- comment on column v_t_area_property.build_name not supported: 楼盘名称  例：乐湾国际城一期

-- comment on column v_t_area_property.community_id not supported: 小区ID

-- comment on column v_t_area_property.community_name not supported: 小区名称 例：西湖御景、依山云墅

-- comment on column v_t_area_property.belong_build_id not supported: 所属楼盘ID

-- comment on column v_t_area_property.remark not supported: 备注

