create view v_user as
select `a`.`USERNAME_`                                                                                    AS `USERNAME_`,
       `a`.`CNAME_`                                                                                       AS `CNAME_`,
       `b`.`DEPT_ID_`                                                                                     AS `DEPT_ID_`,
       (select `e`.`NAME_`
        from `pms_product`.`bdf2_dept` `e`
        where (`e`.`ID_` = `b`.`DEPT_ID_`))                                                               AS `DEPT_NAME`,
       `c`.`POSITION_ID_`                                                                                 AS `POSITION_ID_`,
       (select `f`.`NAME_` from `pms_product`.`bdf2_position` `f` where (`f`.`ID_` = `c`.`POSITION_ID_`)) AS `POSITION`,
       `d`.`work_state`                                                                                   AS `work_state`,
       `d`.`work_times`                                                                                   AS `work_times`,
       `a`.`MOBILE_`                                                                                      AS `MOBILE`
from (((`pms_product`.`bdf2_user` `a` left join `pms_product`.`bdf2_user_dept` `b` on ((`a`.`USERNAME_` = `b`.`USERNAME_`))) left join `pms_product`.`bdf2_user_position` `c` on ((`a`.`USERNAME_` = `c`.`USERNAME_`)))
         left join `pms_product`.`t_r_maintain_workerstate` `d` on ((`a`.`USERNAME_` = `d`.`user_name`)));

