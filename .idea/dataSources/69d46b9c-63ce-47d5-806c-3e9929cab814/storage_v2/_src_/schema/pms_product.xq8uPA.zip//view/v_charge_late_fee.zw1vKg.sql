create view v_charge_late_fee as
select round(((`a`.`receive_amount` * 0.003) * timestampdiff(DAY, `a`.`end_time`, (curdate() - 1))),
             2)                                                                                         AS `arrearage_amount`,
       `a`.`end_time`                                                                                   AS `begin_time`,
       (curdate() - 1)                                                                                  AS `end_time`,
       '物业费滞纳金'                                                                                         AS `charge_type_name`,
       ''                                                                                               AS `charge_type_no`,
       `a`.`count`                                                                                      AS `count`,
       `a`.`delete_id`                                                                                  AS `delete_id`,
       '系统操作'                                                                                           AS `oper_emp_id`,
       `a`.`owner_id`                                                                                   AS `owner_id`,
       `a`.`owner_name`                                                                                 AS `owner_name`,
       0                                                                                                AS `paid_amount`,
       `a`.`price`                                                                                      AS `price`,
       `a`.`rate`                                                                                       AS `rate`,
       round(((`a`.`receive_amount` * 0.003) * timestampdiff(DAY, `a`.`end_time`, (curdate() - 1))),
             2)                                                                                         AS `receive_amount`,
       `a`.`remark`                                                                                     AS `remark`,
       `a`.`room_id`                                                                                    AS `room_id`,
       `a`.`room_no`                                                                                    AS `room_no`,
       now()                                                                                            AS `update_date`,
       '03'                                                                                             AS `state`,
       '01'                                                                                             AS `data_from`,
       `a`.`room_type`                                                                                  AS `room_type`,
       `a`.`community_name`                                                                             AS `community_name`,
       `a`.`storied_build_name`                                                                         AS `storied_build_name`
from (`pms_product`.`t_charge_info` `a`
         join `pms_product`.`t_charge_type_setting` `b`)
where ((`a`.`charge_type_no` = `b`.`charge_type_no`) and (`a`.`state` = '03') and (`a`.`end_time` < (curdate() - 1)) and
       (`b`.`type_flag` = '01') and (`a`.`is_del` = '0'));

