create
    definer = pms_admin@`%` function fun_event2ChageInfo(rpt_id varchar(50)) returns varchar(25)
BEGIN
   DECLARE	v_value	VARCHAR(50);
   DECLARE	v_value1	VARCHAR(50);
   select DISTINCT(t.state) into v_value from t_charge_info t where t.work_id=rpt_id and t.state='03';
 
	 
    RETURN v_value ;
	
END;

