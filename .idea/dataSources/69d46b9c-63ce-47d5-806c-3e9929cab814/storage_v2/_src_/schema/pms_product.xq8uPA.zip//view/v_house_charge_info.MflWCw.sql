create view v_house_charge_info as
select `a`.`build_id`                                                                             AS `build_id`,
       `a`.`build_name`                                                                           AS `build_name`,
       `a`.`community_id`                                                                         AS `community_id`,
       `a`.`community_name`                                                                       AS `community_name`,
       `a`.`belong_sb_id`                                                                         AS `belong_sb_id`,
       `a`.`storied_build_name`                                                                   AS `storied_build_name`,
       `a`.`room_id`                                                                              AS `room_id`,
       `a`.`room_no`                                                                              AS `room_no`,
       `a`.`within_area`                                                                          AS `within_area`,
       `a`.`build_area`                                                                           AS `build_area`,
       `a`.`room_type`                                                                            AS `room_type`,
       `a`.`room_state`                                                                           AS `room_state`,
       `a`.`make_room_date`                                                                       AS `make_room_date`,
       `a`.`decorate_start_date`                                                                  AS `decorate_start_date`,
       `a`.`decorate_plan_date`                                                                   AS `decorate_plan_date`,
       `a`.`decorate_end_date`                                                                    AS `decorate_end_date`,
       `a`.`owner_id`                                                                             AS `owner_id`,
       `a`.`charge_date`                                                                          AS `charge_date`,
       `a`.`charge_state`                                                                         AS `charge_state`,
       `a`.`charge_type_id`                                                                       AS `charge_type_id`,
       `a`.`charge_type_no`                                                                       AS `charge_type_no`,
       `a`.`charge_price`                                                                         AS `charge_price`,
       `a`.`type_flag`                                                                            AS `type_flag`,
       `a`.`total_price`                                                                          AS `total_price`,
       `a`.`day_price`                                                                            AS `day_price`,
       `a`.`total_paid_amount`                                                                    AS `total_paid_amount`,
       (`a`.`total_paid_amount` DIV `a`.`total_price`)                                            AS `months_num`,
       round(((`a`.`total_paid_amount` % `a`.`total_price`) / `a`.`day_price`), 0)                AS `day_num`,
       ((`a`.`charge_date` + interval (`a`.`total_paid_amount` DIV `a`.`total_price`) month) +
        interval round(((`a`.`total_paid_amount` % `a`.`total_price`) / `a`.`day_price`), 0) day) AS `exp_date`
from `pms_product`.`v_house_base_charge` `a`;

-- comment on column v_house_charge_info.build_id not supported: 楼盘ID

-- comment on column v_house_charge_info.build_name not supported: 楼盘名称

-- comment on column v_house_charge_info.community_id not supported: 小区ID

-- comment on column v_house_charge_info.community_name not supported: 小区名称

-- comment on column v_house_charge_info.belong_sb_id not supported: 所属楼栋ID

-- comment on column v_house_charge_info.storied_build_name not supported: 楼栋名称

-- comment on column v_house_charge_info.room_id not supported: 房间ID

-- comment on column v_house_charge_info.room_no not supported: 房间号

-- comment on column v_house_charge_info.within_area not supported: 套内面积

-- comment on column v_house_charge_info.build_area not supported: 建筑面积

-- comment on column v_house_charge_info.room_type not supported: 房间类型 0高层1洋房2别墅

-- comment on column v_house_charge_info.room_state not supported: 房间状态 0未售1交房2接房3入住4出租

-- comment on column v_house_charge_info.make_room_date not supported: 收房日期（地产通知收房的日期）

-- comment on column v_house_charge_info.decorate_start_date not supported: 装修开始日期

-- comment on column v_house_charge_info.decorate_plan_date not supported: 装修拟结束时间

-- comment on column v_house_charge_info.decorate_end_date not supported: 装修结束时间

-- comment on column v_house_charge_info.charge_date not supported: 收费开始时间

-- comment on column v_house_charge_info.charge_state not supported: 是否开始出账（1：开始出账；0：不出账）

-- comment on column v_house_charge_info.type_flag not supported: 收费项目类型的标志，（默认为00，表示未分类。比如物管费，有多种物管费，统一标志为01。其他类似，值为02，03……）

