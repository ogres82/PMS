create
    definer = pms_admin@`%` procedure pro_change_room_charge_state()
BEGIN 
	-- 
	DECLARE v_room_id,v_owner_id VARCHAR(55);
	DECLARE v_charge_state VARCHAR(55);
	DECLARE v_charge_date Date;
	
	-- 遍历数据结束标志
  DECLARE done INT DEFAULT FALSE;
  -- 游标 应收记录中查询还没有收款的
  DECLARE cur CURSOR FOR  select room_id,owner_id,charge_date,charge_state
	from t_charge_type_room_rela 
	where charge_date < CURRENT_DATE
	and is_del = '0'  -- 逻辑删除状态，未删除
	and charge_state = '0' ; -- 还未出账

	-- 将结束标志绑定到游标
  DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' BEGIN SET done = TRUE; END;
	
	-- 如sql异常,将errno设置为1且后续执行退出
	DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; END; -- COMMIT;-- 出错处理	

	#手动提交事务
  SET autocommit=0;	
	-- 开启事务
	START TRANSACTION;
  -- 打开游标
  OPEN cur;
  -- 开始循环
  read_loop: LOOP
    -- 提取游标里的数据
    FETCH cur INTO v_room_id, v_owner_id, v_charge_date,v_charge_state;
    -- 声明结束的时候
    IF done THEN	
      LEAVE read_loop;
    END IF;
    update t_charge_type_room_rela 
		set charge_state = '1'
		where charge_state = v_charge_state
		and room_id = v_room_id
		and owner_id = v_owner_id;
		
		call pro_createChargeInfo_manual(v_charge_date,CURRENT_DATE,v_room_id,'admin');		
  END LOOP read_loop;

  -- 关闭游标
	COMMIT;
  CLOSE cur;
END;

