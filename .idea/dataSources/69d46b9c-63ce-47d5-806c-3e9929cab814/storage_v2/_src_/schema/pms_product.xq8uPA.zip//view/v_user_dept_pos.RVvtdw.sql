create view v_user_dept_pos as
select `a`.`USERNAME_`                                         AS `USERNAME_`,
       `a`.`CNAME_`                                            AS `CNAME_`,
       group_concat(distinct `a`.`DEPT_ID_` separator ',')     AS `DEPT_ID`,
       group_concat(distinct `a`.`DEPT_NAME` separator ',')    AS `DEPT_NAME`,
       group_concat(distinct `a`.`POSITION_ID_` separator ',') AS `POSITION_ID`,
       group_concat(distinct `a`.`POSITION` separator ',')     AS `POSITION`,
       `a`.`work_state`                                        AS `work_state`,
       `a`.`work_times`                                        AS `work_times`,
       `a`.`MOBILE`                                            AS `MOBILE`
from `pms_product`.`v_user` `a`
group by `a`.`USERNAME_`;

