create view v_report_charge as
select `a`.`charge_id`          AS `charge_id`,
       `a`.`arrearage_amount`   AS `arrearage_amount`,
       `a`.`begin_time`         AS `begin_time`,
       `a`.`charge_no`          AS `charge_no`,
       `a`.`charge_type_name`   AS `charge_type_name`,
       `a`.`charge_type_no`     AS `charge_type_no`,
       `a`.`count`              AS `count`,
       `a`.`delete_id`          AS `delete_id`,
       `a`.`end_time`           AS `end_time`,
       `a`.`oper_emp_id`        AS `oper_emp_id`,
       `a`.`owner_id`           AS `owner_id`,
       `a`.`owner_name`         AS `owner_name`,
       `a`.`paid_amount`        AS `paid_amount`,
       `a`.`paid_date`          AS `paid_date`,
       `a`.`paid_mode`          AS `paid_mode`,
       `a`.`price`              AS `price`,
       `a`.`rate`               AS `rate`,
       `a`.`receive_amount`     AS `receive_amount`,
       `a`.`remark`             AS `remark`,
       `a`.`room_id`            AS `room_id`,
       `a`.`room_no`            AS `room_no`,
       `a`.`update_date`        AS `update_date`,
       `a`.`state`              AS `state`,
       `a`.`data_from`          AS `data_from`,
       `a`.`work_id`            AS `work_id`,
       `b`.`community_id`       AS `community_id`,
       `b`.`community_name`     AS `community_name`,
       `b`.`storied_build_id`   AS `storied_build_id`,
       `b`.`storied_build_name` AS `storied_build_name`
from (`pms_product`.`t_charge_info` `a`
         left join `pms_product`.`v_area_build_house_owner_rela` `b` on ((`a`.`room_id` = `b`.`room_id`)))
where (`a`.`charge_type_name` <> '物业费滞纳金');

-- comment on column v_report_charge.state not supported: 01:未收 02已收， 03欠费

-- comment on column v_report_charge.data_from not supported: 01:系统自动，02手动

-- comment on column v_report_charge.community_id not supported: 小区ID

-- comment on column v_report_charge.community_name not supported: 小区名称 例：西湖御景、依山云墅

-- comment on column v_report_charge.storied_build_id not supported: 楼栋ID

-- comment on column v_report_charge.storied_build_name not supported: 楼栋名称 例：独栋、001栋

