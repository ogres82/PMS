create definer = pms_admin@`%` event chargeInfoCreate on schedule
    every '1' MONTH
        starts '2019-07-31 01:00:00'
    on completion preserve
    enable
    do
    CALL pro_createChargeInfo(date_add(curdate()-day(curdate())+1,interval 1 month),last_day(date_add(curdate()-day(curdate())+1,interval 1 month)) );

