create view v_charge_build_area as
select `h`.`room_id`                           AS `room_id`,
       `h`.`community_name`                    AS `community_name`,
       `h`.`storied_build_name`                AS `storied_build_name`,
       `h`.`room_type`                         AS `room_type`,
       `h`.`room_no`                           AS `room_no`,
       (`h`.`build_area` * `t`.`charge_price`) AS `total_price`,
       `h`.`build_area`                        AS `build_area`,
       `h`.`make_room_date`                    AS `make_room_date`,
       `h`.`room_state`                        AS `room_state`,
       `t`.`charge_price`                      AS `charge_price`,
       `t`.`charge_type`                       AS `charge_type`,
       `t`.`charge_type_no`                    AS `charge_type_no`,
       `t`.`charge_type_name`                  AS `charge_type_name`,
       `r`.`amount`                            AS `amount`,
       `r`.`type_flag`                         AS `type_flag`,
       `r`.`charge_state`                      AS `charge_state`,
       `r`.`charge_date`                       AS `charge_date`
from ((`pms_product`.`t_charge_type_room_rela` `r` join `pms_product`.`t_charge_type_setting` `t`)
         join `pms_product`.`t_house_property` `h`)
where ((`r`.`charge_type_no` = `t`.`charge_type_no`) and (`r`.`room_id` = `h`.`room_id`) and
       (`t`.`charge_mode` = '01') and (`r`.`is_del` = '0'));

-- comment on column v_charge_build_area.room_id not supported: 房间ID

-- comment on column v_charge_build_area.community_name not supported: 小区名称

-- comment on column v_charge_build_area.storied_build_name not supported: 楼栋名称

-- comment on column v_charge_build_area.room_type not supported: 房间类型 0高层1洋房2别墅

-- comment on column v_charge_build_area.room_no not supported: 房间号

-- comment on column v_charge_build_area.build_area not supported: 建筑面积

-- comment on column v_charge_build_area.make_room_date not supported: 收房日期（地产通知收房的日期）

-- comment on column v_charge_build_area.room_state not supported: 房间状态 0未售1交房2接房3入住4出租

-- comment on column v_charge_build_area.amount not supported: 余额

-- comment on column v_charge_build_area.type_flag not supported: 收费项目类型的标志（参考表t_charge_type_setting中type_flag字段，默认为00，表示未分类。比如物管费，有多种物管费，统一标志为01。其他类似，值为02，03……）

-- comment on column v_charge_build_area.charge_state not supported: 是否开始出账（1：开始出账；0：不出账）

-- comment on column v_charge_build_area.charge_date not supported: 收费开始时间

