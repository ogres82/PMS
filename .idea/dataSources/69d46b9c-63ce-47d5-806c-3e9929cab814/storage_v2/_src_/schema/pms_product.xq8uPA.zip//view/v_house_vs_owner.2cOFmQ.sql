create view v_house_vs_owner as
select `i`.`lz_id`                                                                                 AS `lz_id`,
       `a`.`build_id`                                                                              AS `build_id`,
       `a`.`build_name`                                                                            AS `build_name`,
       `a`.`community_id`                                                                          AS `community_id`,
       `a`.`community_name`                                                                        AS `community_name`,
       `a`.`belong_sb_id`                                                                          AS `storied_build_id`,
       `a`.`storied_build_name`                                                                    AS `storied_build_name`,
       `a`.`unit_id`                                                                               AS `unit_id`,
       `a`.`unit_name`                                                                             AS `unit_name`,
       `a`.`room_id`                                                                               AS `room_id`,
       `a`.`room_no`                                                                               AS `room_no`,
       `a`.`belong_sb_id`                                                                          AS `belong_sb_id`,
       `a`.`house_type`                                                                            AS `house_type`,
       `a`.`build_area`                                                                            AS `build_area`,
       `a`.`within_area`                                                                           AS `within_area`,
       `a`.`room_type`                                                                             AS `room_type`,
       `a`.`room_state`                                                                            AS `room_state`,
       `a`.`charge_object`                                                                         AS `charge_object`,
       `a`.`remark`                                                                                AS `remark`,
       `a`.`advance_amount`                                                                        AS `advance_amount`,
       `a`.`make_room_date`                                                                        AS `make_room_date`,
       `a`.`decorate_start_date`                                                                   AS `decorate_start_date`,
       `a`.`decorate_end_date`                                                                     AS `decorate_end_date`,
       `a`.`receive_room_date`                                                                     AS `receive_room_date`,
       `a`.`decorate_plan_date`                                                                    AS `decorate_plan_date`,
       `b`.`owner_id`                                                                              AS `owner_id`,
       `b`.`owner_name`                                                                            AS `owner_name`,
       `b`.`phone`                                                                                 AS `phone`,
       `b`.`tel_phone`                                                                             AS `tel_phone`,
       `b`.`card_id`                                                                               AS `card_id`,
       `b`.`birth_date`                                                                            AS `birth_date`,
       `b`.`car_id`                                                                                AS `car_id`,
       `b`.`remark`                                                                                AS `owner_remark`,
       (select `c`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `c`
        where ((`c`.`code` = 'room_type') and (`c`.`code_detail` = `a`.`room_type`)))              AS `room_type_name`,
       (select `d`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `d`
        where ((`d`.`code` = 'room_state') and (`d`.`code_detail` = `a`.`room_state`)))            AS `room_state_name`,
       (select `e`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `e`
        where ((`e`.`code` = 'room_charge_object') and
               (`e`.`code_detail` = `a`.`charge_object`)))                                         AS `charge_object_name`,
       (select `f`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `f`
        where ((`f`.`code` = 'owner_type') and (`f`.`code_detail` = `b`.`owner_type`)))            AS `owner_type_name`,
       (select `w`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `w`
        where ((`w`.`code` = 'owner_identity') and
               (`w`.`code_detail` = `b`.`owner_identity`)))                                        AS `owner_identity_name`,
       `q`.`charge_date`                                                                           AS `charge_date`
from (((`pms_product`.`t_house_property` `a` left join `pms_product`.`t_house_owner` `i` on (((`i`.`room_id` = `a`.`room_id`) and (`i`.`banding_mark` = '0')))) left join `pms_product`.`t_property_owner` `b` on (((`i`.`owner_id` = `b`.`owner_id`) and (`b`.`owner_identity` = '0'))))
         left join `pms_product`.`t_charge_type_room_rela` `q` on ((`a`.`room_id` = `q`.`room_id`)))
where (`a`.`is_del` = '0')
group by `a`.`room_id`
order by `a`.`community_name`, `a`.`storied_build_name`, `a`.`room_no`;

-- comment on column v_house_vs_owner.lz_id not supported: 联掌门户的ID

-- comment on column v_house_vs_owner.build_id not supported: 楼盘ID

-- comment on column v_house_vs_owner.build_name not supported: 楼盘名称

-- comment on column v_house_vs_owner.community_id not supported: 小区ID

-- comment on column v_house_vs_owner.community_name not supported: 小区名称

-- comment on column v_house_vs_owner.storied_build_id not supported: 所属楼栋ID

-- comment on column v_house_vs_owner.storied_build_name not supported: 楼栋名称

-- comment on column v_house_vs_owner.unit_id not supported: 单元ID

-- comment on column v_house_vs_owner.unit_name not supported: 单元名称

-- comment on column v_house_vs_owner.room_id not supported: 房间ID

-- comment on column v_house_vs_owner.room_no not supported: 房间号

-- comment on column v_house_vs_owner.belong_sb_id not supported: 所属楼栋ID

-- comment on column v_house_vs_owner.house_type not supported: 户型  例：A户型、B户型

-- comment on column v_house_vs_owner.build_area not supported: 建筑面积

-- comment on column v_house_vs_owner.within_area not supported: 套内面积

-- comment on column v_house_vs_owner.room_type not supported: 房间类型 0高层1洋房2别墅

-- comment on column v_house_vs_owner.room_state not supported: 房间状态 0未售1交房2接房3入住4出租

-- comment on column v_house_vs_owner.charge_object not supported: 收费对象 0业主1租户2其他

-- comment on column v_house_vs_owner.remark not supported: 备注

-- comment on column v_house_vs_owner.make_room_date not supported: 收房日期（地产通知收房的日期）

-- comment on column v_house_vs_owner.decorate_start_date not supported: 装修开始日期

-- comment on column v_house_vs_owner.decorate_end_date not supported: 装修结束时间

-- comment on column v_house_vs_owner.receive_room_date not supported: 业主实际收房日期

-- comment on column v_house_vs_owner.decorate_plan_date not supported: 装修拟结束时间

-- comment on column v_house_vs_owner.owner_id not supported: 业主ID

-- comment on column v_house_vs_owner.owner_name not supported: 业主姓名

-- comment on column v_house_vs_owner.phone not supported: 手机号

-- comment on column v_house_vs_owner.tel_phone not supported: 联系电话

-- comment on column v_house_vs_owner.card_id not supported: 身份证号

-- comment on column v_house_vs_owner.birth_date not supported: 出生日期

-- comment on column v_house_vs_owner.car_id not supported: 车辆ID

-- comment on column v_house_vs_owner.owner_remark not supported: 备注

-- comment on column v_house_vs_owner.charge_date not supported: 收费开始时间

