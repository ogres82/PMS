create view v_system_app_auth as
select `a`.`role_id`  AS `role_id`,
       `a`.`url_id`   AS `url_id`,
       `b`.`url_name` AS `url_name`,
       `b`.`order_no` AS `order_no`,
       `b`.`name`     AS `name`
from (`pms_product`.`system_app_roleurl` `a`
         left join `pms_product`.`system_app_url` `b` on ((`a`.`url_id` = `b`.`url_id`)));

