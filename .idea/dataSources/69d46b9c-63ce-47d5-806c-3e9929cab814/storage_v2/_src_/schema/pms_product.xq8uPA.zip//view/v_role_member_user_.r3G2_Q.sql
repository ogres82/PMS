create view v_role_member_user_ as
select `a`.`ID_` AS `role_id`, `a`.`NAME_` AS `role_name`, `b`.`USERNAME_` AS `user_name`, `b`.`ID_` AS `user_id`
from (`pms_product`.`bdf2_role` `a`
         join `pms_product`.`bdf2_role_member` `b`)
where (`a`.`ID_` = `b`.`ROLE_ID_`);

