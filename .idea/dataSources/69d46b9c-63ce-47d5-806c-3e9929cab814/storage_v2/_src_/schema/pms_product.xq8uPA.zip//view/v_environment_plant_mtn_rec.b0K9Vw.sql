create view v_environment_plant_mtn_rec as
select `a`.`rec_id`                                                                                              AS `rec_id`,
       `a`.`area_id`                                                                                             AS `area_id`,
       `a`.`plant_mtn_detail`                                                                                    AS `plant_mtn_detail`,
       `a`.`plant_mtn_person`                                                                                    AS `plant_mtn_person`,
       `a`.`plant_mtn_date`                                                                                      AS `plant_mtn_date`,
       `a`.`remark`                                                                                              AS `remark`,
       `b`.`area_name`                                                                                           AS `area_name`,
       (select `t`.`CNAME_`
        from `pms_product`.`bdf2_user` `t`
        where (`t`.`USERNAME_` = `a`.`plant_mtn_person`))                                                        AS `plant_mtn_person_name`
from (`pms_product`.`t_environment_plant_mtn_rec` `a`
         left join `pms_product`.`t_environment_area` `b` on ((`b`.`area_id` = `a`.`area_id`)));

-- comment on column v_environment_plant_mtn_rec.rec_id not supported: 记录ID

-- comment on column v_environment_plant_mtn_rec.area_id not supported: 区域ID

-- comment on column v_environment_plant_mtn_rec.plant_mtn_detail not supported: 养护内容

-- comment on column v_environment_plant_mtn_rec.plant_mtn_person not supported: 养护人ID

-- comment on column v_environment_plant_mtn_rec.plant_mtn_date not supported: 养护日期

-- comment on column v_environment_plant_mtn_rec.remark not supported: 备注

-- comment on column v_environment_plant_mtn_rec.area_name not supported: 区域名称

