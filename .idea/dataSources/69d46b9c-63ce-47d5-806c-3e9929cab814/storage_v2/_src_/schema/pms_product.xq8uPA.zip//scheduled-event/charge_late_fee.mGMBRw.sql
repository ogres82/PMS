create definer = pms_admin@`%` event charge_late_fee on schedule
    every '1' DAY
        starts '2019-07-17 05:00:00'
    on completion preserve
    enable
    do
    call pro_charge_late_fee();

