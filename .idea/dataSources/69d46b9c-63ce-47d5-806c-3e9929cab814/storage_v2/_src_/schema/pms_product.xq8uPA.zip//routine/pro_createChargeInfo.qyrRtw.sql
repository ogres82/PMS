create
    definer = pms_admin@`%` procedure pro_createChargeInfo(IN begin_date date, IN end_date date)
BEGIN
	#Routine body goes here...
	declare exit handler for sqlexception rollback; 
	#手动提交事务
  SET autocommit=0;
	start transaction;
	
	INSERT INTO t_charge_info(charge_id,room_id,room_no,owner_id,owner_name, charge_type_no,charge_type_name,
				 	receive_amount,paid_amount,arrearage_amount,oper_emp_id,update_date, begin_time, end_time, price, count,room_type,community_name,storied_build_name)
		SELECT UUID(),
		a.room_id, a.room_no, o.owner_id, o.owner_name, a.charge_type_no, a.charge_type_name,
		a.total_price, 0, 0, 'admin', SYSDATE(), 
		DATE_FORMAT(begin_date,'%Y-%m-%d'), DATE_FORMAT(end_date,'%Y-%m-%d'),a.charge_price, a.build_area,a.room_type,a.community_name,a.storied_build_name
		FROM v_charge_build_area a, t_house_owner r, t_property_owner o where a.room_id=r.room_id AND r.owner_id=o.owner_id AND o.owner_identity=0 AND a.charge_state = '1' and r.is_del='0' and o.is_del = '0';

	INSERT INTO T_OVERALL_LOG(user_id,log_date,logger,log_level,message) VALUES('admin',now(),'数据库后台','INFO',CONCAT('周期性账单生成-- id:',''));
	commit;
END;

