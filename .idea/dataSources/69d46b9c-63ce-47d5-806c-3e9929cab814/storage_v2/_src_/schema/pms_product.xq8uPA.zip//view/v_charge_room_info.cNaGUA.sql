create view v_charge_room_info as
select `b`.`room_id`                                                                        AS `room_id`,
       `a`.`owner_id`                                                                       AS `owner_id`,
       `b`.`community_name`                                                                 AS `community_name`,
       `b`.`storied_build_name`                                                             AS `storied_build_name`,
       `b`.`room_no`                                                                        AS `room_no`,
       (select `pms_product`.`dir_directorydetail`.`code_detail_name`
        from `pms_product`.`dir_directorydetail`
        where ((`pms_product`.`dir_directorydetail`.`code` = 'room_state') and
               (`pms_product`.`dir_directorydetail`.`code_detail` = `b`.`room_state`)))     AS `room_state`,
       (select `pms_product`.`t_property_owner`.`owner_name`
        from `pms_product`.`t_property_owner`
        where (`a`.`owner_id` = `pms_product`.`t_property_owner`.`owner_id`))               AS `owner_name`,
       (select `pms_product`.`t_property_owner`.`phone`
        from `pms_product`.`t_property_owner`
        where (`a`.`owner_id` = `pms_product`.`t_property_owner`.`owner_id`))               AS `owner_phone`,
       `a`.`charge_date`                                                                    AS `make_room_date`,
       (case `b`.`room_type`
            when '2' then concat(`b`.`community_name`, `b`.`room_no`)
            else concat(`b`.`community_name`, `b`.`storied_build_name`, `b`.`room_no`) end) AS `room_addr`,
       `b`.`room_type`                                                                      AS `room_type`,
       `b`.`build_area`                                                                     AS `build_area`,
       `c`.`charge_price`                                                                   AS `charge_price`,
       (`c`.`charge_price` * `b`.`build_area`)                                              AS `room_charge_price`,
       `a`.`amount`                                                                         AS `amount`,
       ifnull((select sum(`v_charge_info`.`arrearage_amount`)
               from `pms_product`.`v_charge_info`
               where ((`a`.`room_id` = `v_charge_info`.`room_id`) and (`v_charge_info`.`state` = '03') and
                      `v_charge_info`.`charge_type_no` in (select `pms_product`.`t_charge_type_setting`.`charge_type_no`
                                                           from `pms_product`.`t_charge_type_setting`
                                                           where (`pms_product`.`t_charge_type_setting`.`type_flag` = '01')))
               group by `v_charge_info`.`room_id`), 0)                                      AS `arrearage_amount`,
       ifnull((select count(1)
               from `pms_product`.`v_charge_info`
               where ((`a`.`room_id` = `v_charge_info`.`room_id`) and (`v_charge_info`.`state` = '03') and
                      `v_charge_info`.`charge_type_no` in (select `pms_product`.`t_charge_type_setting`.`charge_type_no`
                                                           from `pms_product`.`t_charge_type_setting`
                                                           where (`pms_product`.`t_charge_type_setting`.`type_flag` = '01')))
               group by `v_charge_info`.`room_id`), 0)                                      AS `arrearage_num`,
       cast(ifnull((select (sum(`t`.`paidAmount`) * 100)
                    from `pms_product`.`v_owner_room_property_fee_rec` `t`
                    where (`a`.`room_id` = `t`.`roomId`)), 0) as signed)                    AS `serial_amount`
from ((`pms_product`.`t_charge_type_room_rela` `a` join `pms_product`.`t_house_property` `b`)
         join `pms_product`.`t_charge_type_setting` `c`)
where ((`a`.`room_id` = `b`.`room_id`) and (`a`.`charge_type_no` = `c`.`charge_type_no`) and
       (`c`.`charge_type_name` <> '物业费滞纳金') and (`a`.`is_del` = '0'));

-- comment on column v_charge_room_info.room_id not supported: 房间ID

-- comment on column v_charge_room_info.community_name not supported: 小区名称

-- comment on column v_charge_room_info.storied_build_name not supported: 楼栋名称

-- comment on column v_charge_room_info.room_no not supported: 房间号

-- comment on column v_charge_room_info.make_room_date not supported: 收费开始时间

-- comment on column v_charge_room_info.room_type not supported: 房间类型 0高层1洋房2别墅

-- comment on column v_charge_room_info.build_area not supported: 建筑面积

-- comment on column v_charge_room_info.amount not supported: 余额

