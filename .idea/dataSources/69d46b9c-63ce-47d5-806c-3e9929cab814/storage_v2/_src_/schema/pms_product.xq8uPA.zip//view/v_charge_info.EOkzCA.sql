create view v_charge_info as
select `a`.`build_id`                                         AS `build_id`,
       `a`.`build_name`                                       AS `build_name`,
       `a`.`community_id`                                     AS `community_id`,
       `a`.`belong_sb_id`                                     AS `storied_build_id`,
       `t`.`charge_id`                                        AS `charge_id`,
       `t`.`arrearage_amount`                                 AS `arrearage_amount`,
       `t`.`begin_time`                                       AS `begin_time`,
       `t`.`charge_no`                                        AS `charge_no`,
       `t`.`charge_type_name`                                 AS `charge_type_name`,
       `t`.`charge_type_no`                                   AS `charge_type_no`,
       `t`.`count`                                            AS `count`,
       `t`.`delete_id`                                        AS `delete_id`,
       `t`.`end_time`                                         AS `end_time`,
       `t`.`oper_emp_id`                                      AS `oper_emp_id`,
       `t`.`owner_id`                                         AS `owner_id`,
       `t`.`owner_name`                                       AS `owner_name`,
       `t`.`paid_amount`                                      AS `paid_amount`,
       `t`.`paid_date`                                        AS `paid_date`,
       `t`.`paid_mode`                                        AS `paid_mode`,
       `t`.`price`                                            AS `price`,
       `t`.`rate`                                             AS `rate`,
       `t`.`receive_amount`                                   AS `receive_amount`,
       `t`.`remark`                                           AS `remark`,
       `t`.`room_id`                                          AS `room_id`,
       `a`.`community_name`                                   AS `community_name`,
       `a`.`storied_build_name`                               AS `storied_build_name`,
       `a`.`unit_name`                                        AS `unit_name`,
       `a`.`room_type`                                        AS `room_type`,
       `t`.`room_no`                                          AS `room_no`,
       `t`.`update_date`                                      AS `update_date`,
       `t`.`state`                                            AS `state`,
       `getDropdownName`('charge_paid_mode', `t`.`paid_mode`) AS `drop_paid_mode`,
       `getDropdownName`('charge_data_from', `t`.`data_from`) AS `drop_data_from`,
       `t`.`data_from`                                        AS `data_from`,
       `t`.`work_id`                                          AS `work_id`
from (`pms_product`.`t_charge_info` `t`
         left join `pms_product`.`t_house_property` `a` on ((`a`.`room_id` = `t`.`room_id`)))
where (`t`.`is_del` = '0');

-- comment on column v_charge_info.build_id not supported: 楼盘ID

-- comment on column v_charge_info.build_name not supported: 楼盘名称

-- comment on column v_charge_info.community_id not supported: 小区ID

-- comment on column v_charge_info.storied_build_id not supported: 所属楼栋ID

-- comment on column v_charge_info.community_name not supported: 小区名称

-- comment on column v_charge_info.storied_build_name not supported: 楼栋名称

-- comment on column v_charge_info.unit_name not supported: 单元名称

-- comment on column v_charge_info.room_type not supported: 房间类型 0高层1洋房2别墅

-- comment on column v_charge_info.state not supported: 01:未收 02已收， 03欠费

-- comment on column v_charge_info.data_from not supported: 01:系统自动，02手动

