create
    definer = pms_admin@`%` function getAreaName(v_room_id varchar(50)) returns varchar(50)
BEGIN
	DECLARE	v_value	VARCHAR(50);

	SELECT a.community_name INTO v_value FROM t_house_property h, t_building_property b, t_area_property a 
	WHERE a.community_id=b.belong_comm_id AND b.storied_build_id=h.belong_sb_id AND h.room_id=v_room_id;
	RETURN v_value;
END;

