create view v_house_ztree as
select `pms_product`.`t_all_area`.`build_id`   AS `node_id`,
       ''                                      AS `p_id`,
       `pms_product`.`t_all_area`.`build_name` AS `node_name`,
       '0'                                     AS `node_level`,
       '1'                                     AS `is_open`,
       `pms_product`.`t_all_area`.`lz_id`      AS `lz_id`
from `pms_product`.`t_all_area`
union all
select `pms_product`.`t_area_property`.`community_id`    AS `id`,
       `pms_product`.`t_area_property`.`belong_build_id` AS `belong_build_id`,
       `pms_product`.`t_area_property`.`community_name`  AS `community_name`,
       '1'                                               AS `node_level`,
       '0'                                               AS `is_open`,
       `pms_product`.`t_area_property`.`lz_id`           AS `lz_id`
from `pms_product`.`t_area_property`
where (`pms_product`.`t_area_property`.`is_del` = '0')
union all
select `pms_product`.`t_building_property`.`storied_build_id`   AS `storied_build_id`,
       `pms_product`.`t_building_property`.`belong_comm_id`     AS `belong_comm_id`,
       `pms_product`.`t_building_property`.`storied_build_name` AS `storied_build_name`,
       '2'                                                      AS `node_level`,
       '0'                                                      AS `is_open`,
       `pms_product`.`t_building_property`.`lz_id`              AS `lz_id`
from `pms_product`.`t_building_property`
where (`pms_product`.`t_building_property`.`is_del` = '0')
union all
select `pms_product`.`t_building_unit`.`unit_id`      AS `unit_id`,
       `pms_product`.`t_building_unit`.`belong_sb_id` AS `belong_sb_id`,
       `pms_product`.`t_building_unit`.`unit_name`    AS `unit_name`,
       '3'                                            AS `node_level`,
       '0'                                            AS `is_open`,
       `pms_product`.`t_building_unit`.`lz_id`        AS `lz_id`
from `pms_product`.`t_building_unit`
where (`pms_product`.`t_building_unit`.`is_del` = '0')
union all
select `pms_product`.`t_house_property`.`room_id` AS `room_id`,
       `pms_product`.`t_house_property`.`unit_id` AS `unit_id`,
       `pms_product`.`t_house_property`.`room_no` AS `room_no`,
       '4'                                        AS `node_level`,
       '0'                                        AS `is_open`,
       `pms_product`.`t_house_property`.`lz_id`   AS `lz_id`
from `pms_product`.`t_house_property`
where (`pms_product`.`t_house_property`.`is_del` = '0');

