create definer = pms_admin@`%` event charge_serial_seq_reset on schedule
    every '1' DAY
        starts '2019-07-14 00:00:00'
    on completion preserve
    enable
    do
    BEGIN
SELECT seq_setval('charge_seq',0);
SELECT seq_setval('serial_seq',0);
END;

