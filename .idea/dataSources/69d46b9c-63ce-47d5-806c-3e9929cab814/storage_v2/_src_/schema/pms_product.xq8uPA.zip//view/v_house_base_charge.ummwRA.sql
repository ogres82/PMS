create view v_house_base_charge as
select `a`.`build_id`                                                   AS `build_id`,
       `a`.`build_name`                                                 AS `build_name`,
       `a`.`community_id`                                               AS `community_id`,
       `a`.`community_name`                                             AS `community_name`,
       `a`.`belong_sb_id`                                               AS `belong_sb_id`,
       `a`.`storied_build_name`                                         AS `storied_build_name`,
       `a`.`room_id`                                                    AS `room_id`,
       `a`.`room_no`                                                    AS `room_no`,
       `a`.`within_area`                                                AS `within_area`,
       `a`.`build_area`                                                 AS `build_area`,
       `a`.`room_type`                                                  AS `room_type`,
       `a`.`room_state`                                                 AS `room_state`,
       `a`.`make_room_date`                                             AS `make_room_date`,
       `a`.`decorate_start_date`                                        AS `decorate_start_date`,
       `a`.`decorate_plan_date`                                         AS `decorate_plan_date`,
       `a`.`decorate_end_date`                                          AS `decorate_end_date`,
       `b`.`owner_id`                                                   AS `owner_id`,
       `b`.`charge_date`                                                AS `charge_date`,
       `b`.`charge_state`                                               AS `charge_state`,
       `b`.`charge_type_id`                                             AS `charge_type_id`,
       `b`.`charge_type_no`                                             AS `charge_type_no`,
       `c`.`charge_price`                                               AS `charge_price`,
       `c`.`type_flag`                                                  AS `type_flag`,
       cast((case
                 when (`c`.`type_flag` = '01') then (`a`.`build_area` * `c`.`charge_price`)
                 else `c`.`charge_price` end) as decimal(10, 2))        AS `total_price`,
       cast(((case
                  when (`c`.`type_flag` = '01') then (`a`.`build_area` * `c`.`charge_price`)
                  else `c`.`charge_price` end) / 30) as decimal(10, 2)) AS `day_price`,
       `d`.`total_paid_amount`                                          AS `total_paid_amount`
from (((`pms_product`.`t_house_property` `a` left join `pms_product`.`t_charge_type_room_rela` `b` on ((
        (`a`.`room_id` = `b`.`room_id`) and (`b`.`is_del` = '0') and
        (`b`.`charge_state` = '1')))) left join `pms_product`.`t_charge_type_setting` `c` on ((
        (`b`.`charge_type_id` = `c`.`charge_type_id`) and (`b`.`charge_type_no` = `c`.`charge_type_no`))))
         left join (select sum(`v_owner_room_property_fee_rec`.`paidAmount`) AS `total_paid_amount`,
                           `v_owner_room_property_fee_rec`.`roomId`          AS `room_id`
                    from `pms_product`.`v_owner_room_property_fee_rec`
                    group by `v_owner_room_property_fee_rec`.`roomId`) `d` on ((`a`.`room_id` = `d`.`room_id`)))
where (`a`.`is_del` = '0');

-- comment on column v_house_base_charge.build_id not supported: 楼盘ID

-- comment on column v_house_base_charge.build_name not supported: 楼盘名称

-- comment on column v_house_base_charge.community_id not supported: 小区ID

-- comment on column v_house_base_charge.community_name not supported: 小区名称

-- comment on column v_house_base_charge.belong_sb_id not supported: 所属楼栋ID

-- comment on column v_house_base_charge.storied_build_name not supported: 楼栋名称

-- comment on column v_house_base_charge.room_id not supported: 房间ID

-- comment on column v_house_base_charge.room_no not supported: 房间号

-- comment on column v_house_base_charge.within_area not supported: 套内面积

-- comment on column v_house_base_charge.build_area not supported: 建筑面积

-- comment on column v_house_base_charge.room_type not supported: 房间类型 0高层1洋房2别墅

-- comment on column v_house_base_charge.room_state not supported: 房间状态 0未售1交房2接房3入住4出租

-- comment on column v_house_base_charge.make_room_date not supported: 收房日期（地产通知收房的日期）

-- comment on column v_house_base_charge.decorate_start_date not supported: 装修开始日期

-- comment on column v_house_base_charge.decorate_plan_date not supported: 装修拟结束时间

-- comment on column v_house_base_charge.decorate_end_date not supported: 装修结束时间

-- comment on column v_house_base_charge.charge_date not supported: 收费开始时间

-- comment on column v_house_base_charge.charge_state not supported: 是否开始出账（1：开始出账；0：不出账）

-- comment on column v_house_base_charge.type_flag not supported: 收费项目类型的标志，（默认为00，表示未分类。比如物管费，有多种物管费，统一标志为01。其他类似，值为02，03……）

