create view v_event_satisfa as
select (case
            when (isnull(`di`.`dispatch_visit_lev`) or (`di`.`dispatch_visit_lev` = 0)) then '非常满意'
            when (`di`.`dispatch_visit_lev` = 1) then '基本满意'
            else '不满意' end) AS `visit_lev`
from `pms_product`.`t_r_maintain_dispatch` `di`
where (`di`.`dispatch_status` = 5)
union all
select (case
            when (isnull(`mc`.`comp_visit_lev`) or (`mc`.`comp_visit_lev` = 0)) then '非常满意'
            when (`mc`.`comp_visit_lev` = 1) then '基本满意'
            else '不满意' end) AS `visit_lev`
from `pms_product`.`t_r_maintain_complaint` `mc`
where (`mc`.`comp_status` = 5)
union all
select (case
            when (isnull(`v`.`visit_evaluate`) or (`v`.`visit_evaluate` = 0)) then '非常满意'
            when (`v`.`visit_evaluate` = 1) then '基本满意'
            else '不满意' end) AS `visit_lev`
from (`pms_product`.`t_housework_event` `t`
         join `pms_product`.`t_housework_visit` `v`)
where ((`t`.`id` = `v`.`event_id`) and (`t`.`event_state` = 5));

