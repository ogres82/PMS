create view v_report_comp as
select `c`.`community_id`         AS `community_id`,
       `c`.`community_name`       AS `community_name`,
       `c`.`storied_build_id`     AS `storied_build_id`,
       `c`.`storied_build_name`   AS `storied_build_name`,
       `c`.`room_id`              AS `room_id`,
       `c`.`room_no`              AS `room_no`,
       `d`.`code_detail_name`     AS `code_detail_name`,
       `b`.`event_type`           AS `event_type`,
       `b`.`createTime`           AS `rpt_time`,
       `a`.`comp_kid`             AS `comp_kid`,
       `a`.`comp_createTime`      AS `comp_createTime`,
       `a`.`comp_createby`        AS `comp_createby`,
       `a`.`comp_degree`          AS `comp_degree`,
       `a`.`comp_detail`          AS `comp_detail`,
       `a`.`comp_emergency`       AS `comp_emergency`,
       `a`.`comp_finish_time`     AS `comp_finish_time`,
       `a`.`comp_id`              AS `comp_id`,
       `a`.`comp_operator`        AS `comp_operator`,
       `a`.`comp_operator_id`     AS `comp_operator_id`,
       `a`.`comp_process`         AS `comp_process`,
       `a`.`comp_result`          AS `comp_result`,
       `a`.`comp_solve`           AS `comp_solve`,
       `a`.`comp_status`          AS `comp_status`,
       `a`.`comp_visit_lev`       AS `comp_visit_lev`,
       `a`.`comp_visit_record`    AS `comp_visit_record`,
       `a`.`comp_visit_recording` AS `comp_visit_recording`,
       `a`.`finish_time`          AS `finish_time`,
       `a`.`mtn_id`               AS `mtn_id`,
       `a`.`comp_reply`           AS `comp_reply`,
       `a`.`comp_image`           AS `comp_image`
from (((`pms_product`.`t_r_maintain_complaint` `a` left join `pms_product`.`t_r_maintain` `b` on ((`a`.`mtn_id` = `b`.`rpt_id`))) left join `pms_product`.`v_area_build_house_owner_rela` `c` on ((`b`.`owner_house` = `c`.`room_id`)))
         left join `pms_product`.`dir_directorydetail` `d` on ((`d`.`code_detail` = `b`.`event_type`)))
where (`d`.`code` = 'main_event_type');

-- comment on column v_report_comp.community_id not supported: 小区ID

-- comment on column v_report_comp.community_name not supported: 小区名称 例：西湖御景、依山云墅

-- comment on column v_report_comp.storied_build_id not supported: 楼栋ID

-- comment on column v_report_comp.storied_build_name not supported: 楼栋名称 例：独栋、001栋

-- comment on column v_report_comp.room_id not supported: 房间ID

-- comment on column v_report_comp.room_no not supported: 房间号

-- comment on column v_report_comp.comp_image not supported: 存储图片信息路径

