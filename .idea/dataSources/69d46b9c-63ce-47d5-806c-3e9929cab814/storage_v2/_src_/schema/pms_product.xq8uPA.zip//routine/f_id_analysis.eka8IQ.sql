create
    definer = pms_admin@`%` function f_id_analysis(in_id_no varchar(18), in_type varchar(5)) returns varchar(20)
BEGIN 
    DECLARE v_return VARCHAR(20);
    SET v_return = substring(in_id_no , 7 , 8);

    IF(in_type = 'MON') THEN SET v_return = substring(v_return , 5 , 2);
    END IF;

    IF(in_type = 'AGE') THEN SET v_return =year(from_days( datediff(CURDATE(), CAST(v_return AS DATE))) );
    END IF;

    IF(in_type = 'SEX') THEN SET v_return = IF( SUBSTRING(in_id_no , 17 , 1) % 2 = 1 , "1" , "0");
    END IF;

    RETURN v_return;
END;

