create view v_area_plant as
select `t`.`area_id`         AS `area_id`,
       `t`.`area_name`       AS `area_name`,
       `t`.`area_res_person` AS `area_res_person`,
       `t`.`area_gis_id`     AS `area_gis_id`,
       `t`.`area_gis_area`   AS `area_gis_area`,
       `t`.`remark`          AS `remark`,
       `s`.`emp_name`        AS `area_res_person_name`
from (`pms_product`.`t_environment_area` `t`
         left join `pms_product`.`t_emp` `s` on ((`s`.`emp_id` = `t`.`area_res_person`)));

-- comment on column v_area_plant.area_id not supported: 区域ID

-- comment on column v_area_plant.area_name not supported: 区域名称

-- comment on column v_area_plant.area_res_person not supported: 负责人ID

-- comment on column v_area_plant.area_gis_id not supported: 地图区域id

-- comment on column v_area_plant.area_gis_area not supported: 地图区域面积

-- comment on column v_area_plant.remark not supported: 备注

-- comment on column v_area_plant.area_res_person_name not supported: 姓名

