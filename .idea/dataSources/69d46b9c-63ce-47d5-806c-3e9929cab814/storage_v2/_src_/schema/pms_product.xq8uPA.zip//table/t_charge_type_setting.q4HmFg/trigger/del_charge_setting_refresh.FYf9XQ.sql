create definer = pms_admin@`%` trigger del_charge_setting_refresh
    after delete
    on t_charge_type_setting
    for each row
begin
call pro_refresh_house_vs_fee();
end;

