create view v_order_iteminfo as
select `th`.`instock_id`                        AS `instock_id`,
       `th`.`suppliy_code`                      AS `suppliy_code`,
       `th`.`voucher_id`                        AS `voucher_id`,
       `th`.`suppliy_name`                      AS `suppliy_name`,
       `th`.`unit_price`                        AS `unit_price`,
       `th`.`instock_time`                      AS `instock_time`,
       `th`.`suppliy_num`                       AS `suppliy_num`,
       `th`.`item_code`                         AS `item_code`,
       `th`.`item_name`                         AS `item_name`,
       (`th`.`suppliy_num` * `th`.`unit_price`) AS `sum_price`,
       `th`.`item_type`                         AS `item_type`,
       `th`.`oper_id`                           AS `oper_id`,
       `th`.`item_id`                           AS `item_id`,
       `th`.`instok_type`                       AS `instok_type`,
       `t`.`code_detail_name`                   AS `code_detail_name`
from (`pms_product`.`t_instock_his` `th`
         left join `pms_product`.`dir_directorydetail` `t`
                   on (((`th`.`item_type` = `t`.`code_detail`) and (`t`.`code` like '%item_type%'))));

