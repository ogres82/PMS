create definer = pms_admin@`%` trigger up_house_owner_refresh
    after update
    on t_house_owner
    for each row
begin
call pro_refresh_owner_vs_room_id();
end;

