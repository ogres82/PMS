create definer = pms_admin@`%` trigger ins_owner_refresh
    after insert
    on t_property_owner
    for each row
begin
call pro_refresh_owner_vs_room_id();
end;

