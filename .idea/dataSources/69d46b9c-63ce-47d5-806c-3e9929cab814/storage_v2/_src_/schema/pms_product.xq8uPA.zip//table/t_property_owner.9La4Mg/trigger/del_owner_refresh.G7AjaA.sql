create definer = pms_admin@`%` trigger del_owner_refresh
    after delete
    on t_property_owner
    for each row
begin
call pro_refresh_owner_vs_room_id();
end;

