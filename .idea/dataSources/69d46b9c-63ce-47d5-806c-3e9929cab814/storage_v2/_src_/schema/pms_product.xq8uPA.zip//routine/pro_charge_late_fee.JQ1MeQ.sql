create
    definer = pms_admin@`%` procedure pro_charge_late_fee()
BEGIN
	#Routine body goes here... 
	DECLARE t_error INTEGER DEFAULT 0;    
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1; 
	START TRANSACTION;
	delete from t_charge_info where `state` = '03' and charge_type_name ='物业费滞纳金';

    INSERT into t_charge_info(	charge_id,arrearage_amount,begin_time,end_time,charge_type_name,charge_type_no,	count,delete_id,oper_emp_id,owner_id,owner_name,paid_amount,price,rate,receive_amount,remark,
		room_id,room_no,update_date,state,data_from,room_type,community_name,storied_build_name)
  select UUID(),np.arrearage_amount,np.begin_time,np.end_time,np.charge_type_name,np.charge_type_no,	np.count,
		np.delete_id,np.oper_emp_id,np.owner_id,np.owner_name,np.paid_amount,np.price,np.rate,np.receive_amount,
		np.remark,np.room_id,np.room_no,np.update_date,np.state,np.data_from,np.room_type,np.community_name,np.storied_build_name
	from v_charge_late_fee np where arrearage_amount>=1;

	IF t_error = 1 THEN    
						ROLLBACK;    
				ELSE    
						COMMIT;    
				END IF;
select t_error; 
END;

