create view v_environment_cleaning_check_rec as
select `a`.`rec_id`                                                                             AS `rec_id`,
       `a`.`plan_id`                                                                            AS `plan_id`,
       `a`.`cleaning_check_date`                                                                AS `cleaning_check_date`,
       `a`.`cleaning_check_detail`                                                              AS `cleaning_check_detail`,
       `a`.`cleaning_check_res`                                                                 AS `cleaning_check_res`,
       `a`.`cleaning_checker_id`                                                                AS `cleaning_checker_id`,
       `a`.`remark`                                                                             AS `remark`,
       `b`.`plan_code`                                                                          AS `plan_code`,
       `c`.`emp_name`                                                                           AS `emp_name`,
       (select `pms_product`.`dir_directorydetail`.`code_detail_name`
        from `pms_product`.`dir_directorydetail`
        where ((`pms_product`.`dir_directorydetail`.`code` = 'cleaning_check_res') and
               (`pms_product`.`dir_directorydetail`.`code_detail` =
                `a`.`cleaning_check_res`)))                                                     AS `cleaning_check_res_name`
from ((`pms_product`.`t_environment_cleaning_check_rec` `a` left join `pms_product`.`t_environment_cleaning_area_duty` `b` on ((`b`.`plan_id` = `a`.`plan_id`)))
         left join `pms_product`.`t_emp` `c` on ((`c`.`emp_id` = `a`.`cleaning_checker_id`)));

-- comment on column v_environment_cleaning_check_rec.rec_id not supported: 检查记录ID

-- comment on column v_environment_cleaning_check_rec.plan_id not supported: 计划ID

-- comment on column v_environment_cleaning_check_rec.cleaning_check_date not supported: 检查日期

-- comment on column v_environment_cleaning_check_rec.cleaning_check_detail not supported: 检查内容

-- comment on column v_environment_cleaning_check_rec.cleaning_check_res not supported: 检查结果

-- comment on column v_environment_cleaning_check_rec.cleaning_checker_id not supported: 检查人ID

-- comment on column v_environment_cleaning_check_rec.remark not supported: 备注

-- comment on column v_environment_cleaning_check_rec.plan_code not supported: 计划编码

-- comment on column v_environment_cleaning_check_rec.emp_name not supported: 姓名

