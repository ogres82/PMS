create view v_area_build_house_allowner_rela as
select `a`.`community_id`       AS `community_id`,
       `a`.`community_name`     AS `community_name`,
       `b`.`storied_build_id`   AS `storied_build_id`,
       `b`.`storied_build_name` AS `storied_build_name`,
       `h`.`room_id`            AS `room_id`,
       `h`.`room_no`            AS `room_no`,
       `h`.`room_state`         AS `room_state`,
       `h`.`room_type`          AS `room_type`,
       `o`.`owner_id`           AS `owner_id`,
       `o`.`owner_name`         AS `owner_name`,
       `o`.`phone`              AS `phone`,
       `k`.`default_mark`       AS `default_mark`
from ((((`pms_product`.`t_house_property` `h` join `pms_product`.`t_building_property` `b`) join `pms_product`.`t_area_property` `a`) join `pms_product`.`t_property_owner` `o`)
         join `pms_product`.`t_house_owner` `k`)
where ((`a`.`community_id` = `b`.`belong_comm_id`) and (`b`.`storied_build_id` = `h`.`belong_sb_id`) and
       (`h`.`room_id` = `k`.`room_id`) and (`o`.`owner_id` = `k`.`owner_id`) and (`k`.`default_mark` = '1'));

-- comment on column v_area_build_house_allowner_rela.community_id not supported: 小区ID

-- comment on column v_area_build_house_allowner_rela.community_name not supported: 小区名称 例：西湖御景、依山云墅

-- comment on column v_area_build_house_allowner_rela.storied_build_id not supported: 楼栋ID

-- comment on column v_area_build_house_allowner_rela.storied_build_name not supported: 楼栋名称 例：独栋、001栋

-- comment on column v_area_build_house_allowner_rela.room_id not supported: 房间ID

-- comment on column v_area_build_house_allowner_rela.room_no not supported: 房间号

-- comment on column v_area_build_house_allowner_rela.room_state not supported: 房间状态 0未售1交房2接房3入住4出租

-- comment on column v_area_build_house_allowner_rela.room_type not supported: 房间类型 0高层1洋房2别墅

-- comment on column v_area_build_house_allowner_rela.owner_id not supported: 业主ID

-- comment on column v_area_build_house_allowner_rela.owner_name not supported: 业主姓名

-- comment on column v_area_build_house_allowner_rela.phone not supported: 手机号

