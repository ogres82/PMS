create view v_assessment_rec as
select `a`.`rec_id`        AS `recId`,
       `a`.`kpi_id`        AS `kpiId`,
       `a`.`emp_id`        AS `empId`,
       `a`.`img_urls`      AS `imgUlrs`,
       `a`.`kpi_value`     AS `kpiValue`,
       `a`.`insert_date`   AS `insertDate`,
       `a`.`oper_id`       AS `operId`,
       `d`.`CNAME_`        AS `operName`,
       `a`.`reason`        AS `reason`,
       `b`.`emp_name`      AS `empName`,
       `b`.`emp_dept_id`   AS `empDeptId`,
       `b`.`emp_dept_name` AS `empDeptName`,
       `b`.`emp_post_id`   AS `empPostId`,
       `b`.`emp_post_name` AS `empPostName`,
       '0'                 AS `kpiType`,
       `c`.`kpi_detail`    AS `kpiDetail`,
       `c`.`kpi_method`    AS `kpiMethod`
from (((`pms_product`.`t_assessment_rec` `a` join `pms_product`.`v_t_emp` `b`) join `pms_product`.`t_assessment_kpi` `c`)
         join `pms_product`.`bdf2_user` `d`)
where ((`a`.`emp_id` = `b`.`emp_id`) and (`a`.`kpi_id` = `c`.`kpi_id`) and (`a`.`oper_id` = `d`.`USERNAME_`))
union all
select `a`.`rec_id`                                                    AS `recId`,
       `a`.`kpi_id`                                                    AS `kpiId`,
       `a`.`emp_id`                                                    AS `empId`,
       `a`.`img_urls`                                                  AS `imgUlrs`,
       `a`.`kpi_value`                                                 AS `kpiValue`,
       `a`.`insert_date`                                               AS `insertDate`,
       `a`.`oper_id`                                                   AS `operId`,
       (select `pms_product`.`bdf2_user`.`CNAME_`
        from `pms_product`.`bdf2_user`
        where (`a`.`oper_id` = `pms_product`.`bdf2_user`.`USERNAME_`)) AS `operName`,
       `a`.`reason`                                                    AS `reason`,
       `b`.`NAME_`                                                     AS `empName`,
       `a`.`emp_id`                                                    AS `empDeptId`,
       `b`.`NAME_`                                                     AS `empDeptName`,
       ''                                                              AS `empPostId`,
       ''                                                              AS `empPostName`,
       '1'                                                             AS `kpiType`,
       `c`.`kpi_detail`                                                AS `kpiDetail`,
       `c`.`kpi_method`                                                AS `kpiMethod`
from ((`pms_product`.`t_assessment_rec` `a` join `pms_product`.`bdf2_dept` `b`)
         join `pms_product`.`t_assessment_kpi` `c`)
where ((`a`.`emp_id` = `b`.`ID_`) and (`a`.`kpi_id` = `c`.`kpi_id`));

