create definer = pms_admin@`%` trigger ins_charge_refresh
    after insert
    on t_charge_type_room_rela
    for each row
begin
call pro_refresh_house_vs_fee();
end;

