create
    definer = pms_admin@`%` function seq_setval(v_seq_name varchar(50), v_new_val int) returns int
begin    
	update sequence set current_val = v_new_val where seq_name = v_seq_name;   
	return seq_currval(v_seq_name);
end;

