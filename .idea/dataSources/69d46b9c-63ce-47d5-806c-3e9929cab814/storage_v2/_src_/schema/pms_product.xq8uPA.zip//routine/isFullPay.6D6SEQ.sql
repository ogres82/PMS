create
    definer = pms_admin@`%` function isFullPay(roomId varchar(50), chargeTypeNo varchar(50), accountPay float) returns int(1)
BEGIN
	#Routine body goes here...
	DECLARE v_advance_amount FLOAT DEFAULT 0.0;
		-- 遍历数据结束标志
  DECLARE done INT DEFAULT FALSE;
	-- 将结束标志绑定到
  DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' begin SET done = TRUE; END;

	SELECT r.amount INTO v_advance_amount FROM t_charge_type_room_rela r
						where r.room_id=roomId and r.charge_type_no=chargeTypeNo;
  
	IF done THEN
     RETURN 0;
  END IF;
	
  IF(v_advance_amount>=accountPay) THEN RETURN 1;
	ELSE
		RETURN 0;
	END IF;
END;

