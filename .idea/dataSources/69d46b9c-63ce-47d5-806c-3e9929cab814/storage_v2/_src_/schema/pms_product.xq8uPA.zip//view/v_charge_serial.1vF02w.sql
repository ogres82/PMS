create view v_charge_serial as
select `a`.`serial_id`                                                                           AS `serial_id`,
       ifnull(`b`.`charge_type_no`, `a`.`charge_type_no`)                                        AS `charge_type_no`,
       ifnull(`b`.`charge_type_name`, `a`.`charge_type_name`)                                    AS `charge_type_name`,
       `b`.`type_flag`                                                                           AS `type_flag`,
       (select `q`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `q`
        where ((`q`.`code_detail` = `b`.`type_flag`) and (`q`.`code` = 'charge_type_flag')))     AS `type_flag_name`,
       `a`.`oper_emp_id`                                                                         AS `oper_emp_id`,
       ifnull(`d`.`emp_name`, `a`.`oper_emp_id`)                                                 AS `oper_emp_name`,
       `a`.`owner_id`                                                                            AS `owner_id`,
       `a`.`owner_name`                                                                          AS `owner_name`,
       `c`.`build_id`                                                                            AS `build_id`,
       `c`.`build_name`                                                                          AS `build_name`,
       `c`.`community_id`                                                                        AS `community_id`,
       `c`.`community_name`                                                                      AS `community_name`,
       `c`.`belong_sb_id`                                                                        AS `storied_build_id`,
       `c`.`storied_build_name`                                                                  AS `storied_build_name`,
       `c`.`unit_id`                                                                             AS `unit_id`,
       `c`.`unit_name`                                                                           AS `unit_name`,
       `a`.`room_id`                                                                             AS `room_id`,
       `a`.`room_no`                                                                             AS `room_no`,
       `a`.`room_type`                                                                           AS `room_type`,
       `a`.`paid_amount`                                                                         AS `paid_amount`,
       `a`.`receive_amount`                                                                      AS `receive_amount`,
       `a`.`paid_mode`                                                                           AS `paid_mode`,
       (select `q`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `q`
        where ((`q`.`code_detail` = `a`.`paid_mode`) and (`q`.`code` = 'charge_paid_mode')))     AS `paid_mode_name`,
       `a`.`paid_date`                                                                           AS `paid_date`,
       `a`.`begin_date`                                                                          AS `begin_date`,
       `a`.`end_date`                                                                            AS `end_date`,
       `a`.`update_date`                                                                         AS `update_date`,
       `a`.`remark`                                                                              AS `remark`,
       `a`.`order_id`                                                                            AS `order_id`,
       `a`.`receipt_id`                                                                          AS `receipt_id`,
       `a`.`reduce_url`                                                                          AS `reduce_url`,
       `a`.`charge_type`                                                                         AS `charge_type`,
       (select `q`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `q`
        where ((`q`.`code_detail` = `a`.`charge_type`) and (`q`.`code` = 'charge_serial_type'))) AS `serial_type_name`
from (((`pms_product`.`t_charge_serial_info` `a` left join `pms_product`.`t_charge_type_setting` `b` on ((`a`.`charge_type_no` = `b`.`charge_type_no`))) left join `pms_product`.`t_house_property` `c` on ((`a`.`room_id` = `c`.`room_id`)))
         left join `pms_product`.`t_emp` `d` on ((`d`.`emp_phone` = `a`.`oper_emp_id`)));

-- comment on column v_charge_serial.type_flag not supported: 收费项目类型的标志，（默认为00，表示未分类。比如物管费，有多种物管费，统一标志为01。其他类似，值为02，03……）

-- comment on column v_charge_serial.build_id not supported: 楼盘ID

-- comment on column v_charge_serial.build_name not supported: 楼盘名称

-- comment on column v_charge_serial.community_id not supported: 小区ID

-- comment on column v_charge_serial.community_name not supported: 小区名称

-- comment on column v_charge_serial.storied_build_id not supported: 所属楼栋ID

-- comment on column v_charge_serial.storied_build_name not supported: 楼栋名称

-- comment on column v_charge_serial.unit_id not supported: 单元ID

-- comment on column v_charge_serial.unit_name not supported: 单元名称

-- comment on column v_charge_serial.room_type not supported: 房间类型

-- comment on column v_charge_serial.paid_amount not supported: 实收金额

-- comment on column v_charge_serial.receive_amount not supported: 应收金额

-- comment on column v_charge_serial.paid_mode not supported: 付款方式

-- comment on column v_charge_serial.paid_date not supported: 付款日期

-- comment on column v_charge_serial.order_id not supported: 移动端支付的订单id

-- comment on column v_charge_serial.receipt_id not supported: 收据号

-- comment on column v_charge_serial.reduce_url not supported: 减免证明

