create view v_t_r_assign_dispatch as
select `d`.`dispatch_kid`                                                                                          AS `dispatch_kid`,
       `d`.`dispatch_id`                                                                                           AS `dispatch_id`,
       `t`.`address`                                                                                               AS `addres`,
       format(`d`.`dispatch_expense`, 2)                                                                           AS `dispatch_expense`,
       `d`.`dispatch_status`                                                                                       AS `dispatch_status`,
       (select `di`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `di`
        where ((`di`.`code_detail` = `d`.`dispatch_status`) and
               (`di`.`code` = 'main_mtn_dispatch_status')))                                                        AS `dispatch_status_name`,
       `t`.`createby`                                                                                              AS `createby`,
       (select `u`.`CNAME_`
        from `pms_product`.`bdf2_user` `u`
        where (`u`.`USERNAME_` = `t`.`createby`))                                                                  AS `createby_name`,
       date_format(`t`.`createTime`, '%Y-%m-%d %H:%i:%S')                                                          AS `createTime`,
       `d`.`dispatch_handle_id`                                                                                    AS `dispatch_handle_id`,
       (select `u`.`CNAME_`
        from `pms_product`.`bdf2_user` `u`
        where (`u`.`USERNAME_` = `d`.`dispatch_handle_id`))                                                        AS `dispatch_handle_name`,
       date_format(`d`.`dispatch_finish_time`, '%Y-%m-%d %H:%i:%S')                                                AS `dispatch_finish_time`,
       `d`.`mtn_id`                                                                                                AS `mtn_id`,
       `t`.`rpt_name`                                                                                              AS `rpt_name`,
       `t`.`in_call`                                                                                               AS `in_call`
from (`pms_product`.`t_r_maintain_dispatch` `d`
         join `pms_product`.`t_r_maintain` `t`)
where (`t`.`rpt_id` = `d`.`mtn_id`);

