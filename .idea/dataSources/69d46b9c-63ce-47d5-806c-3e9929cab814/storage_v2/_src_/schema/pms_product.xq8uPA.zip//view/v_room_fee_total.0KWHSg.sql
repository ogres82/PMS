create view v_room_fee_total as
select `a`.`room_id` AS `room_id`, sum(`a`.`paid_amount`) AS `total_paid_amount`
from `pms_product`.`t_charge_serial_info_g` `a`
where exists(select 1
             from `pms_product`.`t_charge_type_setting` `b`
             where ((`b`.`type_flag` = '01') and (`a`.`charge_type_no` = `b`.`charge_type_no`)))
group by `a`.`room_id`;

