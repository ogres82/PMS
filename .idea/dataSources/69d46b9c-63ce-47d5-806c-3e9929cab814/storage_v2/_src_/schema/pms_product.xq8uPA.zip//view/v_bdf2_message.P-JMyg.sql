create view v_bdf2_message as
select `a`.`ID_`        AS `ID_`,
       `a`.`CONTENT_`   AS `CONTENT_`,
       `a`.`READ_`      AS `READ_`,
       `a`.`RECEIVER_`  AS `RECEIVER_`,
       `a`.`REPLY_`     AS `REPLY_`,
       `a`.`SEND_DATE_` AS `SEND_DATE_`,
       `a`.`SENDER_`    AS `SENDER_`,
       `a`.`TAGS_`      AS `TAGS_`,
       `a`.`TITLE_`     AS `TITLE_`,
       `b`.`CNAME_`     AS `CNAME_`,
       `c`.`CNAME_`     AS `receiver`
from ((`pms_product`.`bdf2_message` `a` left join `pms_product`.`bdf2_user` `b` on ((`b`.`USERNAME_` = `a`.`SENDER_`)))
         left join `pms_product`.`bdf2_user` `c` on ((`c`.`USERNAME_` = `a`.`RECEIVER_`)));

