create
    definer = pms_admin@`%` procedure pro_refresh_owner_vs_room_id()
BEGIN
DELETE FROM t_owner_vs_room_id;
INSERT INTO t_owner_vs_room_id
SELECT
	a.owner_id,
	a.owner_name,
	a.sex,
	a.phone,
	a.card_id,
	a.birth_date,
	b.room_id 
FROM
	t_property_owner a
	LEFT JOIN t_house_owner b ON a.owner_id = b.owner_id 
WHERE
	a.is_del = '0' 
	AND a.owner_identity = '0';
	end;

