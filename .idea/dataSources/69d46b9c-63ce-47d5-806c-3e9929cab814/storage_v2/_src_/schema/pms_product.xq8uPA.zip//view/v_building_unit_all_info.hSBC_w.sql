create view v_building_unit_all_info as
select `d`.`build_id`           AS `build_id`,
       `d`.`build_name`         AS `build_name`,
       `d`.`lz_id`              AS `build_lz_id`,
       `c`.`community_id`       AS `community_id`,
       `c`.`community_name`     AS `community_name`,
       `c`.`lz_id`              AS `community_lz_id`,
       `b`.`storied_build_id`   AS `storied_build_id`,
       `b`.`storied_build_name` AS `storied_build_name`,
       `b`.`lz_id`              AS `storied_build_lz_id`,
       `a`.`unit_id`            AS `unit_id`,
       `a`.`unit_name`          AS `unit_name`,
       `a`.`lz_id`              AS `unit_lz_id`,
       isnull(`a`.`lz_id`)      AS `is_sycn`
from (((`pms_product`.`t_building_unit` `a` left join `pms_product`.`t_building_property` `b` on ((`a`.`belong_sb_id` = `b`.`storied_build_id`))) left join `pms_product`.`t_area_property` `c` on ((`b`.`belong_comm_id` = `c`.`community_id`)))
         left join `pms_product`.`t_all_area` `d` on ((`c`.`belong_build_id` = `d`.`build_id`)))
where (`a`.`is_del` = '0');

-- comment on column v_building_unit_all_info.build_id not supported: 楼盘ID

-- comment on column v_building_unit_all_info.build_name not supported: 楼盘名称  例：乐湾国际城一期

-- comment on column v_building_unit_all_info.community_id not supported: 小区ID

-- comment on column v_building_unit_all_info.community_name not supported: 小区名称 例：西湖御景、依山云墅

-- comment on column v_building_unit_all_info.storied_build_id not supported: 楼栋ID

-- comment on column v_building_unit_all_info.storied_build_name not supported: 楼栋名称 例：独栋、001栋

