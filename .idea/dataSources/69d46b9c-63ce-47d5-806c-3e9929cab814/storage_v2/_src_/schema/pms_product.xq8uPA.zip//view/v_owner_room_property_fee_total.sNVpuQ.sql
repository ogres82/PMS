create view v_owner_room_property_fee_total as
select sum(`v_owner_room_property_fee_rec`.`paidAmount`) AS `sum_paid_amount`,
       `v_owner_room_property_fee_rec`.`roomId`          AS `room_id`
from `pms_product`.`v_owner_room_property_fee_rec`
group by `v_owner_room_property_fee_rec`.`roomId`;

