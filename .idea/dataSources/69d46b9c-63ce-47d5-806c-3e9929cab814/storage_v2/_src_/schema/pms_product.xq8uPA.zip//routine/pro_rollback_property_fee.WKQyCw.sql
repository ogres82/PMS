create
    definer = pms_admin@`%` procedure pro_rollback_property_fee(IN in_room_id varchar(60))
BEGIN

	/*标识事务错误*/
  DECLARE p_charge_type_no VARCHAR(20) DEFAULT '';
	/*缴费合计*/
	DECLARE p_pay_fee DECIMAL(10,2) DEFAULT 0.00;
	/*出抵扣外的缴费合计*/
	DECLARE p_pay_fee1 DECIMAL(10,2) DEFAULT 0.00;
	
	DECLARE t_error INTEGER DEFAULT 0;
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;
	
	SELECT charge_type_no INTO p_charge_type_no FROM t_charge_type_room_rela WHERE room_id = in_room_id;
	SELECT ifnull(sum(paidAmount),0) INTO p_pay_fee FROM v_owner_room_property_fee_rec WHERE roomId = in_room_id;
	SELECT ifnull(sum(ifnull(paid_amount,0)),0) INTO p_pay_fee1 FROM t_charge_info WHERE paid_mode<>'01' and room_id = in_room_id
	and charge_type_no in (select charge_type_no from t_charge_type_setting where type_flag = '01');
		/*创建临时表，存放用户账单*/
	drop temporary table if exists tmp_charge_info;
	create temporary table  tmp_charge_info as 
  select *
	from t_charge_info
	where paid_mode = '01'
	and charge_type_no in (select charge_type_no from t_charge_type_setting where type_flag = '01')
	and room_id = in_room_id;
	
	START TRANSACTION ;	
	IF p_charge_type_no <>'' THEN
	
	/*更新用户的余额*/
	update t_charge_type_room_rela
	set amount = p_pay_fee - p_pay_fee1
	where room_id = in_room_id;

	
	DELETE FROM
	t_charge_serial_detail WHERE
	charge_id in  ( SELECT charge_id FROM tmp_charge_info);

	
	DELETE FROM t_charge_serial_info WHERE charge_info_id in (SELECT charge_id FROM tmp_charge_info )
	AND room_id = in_room_id;

	
	update t_charge_info
	set paid_date = null,paid_amount = 0,paid_mode = null,state = '01',arrearage_amount = 0
	where paid_mode = '01' 
	and charge_type_no in (select charge_type_no from t_charge_type_setting where type_flag = '01')
	and room_id = in_room_id;	

	
	ELSE
	select "该房间未关联物业费！";
	END IF; 
	select t_error;
	 IF t_error = 1 THEN    
            ROLLBACK;    
        ELSE    
						select "提交！";
            COMMIT;    
        END IF; 

END;

