create view v_t_r_assign_main as
select `t`.`rpt_kid`                                                                                     AS `rpt_kid`,
       `t`.`rpt_id`                                                                                      AS `rpt_id`,
       `t`.`event_source`                                                                                AS `event_source`,
       (select `d`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `d`
        where ((`d`.`code_detail` = `t`.`event_source`) and
               (`d`.`code` = 'main_event_source')))                                                      AS `event_source_name`,
       `t`.`event_type`                                                                                  AS `event_type`,
       (select `d`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `d`
        where ((`d`.`code_detail` = `t`.`event_type`) and
               (`d`.`code` = 'main_event_type')))                                                        AS `event_type_name`,
       `t`.`address`                                                                                     AS `addres`,
       `t`.`createby`                                                                                    AS `createby`,
       (select `u`.`CNAME_`
        from `pms_product`.`bdf2_user` `u`
        where (`u`.`USERNAME_` = `t`.`createby`))                                                        AS `createby_name`,
       date_format(`t`.`createTime`, '%Y-%m-%d %H:%i:%S')                                                AS `createTime`,
       date_format(`t`.`finishTime`, '%Y-%m-%d %H:%i:%S')                                                AS `finishTime`,
       `t`.`rpt_name`                                                                                    AS `rpt_name`,
       `t`.`event_state`                                                                                 AS `event_state`,
       (select `pms_product`.`dir_directorydetail`.`code_detail_name`
        from `pms_product`.`dir_directorydetail`
        where ((`pms_product`.`dir_directorydetail`.`code` = 'main_mtn_dispatch_status') and
               (`pms_product`.`dir_directorydetail`.`code_detail` = `t`.`event_state`)))                 AS `event_state_name`,
       `t`.`order_state`                                                                                 AS `order_state`
from `pms_product`.`t_r_maintain` `t`;

