create view v_eqp_mtn as
select `a`.`mtn_rec_id`      AS `mtn_rec_id`,
       `a`.`eqp_id`          AS `eqp_id`,
       `b`.`eqp_name`        AS `eqp_name`,
       `a`.`eqp_mtn_content` AS `eqp_mtn_content`,
       `a`.`eqp_mtn_date`    AS `eqp_mtn_date`,
       `a`.`eqp_mtn_detail`  AS `eqp_mtn_detail`,
       `a`.`eqp_mtn_endDate` AS `eqp_mtn_endDate`,
       `a`.`eqp_mtn_fee`     AS `eqp_mtn_fee`,
       `a`.`eqp_mtn_person`  AS `eqp_mtn_person`,
       `a`.`eqp_mtn_time`    AS `eqp_mtn_time`,
       `a`.`eqp_mtn_type`    AS `eqp_mtn_type`
from (`pms_product`.`t_eqp_mtn_rec` `a`
         left join `pms_product`.`t_eqp_file` `b` on ((`a`.`eqp_id` = `b`.`eqp_id`)));

