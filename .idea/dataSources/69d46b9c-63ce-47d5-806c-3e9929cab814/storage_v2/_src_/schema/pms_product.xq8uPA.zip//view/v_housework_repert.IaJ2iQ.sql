create view v_housework_repert as
select `t`.`id`             AS `id`,
       `t`.`event_no`       AS `event_no`,
       `t`.`event_title`    AS `event_title`,
       `t`.`event_content`  AS `event_content`,
       `t`.`user_address`   AS `user_address`,
       `t`.`link_man`       AS `link_man`,
       `t`.`link_phone`     AS `link_phone`,
       `t`.`record_id`      AS `record_id`,
       `t`.`room_id`        AS `room_id`,
       `t`.`project_id`     AS `project_id`,
       `t`.`accept_time`    AS `accept_time`,
       `t`.`call_phone`     AS `call_phone`,
       `t`.`event_from`     AS `event_from`,
       `t`.`pre_time`       AS `pre_time`,
       `t`.`serv_price`     AS `serv_price`,
       `t`.`event_state`    AS `event_state`,
       `t`.`finish_time`    AS `finish_time`,
       `t`.`verify_oper_id` AS `verify_oper_id`,
       `t`.`visit_state`    AS `visit_state`,
       `t`.`visit_oper_id`  AS `visit_oper_id`,
       `t`.`bpm_processId`  AS `bpm_processId`,
       `t`.`other`          AS `other`,
       `t`.`link_man_name`  AS `link_man_name`,
       `d`.`visit_evaluate` AS `visit_evaluate`,
       `d`.`visit_time`     AS `visit_time`
from (`pms_product`.`t_housework_event` `t`
         join `pms_product`.`t_housework_visit` `d`)
where ((`t`.`id` = `d`.`event_id`) and (`t`.`event_state` = '5'));

