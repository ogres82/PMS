create view v_r_t_assign_comp as
select `c`.`mtn_id`                                                                                              AS `mtn_id`,
       `c`.`comp_kid`                                                                                            AS `comp_kid`,
       `t`.`rpt_name`                                                                                            AS `rpt_name`,
       `t`.`address`                                                                                             AS `addres`,
       date_format(`t`.`createTime`, '%Y-%m-%d %H:%i:%S')                                                        AS `createTime`,
       date_format(`t`.`finishTime`, '%Y-%m-%d %H:%i:%S')                                                        AS `finishTime`,
       `c`.`comp_emergency`                                                                                      AS `comp_emergency`,
       (select `d`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `d`
        where ((`d`.`code_detail` = `c`.`comp_emergency`) and
               (`d`.`code` = 'main_mtn_emergency')))                                                             AS `comp_emergency_name`,
       `c`.`comp_status`                                                                                         AS `comp_status`,
       (select `d`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `d`
        where ((`d`.`code_detail` = `c`.`comp_status`) and
               (`d`.`code` = 'main_mtn_dispatch_status')))                                                       AS `comp_status_name`,
       date_format(`c`.`comp_finish_time`, '%Y-%m-%d %H:%i:%S')                                                  AS `comp_finish_time`,
       (select `u`.`CNAME_`
        from `pms_product`.`bdf2_user` `u`
        where (`u`.`USERNAME_` = `t`.`createby`))                                                                AS `CNAME`,
       (select `u`.`CNAME_`
        from `pms_product`.`bdf2_user` `u`
        where (`u`.`USERNAME_` = `c`.`comp_operator_id`))                                                        AS `comp_operator_name`,
       `c`.`comp_id`                                                                                             AS `comp_id`,
       `c`.`comp_operator_id`                                                                                    AS `comp_operator_id`
from (`pms_product`.`t_r_maintain_complaint` `c`
         join `pms_product`.`t_r_maintain` `t`)
where (`c`.`mtn_id` = `t`.`rpt_id`);

