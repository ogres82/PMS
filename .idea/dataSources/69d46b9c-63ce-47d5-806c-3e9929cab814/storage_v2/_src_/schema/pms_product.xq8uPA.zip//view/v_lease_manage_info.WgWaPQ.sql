create view v_lease_manage_info as
select `a`.`build_id`                                                                  AS `buildId`,
       `a`.`build_name`                                                                AS `buildName`,
       `a`.`community_id`                                                              AS `communityId`,
       `a`.`community_name`                                                            AS `communityName`,
       `a`.`belong_sb_id`                                                              AS `storiedBuildId`,
       `a`.`storied_build_name`                                                        AS `storiedBuildName`,
       `a`.`room_id`                                                                   AS `roomId`,
       `a`.`room_no`                                                                   AS `roomNo`,
       concat(`a`.`community_name`, '-', `a`.`storied_build_name`, '-', `a`.`room_no`) AS `roomAddr`,
       `a`.`build_area`                                                                AS `buildArea`,
       `b`.`lease_id`                                                                  AS `leaseId`,
       `b`.`lessees_name`                                                              AS `lesseesName`,
       `b`.`card_id`                                                                   AS `cardId`,
       `b`.`phone`                                                                     AS `phone`,
       `b`.`start_time`                                                                AS `startTime`,
       (`b`.`start_time` + interval `b`.`months_num` month)                            AS `endTime`,
       `b`.`months_num`                                                                AS `monthsNum`,
       `b`.`months_price`                                                              AS `monthsPrice`,
       (`b`.`months_num` * `b`.`months_price`)                                         AS `totalPrice`,
       `b`.`insert_time`                                                               AS `insertTime`,
       `b`.`update_time`                                                               AS `updateTime`,
       `b`.`oper_id`                                                                   AS `operId`,
       (select `pms_product`.`bdf2_user`.`CNAME_`
        from `pms_product`.`bdf2_user`
        where (`pms_product`.`bdf2_user`.`USERNAME_` = `b`.`oper_id`))                 AS `operName`,
       `b`.`remark`                                                                    AS `remark`
from (`pms_product`.`t_house_property` `a`
         left join `pms_product`.`t_lease_manage` `b`
                   on (((`a`.`room_id` = `b`.`room_id`) and (`b`.`delete_is` = '0') and (`b`.`state` = '1'))))
where (`a`.`room_type` = '4');

-- comment on column v_lease_manage_info.buildId not supported: 楼盘ID

-- comment on column v_lease_manage_info.buildName not supported: 楼盘名称

-- comment on column v_lease_manage_info.communityId not supported: 小区ID

-- comment on column v_lease_manage_info.communityName not supported: 小区名称

-- comment on column v_lease_manage_info.storiedBuildId not supported: 所属楼栋ID

-- comment on column v_lease_manage_info.storiedBuildName not supported: 楼栋名称

-- comment on column v_lease_manage_info.roomId not supported: 房间ID

-- comment on column v_lease_manage_info.roomNo not supported: 房间号

-- comment on column v_lease_manage_info.buildArea not supported: 建筑面积

-- comment on column v_lease_manage_info.leaseId not supported: 主键ID

-- comment on column v_lease_manage_info.lesseesName not supported: 租客姓名

-- comment on column v_lease_manage_info.cardId not supported: 身份证

-- comment on column v_lease_manage_info.phone not supported: 电话

-- comment on column v_lease_manage_info.startTime not supported: 开始时间

-- comment on column v_lease_manage_info.monthsNum not supported: 出租月份

-- comment on column v_lease_manage_info.monthsPrice not supported: 出租价格（单位：元）

-- comment on column v_lease_manage_info.insertTime not supported: 创建时间

-- comment on column v_lease_manage_info.updateTime not supported: 更新时间

-- comment on column v_lease_manage_info.operId not supported: 操作员ID

-- comment on column v_lease_manage_info.remark not supported: 备注

