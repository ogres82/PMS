create
    definer = pms_admin@`%` function seq_currval(v_seq_name varchar(50)) returns int
BEGIN
	DECLARE	v_value	INTEGER;
	SET	v_value	= 0;

	SELECT current_val INTO	v_value FROM sequence WHERE	seq_name = v_seq_name;
	RETURN v_value;
END;

