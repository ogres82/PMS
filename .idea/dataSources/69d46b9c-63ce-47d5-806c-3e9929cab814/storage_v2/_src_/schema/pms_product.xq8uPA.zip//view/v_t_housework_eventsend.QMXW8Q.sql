create view v_t_housework_eventsend as
select `t`.`event_no`                                                                                              AS `event_no`,
       `t`.`event_title`                                                                                           AS `event_title`,
       `t`.`call_phone`                                                                                            AS `call_phone`,
       `t`.`accept_time`                                                                                           AS `accept_time`,
       `t`.`event_from`                                                                                            AS `event_from`,
       (select `d`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `d`
        where ((`d`.`code_detail` = `t`.`event_from`) and
               (`d`.`code` = 'main_event_source')))                                                                AS `event_source_name`,
       `t`.`pre_time`                                                                                              AS `pre_time`,
       `t`.`record_id`                                                                                             AS `record_id`,
       `t`.`bpm_processId`                                                                                         AS `bpm_processId`,
       (select `u`.`owner_name`
        from `pms_product`.`t_property_owner` `u`
        where (`u`.`owner_id` = `t`.`link_man`))                                                                   AS `rpt_name`,
       `t`.`event_content`                                                                                         AS `event_content`,
       `t`.`verify_oper_id`                                                                                        AS `verify_oper_id`,
       `t`.`user_address`                                                                                          AS `user_address`,
       `t`.`id`                                                                                                    AS `id`,
       `di`.`oper_id`                                                                                              AS `oper_id`,
       `di`.`send_time`                                                                                            AS `send_time`,
       `di`.`send_state`                                                                                           AS `send_state`,
       `t`.`event_state`                                                                                           AS `event_state`,
       `di`.`send_no`                                                                                              AS `send_no`,
       `di`.`oper_name`                                                                                            AS `oper_name`,
       `di`.`id`                                                                                                   AS `send_id`,
       `di`.`handle_content`                                                                                       AS `handle_content`,
       `di`.`arrv_time`                                                                                            AS `arrv_time`,
       format(`di`.`houseKeepingPay`, 2)                                                                           AS `houseKeepingPay`,
       `t`.`other`                                                                                                 AS `other`
from (`pms_product`.`t_housework_event` `t`
         join `pms_product`.`t_housework_dispatch` `di`)
where ((`t`.`id` = `di`.`event_id`) and (`t`.`event_state` <> '0'));

