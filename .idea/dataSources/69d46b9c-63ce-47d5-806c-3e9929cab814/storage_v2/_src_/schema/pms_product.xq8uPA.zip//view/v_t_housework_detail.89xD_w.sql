create view v_t_housework_detail as
select `t`.`event_no`      AS `event_no`,
       `t`.`event_content` AS `event_content`,
       `t`.`accept_time`   AS `accept_time`,
       `t`.`event_state`   AS `event_state`,
       `t`.`call_phone`    AS `call_phone`,
       `t`.`user_address`  AS `user_address`,
       `h`.`send_time`     AS `send_time`,
       `t`.`other`         AS `other`,
       `t`.`pre_time`      AS `pre_time`
from (`pms_product`.`t_housework_event` `t`
         left join `pms_product`.`t_housework_dispatch` `h` on ((`t`.`id` = `h`.`event_id`)));

