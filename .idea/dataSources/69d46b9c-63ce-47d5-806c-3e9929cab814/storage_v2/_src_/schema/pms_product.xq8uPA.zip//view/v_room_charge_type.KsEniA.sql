create view v_room_charge_type as
select `a`.`room_id`                         AS `room_id`,
       `a`.`room_no`                         AS `room_no`,
       `a`.`owner_id`                        AS `owner_id`,
       `a`.`charge_type_id`                  AS `charge_type_id`,
       `a`.`charge_type_no`                  AS `charge_type_no`,
       `a`.`update_emp_id`                   AS `update_emp_id`,
       `a`.`amount`                          AS `amount`,
       `b`.`charge_type_name`                AS `charge_type_name`,
       `b`.`charge_mode`                     AS `charge_mode`,
       `b`.`charge_price`                    AS `charge_price`,
       `b`.`update_date`                     AS `update_date`,
       `b`.`charge_way`                      AS `charge_way`,
       `b`.`charge_type`                     AS `charge_type`,
       coalesce(`b`.`charge_cycle_count`, 0) AS `charge_cycle_count`,
       `b`.`charge_cycle_unit`               AS `charge_cycle_unit`,
       `c`.`CNAME_`                          AS `CNAME_`,
       `a`.`charge_date`                     AS `charge_date`,
       `a`.`charge_state`                    AS `charge_state`
from ((`pms_product`.`t_charge_type_room_rela` `a` left join `pms_product`.`t_charge_type_setting` `b` on ((`a`.`charge_type_id` = `b`.`charge_type_id`)))
         left join `pms_product`.`bdf2_user` `c` on ((`c`.`USERNAME_` = `a`.`update_emp_id`)));

-- comment on column v_room_charge_type.amount not supported: 余额

-- comment on column v_room_charge_type.charge_date not supported: 收费开始时间

-- comment on column v_room_charge_type.charge_state not supported: 是否开始出账（1：开始出账；0：不出账）

