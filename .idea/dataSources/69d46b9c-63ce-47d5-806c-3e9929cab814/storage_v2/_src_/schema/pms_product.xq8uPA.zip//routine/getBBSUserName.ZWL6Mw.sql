create
    definer = pms_admin@`%` function getBBSUserName(v_id varchar(50)) returns varchar(100)
BEGIN
	#Routine body goes here...
	DECLARE	v_value	VARCHAR(100) DEFAULT '';

	SELECT u.user_nickname INTO v_value FROM t_bbs_user u WHERE u.mapping_user_id=v_id;
	RETURN v_value;
END;

