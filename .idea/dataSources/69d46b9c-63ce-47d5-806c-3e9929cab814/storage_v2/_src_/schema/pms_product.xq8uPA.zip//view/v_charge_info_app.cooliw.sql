create view v_charge_info_app as
select `t`.`charge_type_no`                                                                                  AS `charge_type_no`,
       (case
            when (`t`.`charge_type_name` in ('人工费', '维修材料费')) then '维修总费用'
            else `t`.`charge_type_name` end)                                                                 AS `charge_type_name`,
       `t`.`work_id`                                                                                         AS `work_id`,
       `t`.`owner_id`                                                                                        AS `owner_id`,
       `t`.`owner_name`                                                                                      AS `owner_name`,
       `t`.`room_id`                                                                                         AS `room_id`,
       `t`.`room_no`                                                                                         AS `room_no`,
       `t`.`begin_time`                                                                                      AS `begin_time`,
       `t`.`end_time`                                                                                        AS `end_time`,
       `t`.`receive_amount`                                                                                  AS `arrearage_amount`,
       `t`.`charge_id`                                                                                       AS `charge_id`
from `pms_product`.`t_charge_info` `t`
where ((`t`.`state` = '03') and (`t`.`is_del` = '0'));

