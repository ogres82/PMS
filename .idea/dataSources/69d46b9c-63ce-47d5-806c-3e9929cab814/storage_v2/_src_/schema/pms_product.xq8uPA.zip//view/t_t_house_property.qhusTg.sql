create view t_t_house_property as
select `d`.`build_name`         AS `build_name`,
       `c`.`community_name`     AS `community_name`,
       `b`.`storied_build_name` AS `storied_build_name`,
       `a`.`room_id`            AS `room_id`,
       `a`.`room_no`            AS `room_no`,
       `a`.`belong_sb_id`       AS `belong_sb_id`,
       `a`.`house_type`         AS `house_type`,
       `a`.`build_area`         AS `build_area`,
       `a`.`within_area`        AS `within_area`,
       `a`.`room_type`          AS `room_type`,
       `a`.`room_state`         AS `room_state`,
       `a`.`charge_object`      AS `charge_object`,
       `a`.`remark`             AS `remark`,
       `a`.`advance_amount`     AS `advance_amount`
from (((`pms_product`.`t_house_property` `a` left join `pms_product`.`t_building_property` `b` on ((`a`.`belong_sb_id` = `b`.`storied_build_id`))) left join `pms_product`.`t_area_property` `c` on ((`c`.`community_id` = `b`.`belong_comm_id`)))
         left join `pms_product`.`t_all_area` `d` on ((`d`.`build_id` = `c`.`belong_build_id`)));

-- comment on column t_t_house_property.build_name not supported: 楼盘名称  例：乐湾国际城一期

-- comment on column t_t_house_property.community_name not supported: 小区名称 例：西湖御景、依山云墅

-- comment on column t_t_house_property.storied_build_name not supported: 楼栋名称 例：独栋、001栋

-- comment on column t_t_house_property.room_id not supported: 房间ID

-- comment on column t_t_house_property.room_no not supported: 房间号

-- comment on column t_t_house_property.belong_sb_id not supported: 所属楼栋ID

-- comment on column t_t_house_property.house_type not supported: 户型  例：A户型、B户型

-- comment on column t_t_house_property.build_area not supported: 建筑面积

-- comment on column t_t_house_property.within_area not supported: 套内面积

-- comment on column t_t_house_property.room_type not supported: 房间类型 0高层1洋房2别墅

-- comment on column t_t_house_property.room_state not supported: 房间状态 0未售1交房2接房3入住4出租

-- comment on column t_t_house_property.charge_object not supported: 收费对象 0业主1租户2其他

-- comment on column t_t_house_property.remark not supported: 备注

