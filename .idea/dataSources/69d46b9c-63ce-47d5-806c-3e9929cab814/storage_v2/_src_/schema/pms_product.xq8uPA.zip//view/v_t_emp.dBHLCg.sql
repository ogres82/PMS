create view v_t_emp as
select '乐湾物业'                                                                                                    AS `emp_work_unit`,
       curdate()                                                                                                 AS `cur_date`,
       `a`.`emp_id`                                                                                              AS `emp_id`,
       `a`.`emp_no`                                                                                              AS `emp_no`,
       `a`.`emp_name`                                                                                            AS `emp_name`,
       `a`.`emp_sex`                                                                                             AS `emp_sex`,
       (case `a`.`emp_sex` when '0' then '女' when '1' then '男' end)                                              AS `emp_sex_name`,
       date_format(substr(`a`.`emp_id_no`, 7, 8), '%Y-%m-%d')                                                    AS `emp_birth`,
       ifnull(timestampdiff(YEAR, substr(`a`.`emp_id_no`, 7, 8), curdate()),
              0)                                                                                                 AS `emp_age`,
       substr(`a`.`emp_id_no`, 11, 2)                                                                            AS `emp_birth_mon`,
       (case
            when (timestampdiff(YEAR, substr(`a`.`emp_id_no`, 7, 8), curdate()) < 31) then 30
            when (timestampdiff(YEAR, substr(`a`.`emp_id_no`, 7, 8), curdate()) < 41) then 40
            when (timestampdiff(YEAR, substr(`a`.`emp_id_no`, 7, 8), curdate()) < 51) then 50
            else 60 end)                                                                                         AS `emp_age_group`,
       `a`.`emp_id_no`                                                                                           AS `emp_id_no`,
       `a`.`emp_nation`                                                                                          AS `emp_nation`,
       `a`.`emp_dept_id`                                                                                         AS `emp_dept_id`,
       `b`.`NAME_`                                                                                               AS `emp_dept_name`,
       `a`.`emp_post_id`                                                                                         AS `emp_post_id`,
       `c`.`NAME_`                                                                                               AS `emp_post_name`,
       `a`.`emp_phone`                                                                                           AS `emp_phone`,
       `a`.`emp_email`                                                                                           AS `emp_email`,
       `a`.`emp_contact_info`                                                                                    AS `emp_contact_info`,
       `a`.`emp_entry_time`                                                                                      AS `emp_entry_time`,
       `a`.`emp_quit_time`                                                                                       AS `emp_quit_time`,
       `a`.`emp_status`                                                                                          AS `emp_status`,
       `a`.`emp_photo`                                                                                           AS `emp_photo`,
       `a`.`emp_politics`                                                                                        AS `emp_politics`,
       `a`.`emp_work_place`                                                                                      AS `emp_work_place`,
       `a`.`emp_probation`                                                                                       AS `emp_probation`,
       `a`.`emp_regularize`                                                                                      AS `emp_regularize`,
       (case `a`.`emp_regularize` when '1' then '已转正' else '' end)                                               AS `emp_regularize_name`,
       `a`.`emp_regularize_time`                                                                                 AS `emp_regularize_time`,
       concat((case
                   when (floor((timestampdiff(MONTH, ifnull(`a`.`emp_quit_time`, `a`.`emp_entry_time`), curdate()) /
                                12)) > 0) then concat(floor((timestampdiff(MONTH,
                                                                           ifnull(`a`.`emp_quit_time`, `a`.`emp_entry_time`),
                                                                           curdate()) / 12)), '年')
                   else '0年' end), (case
                                        when ((timestampdiff(MONTH, ifnull(`a`.`emp_quit_time`, `a`.`emp_entry_time`),
                                                             curdate()) % 12) > 0) then concat(
                                                (timestampdiff(MONTH, ifnull(`a`.`emp_quit_time`, `a`.`emp_entry_time`),
                                                               curdate()) % 12), '月')
                                        else '' end))                                                            AS `emp_work_age`,
       concat((case
                   when (floor((timestampdiff(MONTH, ifnull(`a`.`emp_quit_time`, `a`.`emp_entry_time`), curdate()) /
                                12)) > 0) then concat(floor((timestampdiff(MONTH,
                                                                           ifnull(`a`.`emp_quit_time`, `a`.`emp_entry_time`),
                                                                           curdate()) / 12)), '年')
                   else '0年' end))                                                                               AS `emp_work_age1`,
       `a`.`emp_position_levl`                                                                                   AS `emp_position_levl`,
       (case `a`.`emp_position_levl`
            when '0' then '专员'
            when '1' then '主管'
            when '2' then '经理/副经理'
            when '3' then '总监/副总监'
            when '4' then '分管副总'
            when '5' then '总经理'
            when '6' then '副总裁'
            when '7' then '总裁/董事长'
            else '' end)                                                                                         AS `emp_position_levl_name`,
       `a`.`emp_tech_levl`                                                                                       AS `emp_tech_levl`,
       (case `a`.`emp_tech_levl`
            when '0' then '助理技术员/施工员'
            when '1' then '技术员/施工员'
            when '2' then '助理工程师'
            when '3' then '工程师'
            when '4' then '主管/高级工程师'
            when '5' then '特殊技术人才'
            when '6' then '总工'
            else '' end)                                                                                         AS `emp_tech_levl_name`,
       `a`.`emp_file_store_pos`                                                                                  AS `emp_file_store_pos`,
       `a`.`emp_pos_change1`                                                                                     AS `emp_pos_change1`,
       `a`.`emp_pos_change2`                                                                                     AS `emp_pos_change2`,
       `a`.`emp_training_rec`                                                                                    AS `emp_training_rec`,
       `a`.`emp_reword_punish`                                                                                   AS `emp_reword_punish`,
       `a`.`emp_education`                                                                                       AS `emp_education`,
       (case `a`.`emp_education`
            when 0 then '小学'
            when 1 then '初中'
            when 2 then '高中'
            when 3 then '中专'
            when 4 then '大专'
            when 5 then '本科'
            when 6 then '研究生'
            else '' end)                                                                                         AS `emp_education_name`,
       `a`.`emp_edu_full_time`                                                                                   AS `emp_edu_full_time`,
       (case `a`.`emp_edu_full_time` when '0' then '否' else '是' end)                                             AS `emp_edu_full_time1`,
       `a`.`emp_graduate_uni`                                                                                    AS `emp_graduate_uni`,
       `a`.`emp_major`                                                                                           AS `emp_major`,
       `a`.`emp_certificate`                                                                                     AS `emp_certificate`,
       `a`.`emp_certifi_no`                                                                                      AS `emp_certifi_no`,
       `a`.`emp_certifi_date`                                                                                    AS `emp_certifi_date`,
       `a`.`emp_certifi_expire_date`                                                                             AS `emp_certifi_expire_date`,
       `a`.`emp_certifi_check_date`                                                                              AS `emp_certifi_check_date`,
       `a`.`emp_certifi_lev`                                                                                     AS `emp_certifi_lev`,
       `a`.`emp_certifi_scan`                                                                                    AS `emp_certifi_scan`,
       (case `a`.`emp_certifi_scan` when '1' then '是' else '否' end)                                              AS `emp_certifi_scan1`,
       `a`.`emp_employ_type`                                                                                     AS `emp_employ_type`,
       (case `a`.`emp_employ_type`
            when '0' then '劳动合同'
            when '1' then '劳务合同'
            when '1' then '劳务合同'
            when '2' then '聘用合同'
            when '3' then '非全日制用工'
            when '9' then '其它'
            else '' end)                                                                                         AS `emp_employ_type_name`,
       `a`.`emp_contract_subject`                                                                                AS `emp_contract_subject`,
       `a`.`emp_contract_begin_date`                                                                             AS `emp_contract_begin_date`,
       `a`.`emp_contract_end_date`                                                                               AS `emp_contract_end_date`,
       if(isnull(`a`.`emp_quit_time`), ifnull(timestampdiff(DAY, curdate(), `a`.`emp_contract_end_date`), 0),
          0)                                                                                                     AS `emp_contract_remain`,
       if(isnull(`a`.`emp_quit_time`), (case
                                            when (timestampdiff(DAY, curdate(), `a`.`emp_contract_end_date`) < 0)
                                                then '合同过期'
                                            when (timestampdiff(DAY, curdate(), `a`.`emp_contract_end_date`) < 7)
                                                then '合同马上到期'
                                            when (timestampdiff(DAY, curdate(), `a`.`emp_contract_end_date`) < 30)
                                                then '30天内到期'
                                            else '尚未到期' end),
          '合同已终止')                                                                                               AS `emp_contract_mark`,
       `a`.`emp_labor_status`                                                                                    AS `emp_labor_status`,
       (case `a`.`emp_labor_status` when '0' then '在岗' else '' end)                                              AS `emp_labor_status1`,
       (case `a`.`emp_labor_status` when '1' then '停薪留职' else '' end)                                            AS `emp_labor_status2`,
       (case `a`.`emp_labor_status` when '2' then '协保' else '' end)                                              AS `emp_labor_status3`,
       (case `a`.`emp_labor_status` when '3' then '离岗退养' else '' end)                                            AS `emp_labor_status4`,
       (case `a`.`emp_labor_status` when '4' then '内退' else '' end)                                              AS `emp_labor_status5`,
       (case `a`.`emp_labor_status` when '5' then '其它' else '' end)                                              AS `emp_labor_status6`,
       `a`.`emp_pre_work_unit`                                                                                   AS `emp_pre_work_unit`,
       `a`.`emp_first_work_date`                                                                                 AS `emp_first_work_date`,
       `a`.`emp_marriage`                                                                                        AS `emp_marriage`,
       (case `a`.`emp_marriage` when '1' then '已婚' else '未婚' end)                                                AS `emp_marriage_name`,
       `a`.`emp_bear`                                                                                            AS `emp_bear`,
       (case `a`.`emp_bear` when '1' then '已' else '未' end)                                                      AS `emp_bear_name`,
       `a`.`emp_account`                                                                                         AS `emp_account`,
       `a`.`emp_account_address`                                                                                 AS `emp_account_address`,
       `a`.`emp_address`                                                                                         AS `emp_address`,
       `a`.`emp_mobile_phone`                                                                                    AS `emp_mobile_phone`,
       `a`.`emp_apply`                                                                                           AS `emp_apply`,
       `a`.`emp_residence`                                                                                       AS `emp_residence`,
       (case `a`.`emp_residence` when '1' then '是' else '否' end)                                                 AS `emp_residence_name`,
       `a`.`emp_special`                                                                                         AS `emp_special`,
       `a`.`emp_title_certificate`                                                                               AS `emp_title_certificate`,
       `a`.`emp_driver_license`                                                                                  AS `emp_driver_license`,
       `a`.`emp_probation_wages`                                                                                 AS `emp_probation_wages`,
       `a`.`emp_remark`                                                                                          AS `emp_remark`,
       `a`.`emp_full_wages`                                                                                      AS `emp_full_wages`,
       `a`.`emp_full_wages_date`                                                                                 AS `emp_full_wages_date`,
       `a`.`emp_real_wages`                                                                                      AS `emp_real_wages`,
       `a`.`emp_raise_wages`                                                                                     AS `emp_raise_wages`,
       `a`.`emp_bank_name`                                                                                       AS `emp_bank_name`,
       `a`.`emp_bank_card_no`                                                                                    AS `emp_bank_card_no`,
       `a`.`emp_flow_chart`                                                                                      AS `emp_flow_chart`,
       `a`.`emp_resume`                                                                                          AS `emp_resume`,
       `a`.`emp_reg_form`                                                                                        AS `emp_reg_form`,
       `a`.`emp_agreement`                                                                                       AS `emp_agreement`,
       `a`.`emp_id_card_copy`                                                                                    AS `emp_id_card_copy`,
       `a`.`emp_booklet_copy`                                                                                    AS `emp_booklet_copy`,
       `a`.`emp_diploma_copy`                                                                                    AS `emp_diploma_copy`,
       `a`.`emp_checkup_report`                                                                                  AS `emp_checkup_report`,
       `a`.`emp_leave_certificate`                                                                               AS `emp_leave_certificate`,
       `a`.`emp_bondsman_info`                                                                                   AS `emp_bondsman_info`,
       `a`.`emp_bond`                                                                                            AS `emp_bond`,
       `a`.`emp_account_properties`                                                                              AS `emp_account_properties`,
       `a`.`emp_insured_unit_no`                                                                                 AS `emp_insured_unit_no`,
       `a`.`emp_insured_no`                                                                                      AS `emp_insured_no`,
       `a`.`emp_insured_fee`                                                                                     AS `emp_insured_fee`,
       `a`.`emp_insured_date`                                                                                    AS `emp_insured_date`,
       `a`.`emp_funds_unit_no`                                                                                   AS `emp_funds_unit_no`,
       `a`.`emp_funds_no`                                                                                        AS `emp_funds_no`,
       `a`.`emp_funds_fee`                                                                                       AS `emp_funds_fee`,
       `a`.`emp_funds_date`                                                                                      AS `emp_funds_date`,
       `a`.`emp_file_no`                                                                                         AS `emp_file_no`,
       `a`.`emp_fullwages_flag`                                                                                  AS `emp_fullwages_flag`,
       (case `a`.`emp_fullwages_flag` when '1' then '是' else '否' end)                                            AS `emp_fullwages_flag1`,
       `a`.`emp_plate`                                                                                           AS `emp_plate`,
       `a`.`emp_tenure_date`                                                                                     AS `emp_tenure_date`,
       if(isnull(`a`.`emp_quit_time`), '在职', '离职')                                                               AS `emp_status_name`
from ((`pms_product`.`t_emp` `a` left join `pms_product`.`bdf2_dept` `b` on ((`a`.`emp_dept_id` = `b`.`ID_`)))
         left join `pms_product`.`bdf2_position` `c` on ((`a`.`emp_post_id` = `c`.`ID_`)))
order by `a`.`emp_id`;

-- comment on column v_t_emp.emp_id not supported: 员工ID-autocomplete.sc

-- comment on column v_t_emp.emp_no not supported: 工号

-- comment on column v_t_emp.emp_name not supported: 姓名

-- comment on column v_t_emp.emp_sex not supported: 性别(1男 0女)-radio.sc

-- comment on column v_t_emp.emp_id_no not supported: 身份证号

-- comment on column v_t_emp.emp_nation not supported: 民族

-- comment on column v_t_emp.emp_dept_id not supported: 部门ID-combobox.sc

-- comment on column v_t_emp.emp_post_id not supported: 岗位ID-autocomplete.sc

-- comment on column v_t_emp.emp_phone not supported: 联系电话

-- comment on column v_t_emp.emp_email not supported: 邮箱

-- comment on column v_t_emp.emp_contact_info not supported: 紧急联系人及电话

-- comment on column v_t_emp.emp_entry_time not supported: 入职时间

-- comment on column v_t_emp.emp_quit_time not supported: 离职时间

-- comment on column v_t_emp.emp_status not supported: 员工状态(0试用期 1在职 2离职)

-- comment on column v_t_emp.emp_photo not supported: 员工照片

-- comment on column v_t_emp.emp_politics not supported: 政治面貌

-- comment on column v_t_emp.emp_work_place not supported: 工作职场

-- comment on column v_t_emp.emp_probation not supported: 试用期

-- comment on column v_t_emp.emp_regularize not supported: 转正情况(0 未转正；1 已转正)

-- comment on column v_t_emp.emp_regularize_time not supported: 转正时间

-- comment on column v_t_emp.emp_position_levl not supported: 职能层级

-- comment on column v_t_emp.emp_tech_levl not supported: 技术层级

-- comment on column v_t_emp.emp_file_store_pos not supported: 人事档案存放地

-- comment on column v_t_emp.emp_pos_change2 not supported: 岗位晋升/降职

-- comment on column v_t_emp.emp_training_rec not supported: 培训记录

-- comment on column v_t_emp.emp_reword_punish not supported: 奖惩记录

-- comment on column v_t_emp.emp_education not supported: 学历

-- comment on column v_t_emp.emp_edu_full_time not supported: 是否全日制(是 1；不是 0)

-- comment on column v_t_emp.emp_graduate_uni not supported: 毕业院校

-- comment on column v_t_emp.emp_major not supported: 所学专业

-- comment on column v_t_emp.emp_certificate not supported: 专业证书

-- comment on column v_t_emp.emp_certifi_no not supported: 证书编号

-- comment on column v_t_emp.emp_certifi_date not supported: 发证日期

-- comment on column v_t_emp.emp_certifi_expire_date not supported: 证书有效期

-- comment on column v_t_emp.emp_certifi_check_date not supported: 复审日期

-- comment on column v_t_emp.emp_certifi_lev not supported: 专业资质证书等级

-- comment on column v_t_emp.emp_certifi_scan not supported: 是否有扫描件（是 1）

-- comment on column v_t_emp.emp_employ_type not supported: 用工类型

-- comment on column v_t_emp.emp_contract_subject not supported: 劳动合同主体

-- comment on column v_t_emp.emp_contract_begin_date not supported: 起始时间

-- comment on column v_t_emp.emp_contract_end_date not supported: 终止时间

-- comment on column v_t_emp.emp_labor_status not supported: 劳动关系状态

-- comment on column v_t_emp.emp_pre_work_unit not supported: 前工作单位及职务

-- comment on column v_t_emp.emp_first_work_date not supported: 初次工作时间

-- comment on column v_t_emp.emp_marriage not supported: 婚姻状况

-- comment on column v_t_emp.emp_bear not supported: 生育状况

-- comment on column v_t_emp.emp_account not supported: 户口

-- comment on column v_t_emp.emp_account_address not supported: 户籍地址

-- comment on column v_t_emp.emp_address not supported: 家庭住址

-- comment on column v_t_emp.emp_mobile_phone not supported: 手机

-- comment on column v_t_emp.emp_apply not supported: 应聘渠道

-- comment on column v_t_emp.emp_residence not supported: 是否住宿

-- comment on column v_t_emp.emp_special not supported: 特长

-- comment on column v_t_emp.emp_title_certificate not supported: 职称证书

-- comment on column v_t_emp.emp_driver_license not supported: 驾照资料

-- comment on column v_t_emp.emp_probation_wages not supported: 试用期工资

-- comment on column v_t_emp.emp_remark not supported: 备注

-- comment on column v_t_emp.emp_full_wages not supported: 转正工资

-- comment on column v_t_emp.emp_full_wages_date not supported: 转正工资体现月

-- comment on column v_t_emp.emp_real_wages not supported: 现工资

-- comment on column v_t_emp.emp_raise_wages not supported: 调薪情况

-- comment on column v_t_emp.emp_bank_name not supported: 银行名称

-- comment on column v_t_emp.emp_bank_card_no not supported: 银行卡号

-- comment on column v_t_emp.emp_flow_chart not supported: 录入流程表

-- comment on column v_t_emp.emp_resume not supported: 个人简历

-- comment on column v_t_emp.emp_reg_form not supported: 员工登记

-- comment on column v_t_emp.emp_agreement not supported: 保密协议

-- comment on column v_t_emp.emp_id_card_copy not supported: 身份证（复）

-- comment on column v_t_emp.emp_booklet_copy not supported: 户口簿（复）

-- comment on column v_t_emp.emp_diploma_copy not supported: 毕业证（复）

-- comment on column v_t_emp.emp_checkup_report not supported: 体检报告

-- comment on column v_t_emp.emp_leave_certificate not supported: 原单位离职证明

-- comment on column v_t_emp.emp_bondsman_info not supported: 担保人资料

-- comment on column v_t_emp.emp_bond not supported: 担保书

-- comment on column v_t_emp.emp_account_properties not supported: 户口性质

-- comment on column v_t_emp.emp_insured_unit_no not supported: 参保单位编号

-- comment on column v_t_emp.emp_insured_no not supported: 社会保障号

-- comment on column v_t_emp.emp_insured_fee not supported: 参保基数

-- comment on column v_t_emp.emp_insured_date not supported: 入职我单位后参保时间

-- comment on column v_t_emp.emp_funds_unit_no not supported: 公积金单位编号

-- comment on column v_t_emp.emp_funds_no not supported: 公积金个人账号

-- comment on column v_t_emp.emp_funds_fee not supported: 公积金基数

-- comment on column v_t_emp.emp_funds_date not supported: 入职我单位后汇费时间

-- comment on column v_t_emp.emp_file_no not supported: 人事档案编号

-- comment on column v_t_emp.emp_fullwages_flag not supported: 是否体现

-- comment on column v_t_emp.emp_plate not supported: 板块

-- comment on column v_t_emp.emp_tenure_date not supported: 在任时间

