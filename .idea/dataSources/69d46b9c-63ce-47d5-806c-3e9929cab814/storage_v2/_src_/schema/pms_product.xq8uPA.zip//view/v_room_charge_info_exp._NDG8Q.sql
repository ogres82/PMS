create view v_room_charge_info_exp as
select `h`.`room_id`                                                         AS `room_id`,
       `h`.`community_name`                                                  AS `community_name`,
       `h`.`storied_build_name`                                              AS `storied_build_name`,
       `h`.`room_no`                                                         AS `room_no`,
       `h`.`room_type`                                                       AS `room_type`,
       `b`.`owner_id`                                                        AS `owner_id`,
       `b`.`owner_name`                                                      AS `owner_name`,
       `b`.`phone`                                                           AS `phone`,
       `b`.`card_id`                                                         AS `card_id`,
       `b`.`emergency_contact`                                               AS `emergency_contact`,
       `b`.`emergency_contact_phone`                                         AS `emergency_contact_phone`,
       `h`.`within_area`                                                     AS `within_area`,
       `h`.`build_area`                                                      AS `build_area`,
       (`h`.`build_area` * `t`.`charge_price`)                               AS `total_price`,
       `h`.`receive_room_date`                                               AS `receive_room_date`,
       `h`.`make_room_date`                                                  AS `make_room_date`,
       `h`.`room_state`                                                      AS `room_state`,
       `t`.`charge_price`                                                    AS `charge_price`,
       `t`.`charge_type`                                                     AS `charge_type`,
       `t`.`charge_type_no`                                                  AS `charge_type_no`,
       `t`.`charge_type_name`                                                AS `charge_type_name`,
       `r`.`amount`                                                          AS `amount`,
       `r`.`type_flag`                                                       AS `type_flag`,
       sum(`c`.`arrearage_amount`)                                           AS `arrearage_amount`,
       count(`c`.`charge_id`)                                                AS `arrearage_num`,
       (select sum(`pms_product`.`t_charge_serial_info`.`paid_amount`)
        from `pms_product`.`t_charge_serial_info`
        where ((`h`.`room_id` = `pms_product`.`t_charge_serial_info`.`room_id`) and
               (`pms_product`.`t_charge_serial_info`.`paid_mode` <> '01') and
               (`pms_product`.`t_charge_serial_info`.`charge_type` <> '2'))) AS `serial_amount`
from ((((`pms_product`.`t_house_property` `h` left join `pms_product`.`t_charge_type_room_rela` `r` on ((`r`.`room_id` = `h`.`room_id`))) left join `pms_product`.`t_property_owner` `b` on (((`b`.`owner_id` = `r`.`owner_id`) and (`b`.`owner_identity` = '0')))) left join `pms_product`.`t_charge_type_setting` `t` on ((
        (`r`.`charge_type_no` = `t`.`charge_type_no`) and (`t`.`charge_mode` = '01'))))
         left join `pms_product`.`t_charge_info` `c` on (((`h`.`room_id` = `c`.`room_id`) and (`c`.`state` = '03'))))
group by `h`.`room_id`;

-- comment on column v_room_charge_info_exp.room_id not supported: 房间ID

-- comment on column v_room_charge_info_exp.community_name not supported: 小区名称

-- comment on column v_room_charge_info_exp.storied_build_name not supported: 楼栋名称

-- comment on column v_room_charge_info_exp.room_no not supported: 房间号

-- comment on column v_room_charge_info_exp.room_type not supported: 房间类型 0高层1洋房2别墅

-- comment on column v_room_charge_info_exp.owner_id not supported: 业主ID

-- comment on column v_room_charge_info_exp.owner_name not supported: 业主姓名

-- comment on column v_room_charge_info_exp.phone not supported: 手机号

-- comment on column v_room_charge_info_exp.card_id not supported: 身份证号

-- comment on column v_room_charge_info_exp.emergency_contact not supported: 紧急联系人及电话

-- comment on column v_room_charge_info_exp.emergency_contact_phone not supported: 紧急人联系电话

-- comment on column v_room_charge_info_exp.within_area not supported: 套内面积

-- comment on column v_room_charge_info_exp.build_area not supported: 建筑面积

-- comment on column v_room_charge_info_exp.receive_room_date not supported: 业主实际收房日期

-- comment on column v_room_charge_info_exp.make_room_date not supported: 收房日期（地产通知收房的日期）

-- comment on column v_room_charge_info_exp.room_state not supported: 房间状态 0未售1交房2接房3入住4出租

-- comment on column v_room_charge_info_exp.amount not supported: 余额

-- comment on column v_room_charge_info_exp.type_flag not supported: 收费项目类型的标志（参考表t_charge_type_setting中type_flag字段，默认为00，表示未分类。比如物管费，有多种物管费，统一标志为01。其他类似，值为02，03……）

