create view v_contract_rec as
select `a`.`rec_id`                AS `rec_id`,
       `a`.`contract_id`           AS `contract_id`,
       `a`.`contract_code`         AS `contract_code`,
       `a`.`contract_deal_content` AS `contract_deal_content`,
       `a`.`rec_time`              AS `rec_time`,
       `a`.`rec_person`            AS `rec_person`,
       `a`.`remark`                AS `remark`,
       `b`.`contract_name`         AS `contract_name`
from (`pms_product`.`t_contract_rec` `a`
         left join `pms_product`.`t_contract_info` `b` on ((`b`.`contract_id` = `a`.`contract_id`)));

-- comment on column v_contract_rec.rec_id not supported: 记录ID

-- comment on column v_contract_rec.contract_id not supported: 合同ID

-- comment on column v_contract_rec.contract_code not supported: 合同编号

-- comment on column v_contract_rec.contract_deal_content not supported: 执行内容

-- comment on column v_contract_rec.rec_time not supported: 记录日期

-- comment on column v_contract_rec.rec_person not supported: 记录人

-- comment on column v_contract_rec.remark not supported: 备注

-- comment on column v_contract_rec.contract_name not supported: 合同名称

