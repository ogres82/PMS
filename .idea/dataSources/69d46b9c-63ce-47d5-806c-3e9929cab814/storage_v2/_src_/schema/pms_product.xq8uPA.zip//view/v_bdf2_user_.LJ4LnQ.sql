create view v_bdf2_user_ as
select `t`.`USERNAME_`                                          AS `USERNAME_`,
       `t`.`ADDRESS_`                                           AS `ADDRESS_`,
       `t`.`ADMINISTRATOR_`                                     AS `ADMINISTRATOR_`,
       `t`.`BIRTHDAY_`                                          AS `BIRTHDAY_`,
       `t`.`CNAME_`                                             AS `CNAME_`,
       `t`.`COMPANY_ID_`                                        AS `COMPANY_ID_`,
       `t`.`CREATE_DATE_`                                       AS `CREATE_DATE_`,
       `t`.`EMAIL_`                                             AS `EMAIL_`,
       `t`.`ENABLED_`                                           AS `ENABLED_`,
       `t`.`ENAME_`                                             AS `ENAME_`,
       `t`.`MALE_`                                              AS `MALE_`,
       `t`.`MOBILE_`                                            AS `MOBILE_`,
       `t`.`PASSWORD_`                                          AS `PASSWORD_`,
       `t`.`SALT_`                                              AS `SALT_`,
       `t`.`dept_id`                                            AS `dept_id`,
       `t`.`dept_name`                                          AS `dept_name`,
       `t`.`position_id`                                        AS `position_id`,
       `t`.`position_name`                                      AS `position_name`,
       group_concat(distinct `t`.`dept_id` separator ',')       AS `dept_id_`,
       group_concat(distinct `t`.`dept_name` separator ',')     AS `dept_name_`,
       group_concat(distinct `t`.`position_id` separator ',')   AS `position_id_`,
       group_concat(distinct `t`.`position_name` separator ',') AS `position_name_`,
       `q`.`role_name`                                          AS `role_name_`,
       `q`.`role_id`                                            AS `role_id`
from (`pms_product`.`v_bdf2_user` `t`
         left join `pms_product`.`v_role_member_user_` `q` on ((`t`.`USERNAME_` = `q`.`user_name`)))
group by `t`.`dept_name` desc, `t`.`USERNAME_`;

