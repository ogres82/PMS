create definer = pms_admin@`%` trigger chargeNoCreate_copy1
    before insert
    on t_charge_info_190402
    for each row
begin
set new.charge_no=CONCAT('ZD',DATE_FORMAT(now(),'%Y%m%d'),LPAD(seq_nextval('charge_seq'),6,'0'));
end;

