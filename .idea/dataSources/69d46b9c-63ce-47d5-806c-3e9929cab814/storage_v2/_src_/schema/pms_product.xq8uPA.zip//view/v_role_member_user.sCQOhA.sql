create view v_role_member_user as
select `a`.`ID_`          AS `ID_`,
       `a`.`CREATE_DATE_` AS `CREATE_DATE_`,
       `a`.`DEPT_ID_`     AS `DEPT_ID_`,
       `a`.`GRANTED_`     AS `GRANTED_`,
       `a`.`POSITION_ID_` AS `POSITION_ID_`,
       `a`.`ROLE_ID_`     AS `ROLE_ID_`,
       `a`.`USERNAME_`    AS `USERNAME_`,
       `a`.`GROUP_ID_`    AS `GROUP_ID_`,
       `b`.`CNAME_`       AS `CNAME_`
from (`pms_product`.`bdf2_user` `b`
         left join `pms_product`.`bdf2_role_member` `a` on ((`a`.`USERNAME_` = `b`.`USERNAME_`)));

