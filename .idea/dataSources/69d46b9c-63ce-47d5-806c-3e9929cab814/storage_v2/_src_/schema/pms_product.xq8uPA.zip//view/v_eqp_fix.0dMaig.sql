create view v_eqp_fix as
select `a`.`fix_rec_id`      AS `fix_rec_id`,
       `a`.`eqp_id`          AS `eqp_id`,
       `b`.`eqp_name`        AS `eqp_name`,
       `a`.`eqp_fix_content` AS `eqp_fix_content`,
       `a`.`eqp_fix_date`    AS `eqp_fix_date`,
       `a`.`eqp_fix_detail`  AS `eqp_fix_detail`,
       `a`.`eqp_fix_endDate` AS `eqp_fix_endDate`,
       `a`.`eqp_fix_fee`     AS `eqp_fix_fee`,
       `a`.`eqp_fix_person`  AS `eqp_fix_person`,
       `a`.`eqp_fix_time`    AS `eqp_fix_time`,
       `a`.`eqp_handl_res`   AS `eqp_handl_res`
from (`pms_product`.`t_eqp_fix_rec` `a`
         left join `pms_product`.`t_eqp_file` `b` on ((`a`.`eqp_id` = `b`.`eqp_id`)));

