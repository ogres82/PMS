create view v_report_housework as
select `c`.`community_id`       AS `community_id`,
       `c`.`community_name`     AS `community_name`,
       `c`.`storied_build_id`   AS `storied_build_id`,
       `c`.`storied_build_name` AS `storied_build_name`,
       `c`.`room_id`            AS `room_id`,
       `c`.`room_no`            AS `room_no`,
       '家政服务'                   AS `type`,
       '2'                      AS `event_type`,
       `b`.`accept_time`        AS `accept_time`,
       `a`.`id`                 AS `id`,
       `a`.`send_no`            AS `send_no`,
       `a`.`event_id`           AS `event_id`,
       `a`.`oper_id`            AS `oper_id`,
       `a`.`send_time`          AS `send_time`,
       `a`.`arrv_time`          AS `arrv_time`,
       `a`.`delete_time`        AS `delete_time`,
       `a`.`send_state`         AS `send_state`,
       `a`.`handle_content`     AS `handle_content`,
       `a`.`oper_name`          AS `oper_name`,
       `a`.`houseKeepingPay`    AS `houseKeepingPay`,
       `d`.`visit_evaluate`     AS `visit_evaluate`
from (((`pms_product`.`t_housework_dispatch` `a` left join `pms_product`.`t_housework_event` `b` on ((`a`.`event_id` = `b`.`id`))) left join `pms_product`.`t_housework_visit` `d` on ((`b`.`id` = `d`.`event_id`)))
         left join `pms_product`.`v_area_build_house_owner_rela` `c` on ((`b`.`room_id` = `c`.`room_id`)));

-- comment on column v_report_housework.community_id not supported: 小区ID

-- comment on column v_report_housework.community_name not supported: 小区名称 例：西湖御景、依山云墅

-- comment on column v_report_housework.storied_build_id not supported: 楼栋ID

-- comment on column v_report_housework.storied_build_name not supported: 楼栋名称 例：独栋、001栋

-- comment on column v_report_housework.room_id not supported: 房间ID

-- comment on column v_report_housework.room_no not supported: 房间号

