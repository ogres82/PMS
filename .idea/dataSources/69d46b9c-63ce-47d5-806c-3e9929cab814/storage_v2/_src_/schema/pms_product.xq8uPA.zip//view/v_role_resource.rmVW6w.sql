create view v_role_resource as
select `a`.`ROLE_ID_`        AS `ROLE_ID_`,
       `b`.`ID_`             AS `ID_`,
       `b`.`COMPANY_ID_`     AS `COMPANY_ID_`,
       `b`.`DESC_`           AS `DESC_`,
       `b`.`FOR_NAVIGATION_` AS `FOR_NAVIGATION_`,
       `b`.`ICON_`           AS `ICON_`,
       `b`.`NAME_`           AS `NAME_`,
       `b`.`ORDER_`          AS `ORDER_`,
       `b`.`PARENT_ID_`      AS `PARENT_ID_`,
       `b`.`SYSTEM_ID_`      AS `SYSTEM_ID_`,
       `b`.`URL_`            AS `URL_`
from (`pms_product`.`bdf2_url` `b`
         left join `pms_product`.`bdf2_role_resource` `a` on ((`a`.`URL_ID_` = `b`.`ID_`)));

