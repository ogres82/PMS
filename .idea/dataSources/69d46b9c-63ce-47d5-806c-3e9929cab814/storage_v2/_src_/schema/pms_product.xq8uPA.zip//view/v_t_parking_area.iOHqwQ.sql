create view v_t_parking_area as
select `c`.`build_id`       AS `build_id`,
       `c`.`build_name`     AS `build_name`,
       `b`.`community_name` AS `community_name`,
       `a`.`park_id`        AS `park_id`,
       `a`.`belong_com_id`  AS `belong_com_id`,
       `a`.`park_name`      AS `park_name`,
       `a`.`remark`         AS `remark`,
       `a`.`park_code`      AS `park_code`,
       `a`.`park_position`  AS `park_position`,
       `a`.`park_state`     AS `park_state`,
       `a`.`using_date`     AS `using_date`,
       `a`.`floors`         AS `floors`,
       `a`.`park_num`       AS `park_num`
from ((`pms_product`.`t_parking_area` `a` left join `pms_product`.`t_area_property` `b` on ((`b`.`community_id` = `a`.`belong_com_id`)))
         left join `pms_product`.`t_all_area` `c` on ((`c`.`build_id` = `b`.`belong_build_id`)));

-- comment on column v_t_parking_area.build_id not supported: 楼盘ID

-- comment on column v_t_parking_area.build_name not supported: 楼盘名称  例：乐湾国际城一期

-- comment on column v_t_parking_area.community_name not supported: 小区名称 例：西湖御景、依山云墅

-- comment on column v_t_parking_area.park_id not supported: 区域ID

-- comment on column v_t_parking_area.belong_com_id not supported: 所属小区ID

-- comment on column v_t_parking_area.park_name not supported: 区域名称

-- comment on column v_t_parking_area.remark not supported: 备注

