create view v_charge_serial_info as
select `t`.`community_name`                                       AS `community_name`,
       `t`.`room_type`                                            AS `room_type`,
       `t`.`storied_build_name`                                   AS `storied_build_name`,
       `t`.`serial_id`                                            AS `serial_id`,
       `t`.`advance_amount`                                       AS `advance_amount`,
       `t`.`charge_type_name`                                     AS `charge_type_name`,
       `t`.`charge_type_no`                                       AS `charge_type_no`,
       `t`.`delete_id`                                            AS `delete_id`,
       `t`.`oper_emp_id`                                          AS `oper_emp_id`,
       ''                                                         AS `oper_emp_name`,
       `t`.`owner_name`                                           AS `owner_name`,
       `t`.`owner_id`                                             AS `owner_id`,
       `t`.`paid_amount`                                          AS `paid_amount`,
       `t`.`paid_date`                                            AS `paid_date`,
       `t`.`paid_mode`                                            AS `paid_mode`,
       `t`.`receive_amount`                                       AS `receive_amount`,
       `t`.`remark`                                               AS `remark`,
       `t`.`room_id`                                              AS `room_id`,
       `t`.`room_no`                                              AS `room_no`,
       `t`.`serial_no`                                            AS `serial_no`,
       `t`.`state`                                                AS `state`,
       `t`.`update_date`                                          AS `update_date`,
       `t`.`charge_type`                                          AS `charge_type`,
       `t`.`begin_date`                                           AS `begin_date`,
       `t`.`end_date`                                             AS `end_date`,
       `t`.`charge_info_id`                                       AS `charge_info_id`,
       `t`.`ticket_mode`                                          AS `ticket_mode`,
       `t`.`get_mount`                                            AS `get_mount`,
       `t`.`odd_mode`                                             AS `odd_mode`,
       `t`.`odd_mount`                                            AS `odd_mount`,
       `t`.`reduce_mount`                                         AS `reduce_mount`,
       `t`.`reduce_mode`                                          AS `reduce_mode`,
       `t`.`receipt_id`                                           AS `receipt_id`,
       `t`.`reduce_url`                                           AS `reduce_url`,
       `t`.`is_del`                                               AS `is_del`,
       `getDropdownName`('charge_paid_mode', `t`.`paid_mode`)     AS `drop_paid_mode`,
       `getDropdownName`('charge_serial_state', `t`.`state`)      AS `drop_state`,
       `getDropdownName`('charge_serial_type', `t`.`charge_type`) AS `drop_charge_type`,
       `getDropdownName`('charge_ticket_mode', `t`.`ticket_mode`) AS `drop_ticket_mode`,
       `getDropdownName`('charge_odd_mode', `t`.`odd_mode`)       AS `drop_odd_mode`
from `pms_product`.`t_charge_serial_info` `t`
where (`t`.`is_del` = '0');

-- comment on column v_charge_serial_info.community_name not supported: 小区名称

-- comment on column v_charge_serial_info.room_type not supported: 房间类型

-- comment on column v_charge_serial_info.storied_build_name not supported: 楼宇名称

-- comment on column v_charge_serial_info.paid_amount not supported: 实收金额

-- comment on column v_charge_serial_info.paid_date not supported: 付款日期

-- comment on column v_charge_serial_info.paid_mode not supported: 付款方式

-- comment on column v_charge_serial_info.receive_amount not supported: 应收金额

-- comment on column v_charge_serial_info.state not supported: 收支状态01:收入02：支出

-- comment on column v_charge_serial_info.ticket_mode not supported: 开票方式 01发票，02收据

-- comment on column v_charge_serial_info.get_mount not supported: 前台收到金额（或许找零）

-- comment on column v_charge_serial_info.odd_mode not supported: 找零方式(01找零，02转预存)

-- comment on column v_charge_serial_info.odd_mount not supported: 找零金额

-- comment on column v_charge_serial_info.reduce_mount not supported: 优惠金额

-- comment on column v_charge_serial_info.reduce_mode not supported: 优惠方式（待定）

-- comment on column v_charge_serial_info.receipt_id not supported: 收据号

-- comment on column v_charge_serial_info.reduce_url not supported: 减免证明

-- comment on column v_charge_serial_info.is_del not supported: 1：删除；0：未删除

