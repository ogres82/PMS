create view t_r_assign_newvisit as
select `t`.`rpt_kid`                                                    AS `rpt_kid`,
       `t`.`rpt_id`                                                     AS `rpt_id`,
       `t`.`rpt_name`                                                   AS `rpt_name`,
       `t`.`in_call`                                                    AS `in_call`,
       `t`.`addres`                                                     AS `addres`,
       `t`.`event_type`                                                 AS `event_type`,
       `t`.`event_source`                                               AS `event_source`,
       `t`.`event_type_name`                                            AS `event_type_name`,
       `t`.`event_source_name`                                          AS `event_source_name`,
       `t`.`dispatch_status`                                            AS `dispatch_status`,
       `t`.`dispatch_handle_id`                                         AS `dispatch_handle_id`,
       `t`.`dispatch_id`                                                AS `dispatch_id`,
       `t`.`dispatch_status_name`                                       AS `dispatch_status_name`,
       `t`.`createTime`                                                 AS `createTime`,
       `t`.`dispatch_result`                                            AS `dispatch_result`,
       `t`.`createby`                                                   AS `createby`,
       `t`.`createby_name`                                              AS `createby_name`,
       (select distinct `pms_product`.`t_charge_info`.`state`
        from `pms_product`.`t_charge_info`
        where (`t`.`rpt_id` = `pms_product`.`t_charge_info`.`work_id`)) AS `state`
from `pms_product`.`v_r_t_assign_visit` `t`
order by `t`.`rpt_id`;

