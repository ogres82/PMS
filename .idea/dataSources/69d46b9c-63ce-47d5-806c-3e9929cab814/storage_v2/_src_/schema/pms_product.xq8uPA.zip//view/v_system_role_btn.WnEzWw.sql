create view v_system_role_btn as
select `a`.`btn_id`  AS `btn_id`,
       `a`.`name`    AS `name`,
       `a`.`role_id` AS `role_id`,
       `a`.`url_id`  AS `url_id`,
       `a`.`order_`  AS `order_`,
       `b`.`URL_`    AS `URL_`
from (`pms_product`.`system_role_btn` `a`
         left join `pms_product`.`bdf2_url` `b` on ((`a`.`url_id` = `b`.`ID_`)));

