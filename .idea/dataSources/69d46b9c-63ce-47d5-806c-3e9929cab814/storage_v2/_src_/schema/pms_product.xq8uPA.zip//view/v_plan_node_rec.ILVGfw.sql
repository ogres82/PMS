create view v_plan_node_rec as
select `a`.`patrol_rec_id`                                                             AS `patrol_rec_id`,
       `a`.`patrol_node_id`                                                            AS `patrol_node_id`,
       `b`.`patrol_plan_id`                                                            AS `patrol_plan_id`,
       (select `pms_product`.`t_patrol_plan`.`plan_name`
        from `pms_product`.`t_patrol_plan`
        where (`b`.`patrol_plan_id` = `pms_product`.`t_patrol_plan`.`patrol_plan_id`)) AS `plan_name`,
       (select `pms_product`.`t_patrol_node`.`patrol_node_name`
        from `pms_product`.`t_patrol_node`
        where (`a`.`patrol_node_id` = `pms_product`.`t_patrol_node`.`patrol_node_id`)) AS `patrol_node_name`,
       `a`.`patrol_user_id`                                                            AS `patrol_user_id`,
       (select `pms_product`.`bdf2_user`.`CNAME_`
        from `pms_product`.`bdf2_user`
        where (`pms_product`.`bdf2_user`.`USERNAME_` = `a`.`patrol_user_id`))          AS `patrol_user_name`,
       `a`.`patrol_content`                                                            AS `patrol_content`,
       `a`.`insert_time`                                                               AS `insert_time`,
       date_format(from_unixtime((`a`.`insert_time` / 1000)), '%Y-%m-%d')              AS `query_date`
from (`pms_product`.`t_patrol_node_rec` `a`
         left join `pms_product`.`t_patrol_plan_node` `b` on ((`a`.`patrol_node_id` = `b`.`patrol_node_id`)))
order by `b`.`patrol_plan_id`, `a`.`insert_time` desc;

-- comment on column v_plan_node_rec.patrol_rec_id not supported: 巡更记录ID

-- comment on column v_plan_node_rec.patrol_node_id not supported: 巡更计划ID

-- comment on column v_plan_node_rec.patrol_plan_id not supported: 计划ID

-- comment on column v_plan_node_rec.patrol_user_id not supported: 巡更人

-- comment on column v_plan_node_rec.patrol_content not supported: 巡更内容

-- comment on column v_plan_node_rec.insert_time not supported: 插入时间

