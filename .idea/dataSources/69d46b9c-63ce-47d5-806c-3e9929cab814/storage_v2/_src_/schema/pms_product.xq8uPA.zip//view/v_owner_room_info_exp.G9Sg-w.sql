create view v_owner_room_info_exp as
select `a`.`owner_id`                AS `owner_id`,
       `c`.`room_id`                 AS `room_id`,
       `c`.`community_id`            AS `community_id`,
       `c`.`belong_sb_id`            AS `belong_sb_id`,
       `a`.`owner_name`              AS `owner_name`,
       `a`.`phone`                   AS `phone`,
       `a`.`card_id`                 AS `card_id`,
       `a`.`car_id`                  AS `car_id`,
       `a`.`emergency_contact`       AS `emergency_contact`,
       `a`.`emergency_contact_phone` AS `emergency_contact_phone`,
       `c`.`community_name`          AS `community_name`,
       `c`.`storied_build_name`      AS `storied_build_name`,
       `c`.`receive_room_date`       AS `receive_room_date`,
       `c`.`make_room_date`          AS `make_room_date`,
       `c`.`room_no`                 AS `room_no`,
       `c`.`room_state`              AS `room_state`,
       `c`.`room_type`               AS `room_type`,
       `c`.`build_area`              AS `build_area`,
       `c`.`within_area`             AS `within_area`
from ((`pms_product`.`t_property_owner` `a` left join `pms_product`.`t_house_owner` `b` on ((`a`.`owner_id` = `b`.`owner_id`)))
         left join `pms_product`.`t_house_property` `c` on ((`b`.`room_id` = `c`.`room_id`)))
where (`a`.`owner_identity` = '0');

-- comment on column v_owner_room_info_exp.owner_id not supported: 业主ID

-- comment on column v_owner_room_info_exp.room_id not supported: 房间ID

-- comment on column v_owner_room_info_exp.community_id not supported: 小区ID

-- comment on column v_owner_room_info_exp.belong_sb_id not supported: 所属楼栋ID

-- comment on column v_owner_room_info_exp.owner_name not supported: 业主姓名

-- comment on column v_owner_room_info_exp.phone not supported: 手机号

-- comment on column v_owner_room_info_exp.card_id not supported: 身份证号

-- comment on column v_owner_room_info_exp.car_id not supported: 车辆ID

-- comment on column v_owner_room_info_exp.emergency_contact not supported: 紧急联系人及电话

-- comment on column v_owner_room_info_exp.emergency_contact_phone not supported: 紧急人联系电话

-- comment on column v_owner_room_info_exp.community_name not supported: 小区名称

-- comment on column v_owner_room_info_exp.storied_build_name not supported: 楼栋名称

-- comment on column v_owner_room_info_exp.receive_room_date not supported: 业主实际收房日期

-- comment on column v_owner_room_info_exp.make_room_date not supported: 收房日期（地产通知收房的日期）

-- comment on column v_owner_room_info_exp.room_no not supported: 房间号

-- comment on column v_owner_room_info_exp.room_state not supported: 房间状态 0未售1交房2接房3入住4出租

-- comment on column v_owner_room_info_exp.room_type not supported: 房间类型 0高层1洋房2别墅

-- comment on column v_owner_room_info_exp.build_area not supported: 建筑面积

-- comment on column v_owner_room_info_exp.within_area not supported: 套内面积

