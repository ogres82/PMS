create view v_toptasklist as
select `t`.`rpt_id`            AS `rpt_id`,
       `t`.`createTime`        AS `createTime`,
       `t`.`createby`          AS `createby`,
       `t`.`address`           AS `address`,
       '0.00'                  AS `dispatch_expense`,
       `tm`.`comp_operator_id` AS `comp_operator_id`,
       `t`.`event_state`       AS `event_state`,
       '咨询建议'                  AS `type_name`,
       `t`.`event_content`     AS `event_content`
from (`pms_product`.`t_r_maintain` `t`
         join `pms_product`.`t_r_maintain_complaint` `tm`)
where ((`t`.`rpt_id` = `tm`.`mtn_id`) and (`t`.`event_state` not in (0, 3, 4, 5)))
union all
select `t`.`rpt_id`                       AS `rpt_id`,
       `t`.`createTime`                   AS `createTime`,
       `t`.`createby`                     AS `createby`,
       `t`.`address`                      AS `address`,
       format(`td`.`dispatch_expense`, 2) AS `dispatch_expense`,
       `td`.`dispatch_handle_id`          AS `comp_operator_id`,
       `t`.`event_state`                  AS `event_state`,
       '报障报修'                             AS `type_name`,
       `t`.`event_content`                AS `event_content`
from (`pms_product`.`t_r_maintain` `t`
         join `pms_product`.`t_r_maintain_dispatch` `td`)
where ((`t`.`rpt_id` = `td`.`mtn_id`) and (`t`.`event_state` not in (0, 3, 4, 5)))
union all
select `t`.`event_no`                     AS `event_no`,
       `t`.`accept_time`                  AS `accept_time`,
       `t`.`verify_oper_id`               AS `verify_oper_id`,
       `t`.`user_address`                 AS `user_address`,
       format(`dis`.`houseKeepingPay`, 2) AS `houseKeepingPay`,
       `dis`.`oper_id`                    AS `oper_id`,
       `t`.`event_state`                  AS `event_state`,
       '家政服务'                             AS `type_name`,
       `t`.`event_content`                AS `event_content`
from (`pms_product`.`t_housework_event` `t`
         join `pms_product`.`t_housework_dispatch` `dis`)
where ((`t`.`id` = `dis`.`event_id`) and (`t`.`event_state` not in (0, 3, 4, 5)))
union all
select `t`.`ntc_no`          AS `rpt_id`,
       `t`.`ntc_create_time` AS `createTime`,
       `t`.`ntc_creator`     AS `createby`,
       `t`.`ntc_subject`     AS `address`,
       ''                    AS `houseKeepingPay`,
       `t`.`ntc_auditor`     AS `comp_operator_id`,
       `t`.`ntc_status`      AS `event_state`,
       '公告审核'                AS `type_name`,
       `t`.`ntc_creator`     AS `event_content`
from `pms_product`.`t_msgandnotice_ntc` `t`
where ((`t`.`ntc_status` = 20) or (`t`.`ntc_status` = 22));

