create view v_system_btn_url as
select `b`.`NAME_`    AS `page_name`,
       `a`.`id`       AS `id`,
       `a`.`url_id`   AS `url_id`,
       `a`.`url_name` AS `url_name`,
       `a`.`btn_id`   AS `btn_id`,
       `a`.`btn_name` AS `btn_name`,
       `a`.`order_`   AS `order_`
from (`pms_product`.`system_btn_url` `a`
         left join `pms_product`.`bdf2_url` `b` on ((`a`.`url_id` = `b`.`ID_`)))
order by `b`.`NAME_`, `a`.`order_`;

