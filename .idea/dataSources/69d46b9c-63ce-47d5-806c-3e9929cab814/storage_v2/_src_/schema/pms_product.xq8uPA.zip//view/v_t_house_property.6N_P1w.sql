create view v_t_house_property as
select `a`.`build_id`                                                                              AS `build_id`,
       `a`.`build_name`                                                                            AS `build_name`,
       `a`.`community_id`                                                                          AS `community_id`,
       `a`.`community_name`                                                                        AS `community_name`,
       `a`.`belong_sb_id`                                                                          AS `belong_sb_id`,
       `a`.`storied_build_name`                                                                    AS `storied_build_name`,
       `a`.`unit_id`                                                                               AS `unit_id`,
       `a`.`unit_name`                                                                             AS `unit_name`,
       `a`.`room_id`                                                                               AS `room_id`,
       `a`.`room_no`                                                                               AS `room_no`,
       `a`.`house_type`                                                                            AS `house_type`,
       `a`.`build_area`                                                                            AS `build_area`,
       `a`.`within_area`                                                                           AS `within_area`,
       `a`.`room_type`                                                                             AS `room_type`,
       `a`.`room_state`                                                                            AS `room_state`,
       `a`.`charge_object`                                                                         AS `charge_object`,
       `a`.`remark`                                                                                AS `remark`,
       `a`.`advance_amount`                                                                        AS `advance_amount`,
       `a`.`make_room_date`                                                                        AS `make_room_date`,
       `a`.`decorate_start_date`                                                                   AS `decorate_start_date`,
       `a`.`decorate_end_date`                                                                     AS `decorate_end_date`,
       `a`.`receive_room_date`                                                                     AS `receive_room_date`,
       `a`.`decorate_plan_date`                                                                    AS `decorate_plan_date`,
       `a`.`room_decorate_status`                                                                  AS `room_decorate_status`,
       `a`.`decorate_instructions`                                                                 AS `decorate_instructions`,
       (select `e`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `e`
        where ((`e`.`code` = 'room_type') and (`e`.`code_detail` = `a`.`room_type`)))              AS `room_type_name`,
       (select `f`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `f`
        where ((`f`.`code` = 'room_state') and (`f`.`code_detail` = `a`.`room_state`)))            AS `room_state_name`,
       (select `g`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `g`
        where ((`g`.`code` = 'room_charge_object') and
               (`g`.`code_detail` = `a`.`charge_object`)))                                         AS `charge_object_name`,
       `a`.`lz_id`                                                                                 AS `lz_id`
from `pms_product`.`t_house_property` `a`
where (`a`.`is_del` = '0');

-- comment on column v_t_house_property.build_id not supported: 楼盘ID

-- comment on column v_t_house_property.build_name not supported: 楼盘名称

-- comment on column v_t_house_property.community_id not supported: 小区ID

-- comment on column v_t_house_property.community_name not supported: 小区名称

-- comment on column v_t_house_property.belong_sb_id not supported: 所属楼栋ID

-- comment on column v_t_house_property.storied_build_name not supported: 楼栋名称

-- comment on column v_t_house_property.unit_id not supported: 单元ID

-- comment on column v_t_house_property.unit_name not supported: 单元名称

-- comment on column v_t_house_property.room_id not supported: 房间ID

-- comment on column v_t_house_property.room_no not supported: 房间号

-- comment on column v_t_house_property.house_type not supported: 户型  例：A户型、B户型

-- comment on column v_t_house_property.build_area not supported: 建筑面积

-- comment on column v_t_house_property.within_area not supported: 套内面积

-- comment on column v_t_house_property.room_type not supported: 房间类型 0高层1洋房2别墅

-- comment on column v_t_house_property.room_state not supported: 房间状态 0未售1交房2接房3入住4出租

-- comment on column v_t_house_property.charge_object not supported: 收费对象 0业主1租户2其他

-- comment on column v_t_house_property.remark not supported: 备注

-- comment on column v_t_house_property.make_room_date not supported: 收房日期（地产通知收房的日期）

-- comment on column v_t_house_property.decorate_start_date not supported: 装修开始日期

-- comment on column v_t_house_property.decorate_end_date not supported: 装修结束时间

-- comment on column v_t_house_property.receive_room_date not supported: 业主实际收房日期

-- comment on column v_t_house_property.decorate_plan_date not supported: 装修拟结束时间

