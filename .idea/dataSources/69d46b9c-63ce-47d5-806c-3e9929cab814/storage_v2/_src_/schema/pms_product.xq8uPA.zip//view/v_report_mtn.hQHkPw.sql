create view v_report_mtn as
select `c`.`community_id`             AS `community_id`,
       `c`.`community_name`           AS `community_name`,
       `c`.`storied_build_id`         AS `storied_build_id`,
       `c`.`storied_build_name`       AS `storied_build_name`,
       `c`.`room_id`                  AS `room_id`,
       `c`.`room_no`                  AS `room_no`,
       `d`.`code_detail_name`         AS `code_detail_name`,
       `b`.`event_type`               AS `event_type`,
       `b`.`createTime`               AS `rpt_time`,
       `a`.`dispatch_kid`             AS `dispatch_kid`,
       `a`.`createTime`               AS `createTime`,
       `a`.`createby`                 AS `createby`,
       `a`.`dispatch_arrive_time`     AS `dispatch_arrive_time`,
       `a`.`dispatch_degree`          AS `dispatch_degree`,
       `a`.`dispatch_expense`         AS `dispatch_expense`,
       `a`.`dispatch_finish_time`     AS `dispatch_finish_time`,
       `a`.`dispatch_handle_id`       AS `dispatch_handle_id`,
       `a`.`dispatch_handle_name`     AS `dispatch_handle_name`,
       `a`.`dispatch_id`              AS `dispatch_id`,
       `a`.`dispatch_result`          AS `dispatch_result`,
       `a`.`dispatch_sl_time`         AS `dispatch_sl_time`,
       `a`.`dispatch_solve`           AS `dispatch_solve`,
       `a`.`dispatch_status`          AS `dispatch_status`,
       `a`.`dispatch_time`            AS `dispatch_time`,
       `a`.`dispatch_tools`           AS `dispatch_tools`,
       `a`.`dispatch_visit_lev`       AS `dispatch_visit_lev`,
       `a`.`dispatch_visit_record`    AS `dispatch_visit_record`,
       `a`.`dispatch_visit_recording` AS `dispatch_visit_recording`,
       `a`.`mtn_detail`               AS `mtn_detail`,
       `a`.`mtn_emergency`            AS `mtn_emergency`,
       `a`.`mtn_id`                   AS `mtn_id`,
       `a`.`mtn_priority`             AS `mtn_priority`,
       `a`.`mtn_type`                 AS `mtn_type`,
       `a`.`material_cost`            AS `material_cost`,
       `a`.`labor_cost`               AS `labor_cost`
from (((`pms_product`.`t_r_maintain_dispatch` `a` left join `pms_product`.`t_r_maintain` `b` on ((`a`.`mtn_id` = `b`.`rpt_id`))) left join `pms_product`.`v_area_build_house_owner_rela` `c` on ((`b`.`owner_house` = `c`.`room_id`)))
         left join `pms_product`.`dir_directorydetail` `d` on ((`d`.`code_detail` = `b`.`event_type`)))
where (`d`.`code` = 'main_event_type');

-- comment on column v_report_mtn.community_id not supported: 小区ID

-- comment on column v_report_mtn.community_name not supported: 小区名称 例：西湖御景、依山云墅

-- comment on column v_report_mtn.storied_build_id not supported: 楼栋ID

-- comment on column v_report_mtn.storied_build_name not supported: 楼栋名称 例：独栋、001栋

-- comment on column v_report_mtn.room_id not supported: 房间ID

-- comment on column v_report_mtn.room_no not supported: 房间号

