create definer = pms_admin@`%` trigger del_house_owner_refresh
    after delete
    on t_house_owner
    for each row
begin
call pro_refresh_owner_vs_room_id();
end;

