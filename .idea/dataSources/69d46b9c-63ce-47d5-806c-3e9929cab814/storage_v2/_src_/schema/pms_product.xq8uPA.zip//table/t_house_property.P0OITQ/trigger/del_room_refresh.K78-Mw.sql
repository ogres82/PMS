create definer = root@localhost trigger del_room_refresh
    after delete
    on t_house_property
    for each row
begin
call pro_refresh_house_vs_fee();
end;

