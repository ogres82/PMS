create
    definer = pms_admin@`%` function seq_nextval(v_seq_name varchar(50)) returns int
begin    
	update sequence set current_val = current_val + increment_val where seq_name = v_seq_name;     
	return seq_currval(v_seq_name);   
end;

