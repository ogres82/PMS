create view v_event_satisfade as
select (case
            when (isnull(`di`.`dispatch_visit_lev`) or (`di`.`dispatch_visit_lev` = 0)) then '非常满意'
            when (`di`.`dispatch_visit_lev` = 1) then '基本满意'
            else '不满意' end) AS `visit_lev`
from `pms_product`.`t_r_maintain_dispatch` `di`
where (`di`.`dispatch_status` = 5);

