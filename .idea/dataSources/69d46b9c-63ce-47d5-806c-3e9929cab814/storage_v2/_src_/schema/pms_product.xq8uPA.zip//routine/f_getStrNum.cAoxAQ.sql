create
    definer = pms_admin@`%` function f_getStrNum(in_str varchar(500)) returns varchar(30)
BEGIN
DECLARE v_length INT DEFAULT 0;
DECLARE v_Tmp varchar(50) default '';
set v_length=CHAR_LENGTH(in_str);
WHILE v_length > 0 DO
IF (ASCII(mid(in_str,v_length,1))>47 and ASCII(mid(in_str,v_length,1))<58 )   THEN
set v_Tmp=concat(v_Tmp,mid(in_str,v_length,1));
END IF;
SET v_length = v_length - 1;
END WHILE;
RETURN REVERSE(v_Tmp);
END;

