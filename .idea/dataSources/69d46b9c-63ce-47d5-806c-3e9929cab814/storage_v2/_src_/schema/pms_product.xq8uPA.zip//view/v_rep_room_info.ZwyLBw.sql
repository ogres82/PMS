create view v_rep_room_info as
select `q`.`room_id`                                                  AS `room_id`,
       `q`.`build_name`                                               AS `build_name`,
       `q`.`community_name`                                           AS `community_name`,
       (case `q`.`room_type`
            when '2' then `q`.`room_no`
            when '4' then `q`.`room_no`
            else concat(`q`.`storied_build_name`, `q`.`room_no`) end) AS `room_addr`,
       (case `q`.`room_state`
            when '0' then '空置'
            when '1' then '未收'
            when '2' then '已收'
            when '3' then '装修'
            else '入住' end)                                            AS `room_state`,
       (case `q`.`room_type`
            when '0' then '高层'
            when '1' then '洋房'
            when '2' then '别墅'
            when '3' then '空墅'
            else '商铺' end)                                            AS `room_type`,
       `q`.`make_room_date`                                           AS `make_room_date`,
       `q`.`receive_room_date`                                        AS `receive_room_date`,
       `q`.`decorate_start_date`                                      AS `decorate_start_date`,
       `q`.`decorate_end_date`                                        AS `decorate_end_date`,
       `q`.`within_area`                                              AS `within_area`,
       `q`.`build_area`                                               AS `build_area`
from `pms_product`.`t_house_property` `q`
where (`q`.`community_name` <> '测试小区')
order by `q`.`build_name`, `q`.`community_name`, (`q`.`storied_build_name` + 0), (`q`.`room_no` + 0);

-- comment on column v_rep_room_info.room_id not supported: 房间ID

-- comment on column v_rep_room_info.build_name not supported: 楼盘名称

-- comment on column v_rep_room_info.community_name not supported: 小区名称

-- comment on column v_rep_room_info.make_room_date not supported: 收房日期（地产通知收房的日期）

-- comment on column v_rep_room_info.receive_room_date not supported: 业主实际收房日期

-- comment on column v_rep_room_info.decorate_start_date not supported: 装修开始日期

-- comment on column v_rep_room_info.decorate_end_date not supported: 装修结束时间

-- comment on column v_rep_room_info.within_area not supported: 套内面积

-- comment on column v_rep_room_info.build_area not supported: 建筑面积

