create definer = pms_admin@`%` event 根据物业起征日期判断是否开始收费 on schedule
    every '1' DAY
        starts '2019-07-14 00:10:00'
    on completion preserve
    enable
    comment '根据房间绑定的物业费以及收费日期，每天进行判断是否开始计费'
    do
    CALL pro_change_room_charge_state();

