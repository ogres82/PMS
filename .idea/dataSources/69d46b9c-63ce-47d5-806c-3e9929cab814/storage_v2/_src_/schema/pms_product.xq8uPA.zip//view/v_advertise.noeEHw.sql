create view v_advertise as
select `a`.`adv_pos_id`                                                                             AS `a_id`,
       `a`.`adv_pos_code`                                                                           AS `a_code`,
       `a`.`adv_business`                                                                           AS `adv_business`,
       `a`.`adv_business_phone`                                                                     AS `adv_business_phone`,
       `a`.`contract_code`                                                                          AS `contract_code`,
       `a`.`dur_time`                                                                               AS `dur_time`,
       `a`.`price`                                                                                  AS `price`,
       `a`.`adv_memo`                                                                               AS `adv_memo`,
       `a`.`create_by`                                                                              AS `create_by`,
       `a`.`create_time`                                                                            AS `create_time`,
       `p`.`adv_pos_id`                                                                             AS `p_id`,
       `p`.`adv_pos_code`                                                                           AS `p_code`,
       `p`.`adv_position`                                                                           AS `adv_position`,
       `p`.`adv_pos_size`                                                                           AS `adv_pos_size`,
       `p`.`adv_pos_status`                                                                         AS `adv_pos_status`,
       (select `dir`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `dir`
        where ((`dir`.`code` = 'adv_pos_status') and
               (`dir`.`code_detail` = `p`.`adv_pos_status`)))                                       AS `adv_pos_status_name`,
       `p`.`adv_pos_type`                                                                           AS `adv_pos_type`,
       (select `dir`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `dir`
        where ((`dir`.`code` = 'adv_pos_type') and
               (`dir`.`code_detail` = `p`.`adv_pos_type`)))                                         AS `adv_pos_type_name`
from (`pms_product`.`t_advertise_attach` `a`
         join `pms_product`.`t_advertise_position` `p`)
where (`a`.`adv_pos_code` = `p`.`adv_pos_code`);

-- comment on column v_advertise.a_id not supported: 广告位ID

-- comment on column v_advertise.a_code not supported: 广告位编号

-- comment on column v_advertise.adv_business not supported: 广告商

-- comment on column v_advertise.adv_business_phone not supported: 广告商电话

-- comment on column v_advertise.contract_code not supported: 合同编号

-- comment on column v_advertise.dur_time not supported: 时限

-- comment on column v_advertise.price not supported: 价格

-- comment on column v_advertise.p_id not supported: 广告位ID

-- comment on column v_advertise.p_code not supported: 广告位编号

-- comment on column v_advertise.adv_position not supported: 广告位位置

-- comment on column v_advertise.adv_pos_size not supported: 广告位大小

-- comment on column v_advertise.adv_pos_status not supported: 状态

-- comment on column v_advertise.adv_pos_type not supported: 广告位类别

