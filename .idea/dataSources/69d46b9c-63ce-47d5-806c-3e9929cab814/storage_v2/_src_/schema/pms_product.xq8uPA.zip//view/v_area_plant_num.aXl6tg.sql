create view v_area_plant_num as
select `a`.`id` AS `id`, `a`.`area_id` AS `area_id`, `a`.`plant_id` AS `plant_id`, `b`.`plant_name` AS `plant_name`
from (`pms_product`.`t_environment_area_plant` `a`
         left join `pms_product`.`t_environment_plant` `b` on ((`b`.`plant_id` = `a`.`plant_id`)));

-- comment on column v_area_plant_num.area_id not supported: 区域ID

-- comment on column v_area_plant_num.plant_id not supported: 植被ID

-- comment on column v_area_plant_num.plant_name not supported: 植被名称

