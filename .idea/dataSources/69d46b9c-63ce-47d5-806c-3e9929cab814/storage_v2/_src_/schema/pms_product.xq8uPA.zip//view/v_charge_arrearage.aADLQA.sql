create view v_charge_arrearage as
select `i`.`room_id`                                                                               AS `room_id`,
       `r`.`community_name`                                                                        AS `community_name`,
       `r`.`storied_build_name`                                                                    AS `storied_build_name`,
       `r`.`room_type`                                                                             AS `room_type`,
       `i`.`room_no`                                                                               AS `room_no`,
       `o`.`owner_id`                                                                              AS `owner_id`,
       `o`.`owner_name`                                                                            AS `owner_name`,
       `o`.`phone`                                                                                 AS `phone`,
       min(`i`.`begin_time`)                                                                       AS `begin_time`,
       max(`i`.`end_time`)                                                                         AS `end_time`,
       sum((case
                when `i`.`charge_type_no` in (select `pms_product`.`t_charge_type_setting`.`charge_type_no`
                                              from `pms_product`.`t_charge_type_setting`
                                              where (`pms_product`.`t_charge_type_setting`.`type_flag` = '01'))
                    then `i`.`arrearage_amount`
                else 0 end))                                                                       AS `arrearage_amount`,
       sum((case when (`i`.`charge_type_name` = '物业费滞纳金') then `i`.`arrearage_amount` else 0 end)) AS `delay_pay`,
       0                                                                                           AS `reduce_pay`,
       count(1)                                                                                    AS `arrearage_num`,
       sum(`i`.`arrearage_amount`)                                                                 AS `total_pay`
from ((`pms_product`.`t_charge_info` `i` join `pms_product`.`t_property_owner` `o`)
         join `pms_product`.`t_house_property` `r`)
where ((`i`.`owner_id` = `o`.`owner_id`) and (`i`.`room_id` = `r`.`room_id`) and (`o`.`owner_identity` = 0) and
       (`i`.`is_del` = '0') and (`i`.`state` = '03'))
group by `i`.`room_id`;

-- comment on column v_charge_arrearage.community_name not supported: 小区名称

-- comment on column v_charge_arrearage.storied_build_name not supported: 楼栋名称

-- comment on column v_charge_arrearage.room_type not supported: 房间类型 0高层1洋房2别墅

-- comment on column v_charge_arrearage.owner_id not supported: 业主ID

-- comment on column v_charge_arrearage.owner_name not supported: 业主姓名

-- comment on column v_charge_arrearage.phone not supported: 手机号

