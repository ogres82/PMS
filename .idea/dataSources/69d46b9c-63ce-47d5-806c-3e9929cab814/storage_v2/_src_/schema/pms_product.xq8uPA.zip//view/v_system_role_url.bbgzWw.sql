create view v_system_role_url as
select `a`.`ID_`        AS `ID_`,
       `a`.`ROLE_ID_`   AS `ROLE_ID_`,
       `a`.`URL_ID_`    AS `URL_ID_`,
       `b`.`NAME_`      AS `NAME_`,
       `b`.`ORDER_`     AS `ORDER_`,
       `b`.`PARENT_ID_` AS `PARENT_ID_`,
       `b`.`URL_`       AS `URL_`
from (`pms_product`.`bdf2_role_resource` `a`
         left join `pms_product`.`bdf2_url` `b` on ((`a`.`URL_ID_` = `b`.`ID_`)));

