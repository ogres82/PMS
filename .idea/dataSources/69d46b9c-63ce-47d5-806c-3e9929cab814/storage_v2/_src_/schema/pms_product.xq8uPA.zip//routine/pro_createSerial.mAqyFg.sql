create
    definer = pms_admin@`%` procedure pro_createSerial(IN flag int, IN beginDate date, IN endDate date,
                                                       IN belongUnit varchar(50))
BEGIN
	#Routine body goes here...
	-- 需要定义接收游标数据的变量 
  DECLARE v_room_id VARCHAR(50);
	DECLARE v_room_no VARCHAR(50);
	DECLARE v_charge_type_no VARCHAR(50);
	DECLARE v_charge_type_name VARCHAR(50);
	DECLARE v_price DECIMAL(10,2);
	DECLARE v_charge_id VARCHAR(50);
	DECLARE v_begin_date DATETIME;
	DECLARE v_end_date DATETIME;

	-- 先记录两条流水的uuid
	DECLARE v_serial_id VARCHAR(50);
	DECLARE v_serial_id2 VARCHAR(50);

	DECLARE v_arrear_num INT DEFAULT 0;
	DECLARE v_receive_num INT DEFAULT 0;
	DECLARE v_arrear_count DECIMAL(10,2) DEFAULT 0.00;
	DECLARE v_receive_count DECIMAL(10,2) DEFAULT 0.00;

	-- 遍历数据结束标志
  DECLARE done INT DEFAULT FALSE;
  -- 游标 应收记录中查询还没有收款的
  DECLARE cur CURSOR FOR SELECT i.charge_id, i.receive_amount, i.charge_type_no, i.room_id FROM t_charge_info i 
								WHERE i.state != '02' and is_del = '0' ORDER BY i.begin_time;

	-- 将结束标志绑定到游标
  DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' BEGIN SET done = TRUE; SELECT 11; END;
	
	-- 如sql异常,将errno设置为1且后续执行退出
	DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; SELECT 12; END; -- COMMIT;-- 出错处理	

	#手动提交事务
  SET autocommit=0;	
	-- 开启事务
	START TRANSACTION;
  -- 打开游标
  OPEN cur;
  -- 开始循环
  read_loop: LOOP
    -- 提取游标里的数据
    FETCH cur INTO v_charge_id, v_price, v_charge_type_no, v_room_id;
    -- 声明结束的时候
    IF done THEN
			SELECT 21;
      LEAVE read_loop;
    END IF;

			BEGIN
					DECLARE v_advance_amount DECIMAL(10,2) DEFAULT 0.00;
					-- 将结束标志绑定到
					DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' begin SET v_advance_amount = -1.0; END;

					SELECT r.amount INTO v_advance_amount FROM t_charge_type_room_rela r
						WHERE r.room_id=v_room_id and r.charge_type_no=v_charge_type_no and r.is_del = '0';

			-- 没有预存或预存额度不够，生成应收账单
			IF v_advance_amount<v_price THEN 
				-- 更新状态为欠费
				 UPDATE t_charge_info i SET i.state='03', i.arrearage_amount=v_price, i.update_date=SYSDATE() WHERE i.charge_id = v_charge_id;
				SET v_arrear_num = v_arrear_num + 1;
				SET v_arrear_count = v_arrear_count + v_price;
			-- 扣款，生成流水
			ELSE
				set v_serial_id = UUID();
				set v_serial_id2 = UUID();
				-- 生成流水（物业等周期性收费，抵扣为收入）
				 INSERT INTO t_charge_serial_info(serial_id,room_id,room_no,owner_id,owner_name, charge_type_no,charge_type_name,
						charge_type,state,receive_amount,paid_amount,advance_amount,paid_date,paid_mode,oper_emp_id,update_date, begin_date, end_date, charge_info_id,room_type,community_name,storied_build_name)
					 SELECT v_serial_id, t.room_id, t.room_no, t.owner_id, t.owner_name, t.charge_type_no, t.charge_type_name, '01','01',t.receive_amount,t.receive_amount,
					(SELECT r.amount-t.receive_amount FROM t_charge_type_room_rela r WHERE r.room_id=t.room_id and r.charge_type_no=t.charge_type_no) advance_amount, 
					SYSDATE(), '01', 'admin',	SYSDATE(), t.begin_time, t.end_time, t.charge_id,t.room_type,t.community_name,t.storied_build_name FROM t_charge_info t WHERE t.charge_id=v_charge_id;

				-- 插入流水明细
				INSERT INTO t_charge_serial_detail(charge_serial_id,charge_id,update_date) VALUES(v_serial_id, v_charge_id, SYSDATE());

				-- 生成流水(预收，状态为支出)
				
				 INSERT INTO t_charge_serial_info(serial_id,room_id,room_no,owner_id,owner_name, charge_type_no,charge_type_name,
						charge_type,state,receive_amount,paid_amount,advance_amount,paid_date,paid_mode,oper_emp_id,update_date, begin_date, end_date, charge_info_id,room_type,community_name,storied_build_name)
						SELECT v_serial_id2, t.room_id, t.room_no, t.owner_id, t.owner_name, t.charge_type_no, t.charge_type_name, '03','02',t.receive_amount,t.receive_amount,
					(SELECT r.amount-t.receive_amount FROM t_charge_type_room_rela r WHERE r.room_id=t.room_id and r.charge_type_no=t.charge_type_no) advance_amount, 
					SYSDATE(), '01', 'admin',	SYSDATE(), t.begin_time, t.end_time, t.charge_id,t.room_type,t.community_name,t.storied_build_name FROM t_charge_info t WHERE t.charge_id=v_charge_id;


					-- 插入流水明细
				INSERT INTO t_charge_serial_detail(charge_serial_id,charge_id,update_date) VALUES(v_serial_id2, v_charge_id, SYSDATE());

					-- 更新押金余额
					UPDATE t_charge_type_room_rela r SET r.amount=r.amount-v_price
							WHERE r.room_id=v_room_id and r.charge_type_no=v_charge_type_no;
					-- 更新状态为已收
					UPDATE t_charge_info i SET i.state='02', i.paid_amount=v_price, i.paid_date=SYSDATE(), i.paid_mode='01' WHERE i.charge_id = v_charge_id;

					SET v_receive_num = v_receive_num + 1;
					SET v_receive_count = v_receive_count + v_price;
			END IF;
			
			

	END;

  END LOOP read_loop;

	-- 生成日志
	INSERT INTO T_OVERALL_LOG(user_id,log_date,logger,log_level,message) VALUES('admin',now(),'数据库后台','INFO',
								CONCAT('生成欠费账单-- 数量:',v_arrear_num, ', 金额：', v_arrear_count));
	INSERT INTO T_OVERALL_LOG(user_id,log_date,logger,log_level,message) VALUES('admin',now(),'数据库后台','INFO',
									CONCAT('收款（预收抵扣）-- 数量:',v_receive_num, ', 金额：', v_receive_count));
  -- 关闭游标
	COMMIT;
  CLOSE cur;
SELECT 24;

END;

