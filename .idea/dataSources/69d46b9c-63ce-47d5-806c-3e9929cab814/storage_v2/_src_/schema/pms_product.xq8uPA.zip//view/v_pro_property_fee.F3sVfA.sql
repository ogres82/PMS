create view v_pro_property_fee as
select `a`.`room_id`                                                  AS `room_id`,
       `b`.`charge_type_no`                                           AS `charge_type_no`,
       `b`.`charge_type_name`                                         AS `charge_type_name`,
       `a`.`begin_time`                                               AS `begin_time`,
       `a`.`end_time`                                                 AS `end_time`,
       ifnull(`a`.`paid_date`, `a`.`begin_time`)                      AS `paid_date`,
       ifnull(`a`.`paid_amount`, 0)                                   AS `paid_amount`,
       `a`.`receive_amount`                                           AS `receive_amount`,
       (case `a`.`state` when '02' then '1' else '0' end)             AS `state`,
       date_format(ifnull(`a`.`paid_date`, `a`.`begin_time`), '%Y%m') AS `paid_month`
from (`pms_product`.`t_charge_info` `a`
         join `pms_product`.`t_charge_type_setting` `b`)
where ((`a`.`charge_type_no` = `b`.`charge_type_no`) and (`b`.`type_flag` = '01'));

