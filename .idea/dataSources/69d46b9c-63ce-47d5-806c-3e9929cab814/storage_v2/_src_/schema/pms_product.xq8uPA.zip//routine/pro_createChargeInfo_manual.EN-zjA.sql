create
    definer = pms_admin@`%` procedure pro_createChargeInfo_manual(IN in_begin_date date, IN in_end_date date,
                                                                  IN in_room_id varchar(100),
                                                                  IN in_oper_id varchar(100))
BEGIN
	#Routine body goes here

	DECLARE begin_date,end_date date DEFAULT CURDATE(); 
	DECLARE t_error,cur_day,month_days,isExist int DEFAULT 0;    
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;
	

	
	set cur_day = day(in_begin_date);
	set month_days = DAYOFMONTH(LAST_DAY(in_begin_date));
	set in_end_date = if(in_end_date='0000-00-00',CURDATE(),in_end_date);
	
	##判断起征日期是否为当月1号,或者不是月末暂时定义小于3天都需要正常收费
  if(cur_day=1 or cur_day+3< month_days ) then
		set begin_date =in_begin_date;
  else 
		set in_begin_date = DATE_ADD(in_begin_date,INTERVAL 1 MONTH); 
		set begin_date = date_add(in_begin_date, interval - day(in_begin_date) + 1 day); #获取当月第一天
  end if;
   
  ##比较开始日期是否小于当前时间
	if(DATE_FORMAT(in_begin_date,'%Y%m')>DATE_FORMAT(CURDATE(),'%Y%m')) then
		SET t_error=1;
	else
	
  START TRANSACTION; 
	
	WHILE DATE_FORMAT(begin_date,'%Y%m')<=DATE_FORMAT(if(CURDATE()>=in_end_date,in_end_date,CURDATE()),'%Y%m')#判断循环次数   
	DO  
   
		#判断账单是否存在，存在就不插入，但是存在用户如果更换物业费类型，无法判断账单是否存	
		IF EXISTS (
					SELECT
						1 
					FROM
						t_charge_info a,
						v_charge_build_area b 
					WHERE
						a.room_id = b.room_id 
						AND a.charge_type_no = b.charge_type_no 
						AND a.begin_time = DATE_FORMAT( begin_date, '%Y-%m-%d' ) 
						AND a.room_id = in_room_id 
						LIMIT 1 
						) THEN
			SET isExist=1;
		ELSE
			SET isExist=0;
		END IF;
		
		if(isExist=1) then 
			##修改变量执行运算下个月时间
			set in_begin_date = DATE_ADD(in_begin_date,INTERVAL 1 MONTH);  
			set begin_date = date_add(in_begin_date, interval - day(in_begin_date) + 1 day); #获取本月第一天
			set end_date= last_day(in_begin_date); #获取本月最后一天
		else 	
		set end_date = date_sub(date_sub(date_format(begin_date, '%y-%m-%d'),interval extract(day from begin_date) day), interval - 1 month);
			INSERT INTO t_charge_info (
				charge_id,
				room_id,
				room_no,
				owner_id,
				owner_name,
				charge_type_no,
				charge_type_name,
				receive_amount,
				paid_amount,
				arrearage_amount,
				oper_emp_id,
				update_date,
				begin_time,
				end_time,
				price,
				count,
				room_type,
				community_name,
				storied_build_name
			) SELECT
				UUID() as charge_id,
				a.room_id as room_id,
				a.room_no as room_no,
				o.owner_id as owner_id,
				o.owner_name as owner_name,
				a.charge_type_no as charge_type_no,
				a.charge_type_name as charge_type_name,
				if(DAY(begin_date)=1,a.total_price,(a.total_price/30)*(30-DAY(begin_date))) as receive_amount,
				0 as paid_amount,
				if(DAY(begin_date)=1,a.total_price,(a.total_price/30)*(30-DAY(begin_date))) as arrearage_amount,
				in_oper_id as oper_emp_id,
				SYSDATE() as update_date,
				DATE_FORMAT(begin_date, '%Y-%m-%d') as begin_time,
				DATE_FORMAT(end_date, '%Y-%m-%d') as end_time,
				a.charge_price as price,
				a.build_area as count,
				a.room_type as room_type,
				a.community_name as community_name,
				a.storied_build_name as storied_build_name
			FROM
				v_charge_build_area a,
				t_house_owner r,
				t_property_owner o
			WHERE	a.room_id = r.room_id
			AND r.owner_id = o.owner_id
			AND a.charge_state = '1'
			AND o.owner_identity = 0
			AND a.room_id = in_room_id;
		
		##修改变量执行运算下个月时间
		set in_begin_date = DATE_ADD(in_begin_date,INTERVAL 1 MONTH);  
		set begin_date = date_add(in_begin_date, interval - day(in_begin_date) + 1 day); #获取本月第一天
		set end_date= last_day(in_begin_date); #获取本月最后一天
		END IF;
	END WHILE; 
	
	 IF t_error = 1 THEN 
             ROLLBACK;  
         ELSE  
             COMMIT;  
         END IF; 
  END IF; 
		
	SELECT  t_error;		
	
END;

