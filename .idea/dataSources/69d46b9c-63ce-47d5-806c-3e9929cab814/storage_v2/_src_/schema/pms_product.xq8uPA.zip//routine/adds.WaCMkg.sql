create
    definer = root@localhost function adds(in_s_num int, in_e_num int, in_step_num int) returns int
BEGIN
	#Routine body goes here...
  DECLARE sum INT DEFAULT 0;
	while(in_s_num<=in_e_num) DO
		set sum=sum+in_s_num;
		set in_s_num =in_s_num+in_step_num;
	end while;
	RETURN sum;
END;

