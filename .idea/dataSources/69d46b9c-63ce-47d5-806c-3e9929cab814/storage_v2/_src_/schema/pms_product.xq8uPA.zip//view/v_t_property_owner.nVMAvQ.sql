create view v_t_property_owner as
select `a`.`owner_id`                                                                           AS `owner_id`,
       `a`.`owner_name`                                                                         AS `owner_name`,
       `a`.`phone`                                                                              AS `phone`,
       `a`.`tel_phone`                                                                          AS `tel_phone`,
       `a`.`sex`                                                                                AS `sex`,
       `a`.`password`                                                                           AS `PASSWORD`,
       `a`.`card_id`                                                                            AS `card_id`,
       `a`.`birth_date`                                                                         AS `birth_date`,
       `a`.`car_id`                                                                             AS `car_id`,
       `a`.`owner_type`                                                                         AS `owner_type`,
       `a`.`owner_identity`                                                                     AS `owner_identity`,
       `a`.`parent_id`                                                                          AS `parent_id`,
       `a`.`remark`                                                                             AS `remark`,
       `a`.`owner_head_img`                                                                     AS `owner_head_img`,
       `a`.`owner_hk_id`                                                                        AS `owner_hk_id`,
       `a`.`emergency_contact`                                                                  AS `emergency_contact`,
       `a`.`emergency_contact_phone`                                                            AS `emergency_contact_phone`,
       (select `f`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `f`
        where ((`f`.`code` = 'owner_type') and (`f`.`code_detail` = `a`.`owner_type`)))         AS `owner_type_name`,
       (select `g`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `g`
        where ((`g`.`code` = 'owner_identity') and (`g`.`code_detail` = `a`.`owner_identity`))) AS `owner_identity_name`
from `pms_product`.`t_property_owner` `a`;

-- comment on column v_t_property_owner.owner_id not supported: 业主ID

-- comment on column v_t_property_owner.owner_name not supported: 业主姓名

-- comment on column v_t_property_owner.phone not supported: 手机号

-- comment on column v_t_property_owner.tel_phone not supported: 联系电话

-- comment on column v_t_property_owner.sex not supported: 性别

-- comment on column v_t_property_owner.PASSWORD not supported: 密码(APP用户使用)

-- comment on column v_t_property_owner.card_id not supported: 身份证号

-- comment on column v_t_property_owner.birth_date not supported: 出生日期

-- comment on column v_t_property_owner.car_id not supported: 车辆ID

-- comment on column v_t_property_owner.owner_type not supported: 业主类型（0一般 1重要）

-- comment on column v_t_property_owner.owner_identity not supported: 身份（业主、家属、租客、游客）

-- comment on column v_t_property_owner.parent_id not supported: 所属业主ID

-- comment on column v_t_property_owner.remark not supported: 备注

-- comment on column v_t_property_owner.owner_head_img not supported: 业主头像

-- comment on column v_t_property_owner.owner_hk_id not supported: 海康人员id

-- comment on column v_t_property_owner.emergency_contact not supported: 紧急联系人及电话

-- comment on column v_t_property_owner.emergency_contact_phone not supported: 紧急人联系电话

