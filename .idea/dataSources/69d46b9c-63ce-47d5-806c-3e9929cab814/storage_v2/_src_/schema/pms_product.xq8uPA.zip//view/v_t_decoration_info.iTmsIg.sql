create view v_t_decoration_info as
select `a`.`id`                                                                 AS `id`,
       `a`.`name`                                                               AS `name`,
       `a`.`summary`                                                            AS `summary`,
       `a`.`telephone`                                                          AS `telephone`,
       `a`.`logo_url`                                                           AS `logo_url`,
       `a`.`editor_id`                                                          AS `editor_id`,
       `a`.`editor_name`                                                        AS `editor_name`,
       `a`.`logo_path`                                                          AS `logo_path`,
       (select count(0)
        from `pms_product`.`t_decoration_checker`
        where (`pms_product`.`t_decoration_checker`.`company_id` = `a`.`id`))   AS `checker`,
       (select count(0)
        from `pms_product`.`t_decoration_consultor`
        where (`pms_product`.`t_decoration_consultor`.`company_id` = `a`.`id`)) AS `consultor`
from `pms_product`.`t_decoration_info` `a`;

-- comment on column v_t_decoration_info.name not supported: 公司名称

-- comment on column v_t_decoration_info.summary not supported: 公司简介

-- comment on column v_t_decoration_info.telephone not supported: 联系电话

-- comment on column v_t_decoration_info.logo_url not supported: logo图片地址

-- comment on column v_t_decoration_info.editor_id not supported: 编辑人ID

-- comment on column v_t_decoration_info.editor_name not supported: 编辑人姓名

