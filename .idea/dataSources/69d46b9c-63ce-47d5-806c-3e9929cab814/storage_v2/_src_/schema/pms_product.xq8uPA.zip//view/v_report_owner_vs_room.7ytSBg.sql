create view v_report_owner_vs_room as
select `b`.`room_id`    AS `room_id`,
       `a`.`owner_id`   AS `owner_id`,
       `a`.`owner_name` AS `owner_name`,
       `a`.`card_id`    AS `card_id`,
       `a`.`phone`      AS `phone`
from (`pms_product`.`t_property_owner` `a`
         join `pms_product`.`t_house_owner` `b`)
where ((`a`.`owner_id` = `b`.`owner_id`) and (`a`.`owner_identity` = '0'));

-- comment on column v_report_owner_vs_room.owner_id not supported: 业主ID

-- comment on column v_report_owner_vs_room.owner_name not supported: 业主姓名

-- comment on column v_report_owner_vs_room.card_id not supported: 身份证号

-- comment on column v_report_owner_vs_room.phone not supported: 手机号

