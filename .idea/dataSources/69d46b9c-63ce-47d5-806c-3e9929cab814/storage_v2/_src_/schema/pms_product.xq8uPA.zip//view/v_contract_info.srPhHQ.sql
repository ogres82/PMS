create view v_contract_info as
select `a`.`contract_id`                                                                     AS `contract_id`,
       `a`.`contract_code`                                                                   AS `contract_code`,
       `a`.`contract_name`                                                                   AS `contract_name`,
       `a`.`contract_type`                                                                   AS `contract_type`,
       `a`.`contract_detail`                                                                 AS `contract_detail`,
       `a`.`contract_pB_name`                                                                AS `contract_pB_name`,
       `a`.`contract_pB_linker`                                                              AS `contract_pB_linker`,
       `a`.`contract_pB_phone`                                                               AS `contract_pB_phone`,
       `a`.`contract_sign_date`                                                              AS `contract_sign_date`,
       `a`.`contract_end_date`                                                               AS `contract_end_date`,
       `a`.`contract_period`                                                                 AS `contract_period`,
       `a`.`contract_price`                                                                  AS `contract_price`,
       `a`.`contract_status`                                                                 AS `contract_status`,
       `a`.`remark`                                                                          AS `remark`,
       (select `pms_product`.`dir_directorydetail`.`code_detail_name`
        from `pms_product`.`dir_directorydetail`
        where ((`pms_product`.`dir_directorydetail`.`code` = 'contract_type') and
               (`pms_product`.`dir_directorydetail`.`code_detail` = `a`.`contract_type`)))   AS `contract_type_name`,
       (select `pms_product`.`dir_directorydetail`.`code_detail_name`
        from `pms_product`.`dir_directorydetail`
        where ((`pms_product`.`dir_directorydetail`.`code` = 'contract_status') and
               (`pms_product`.`dir_directorydetail`.`code_detail` = `a`.`contract_status`))) AS `contract_status_name`
from `pms_product`.`t_contract_info` `a`;

-- comment on column v_contract_info.contract_id not supported: 合同ID

-- comment on column v_contract_info.contract_code not supported: 合同编号

-- comment on column v_contract_info.contract_name not supported: 合同名称

-- comment on column v_contract_info.contract_type not supported: 合同类型（01服务合同02买卖合同03租赁合同04业主合同）

-- comment on column v_contract_info.contract_detail not supported: 合同简述

-- comment on column v_contract_info.contract_pB_name not supported: 乙方名称

-- comment on column v_contract_info.contract_pB_linker not supported: 乙方联系人

-- comment on column v_contract_info.contract_pB_phone not supported: 乙方联系人方式

-- comment on column v_contract_info.contract_sign_date not supported: 签订日期

-- comment on column v_contract_info.contract_end_date not supported: 终止日期

-- comment on column v_contract_info.contract_period not supported: 合同期限

-- comment on column v_contract_info.contract_price not supported: 合同金额

-- comment on column v_contract_info.contract_status not supported: 合同状态（01生效02终止03 结束）

-- comment on column v_contract_info.remark not supported: 备注

