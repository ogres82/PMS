create view v_room_property_fee_info as
select `a`.`room_addrs`                                                                                            AS `room_addrs`,
       `a`.`build_id`                                                                                              AS `build_id`,
       `a`.`build_name`                                                                                            AS `build_name`,
       `a`.`community_id`                                                                                          AS `community_id`,
       `a`.`community_name`                                                                                        AS `community_name`,
       `a`.`storied_build_id`                                                                                      AS `storied_build_id`,
       `a`.`storied_build_name`                                                                                    AS `storied_build_name`,
       `a`.`unit_id`                                                                                               AS `unit_id`,
       `a`.`unit_name`                                                                                             AS `unit_name`,
       `a`.`room_id`                                                                                               AS `room_id`,
       `a`.`room_no`                                                                                               AS `room_no`,
       `a`.`room_lz_id`                                                                                            AS `room_lz_id`,
       `a`.`build_area`                                                                                            AS `build_area`,
       `a`.`within_area`                                                                                           AS `within_area`,
       `a`.`room_state`                                                                                            AS `room_state`,
       `a`.`room_state_name`                                                                                       AS `room_state_name`,
       `a`.`room_type`                                                                                             AS `room_type`,
       `a`.`room_type_name`                                                                                        AS `room_type_name`,
       `a`.`make_room_date`                                                                                        AS `make_room_date`,
       `a`.`charge_date`                                                                                           AS `charge_date`,
       `a`.`charge_type_no`                                                                                        AS `charge_type_no`,
       `a`.`charge_price`                                                                                          AS `charge_price`,
       `a`.`charge_type_name`                                                                                      AS `charge_type_name`,
       `a`.`charge_state`                                                                                          AS `charge_state`,
       `a`.`charge_state_name`                                                                                     AS `charge_state_name`,
       `a`.`months_price`                                                                                          AS `months_price`,
       `a`.`days_price`                                                                                            AS `days_price`,
       `b`.`owner_id`                                                                                              AS `owner_id`,
       `b`.`owner_name`                                                                                            AS `owner_name`,
       `b`.`card_id`                                                                                               AS `card_id`,
       `b`.`phone`                                                                                                 AS `phone`,
       `b`.`sex`                                                                                                   AS `sex`,
       `b`.`birth_date`                                                                                            AS `birth_date`,
       ifnull(`c`.`total_paid_amount`, 0)                                                                          AS `total_paid_amount`,
       (ifnull(`c`.`total_paid_amount`, 0) DIV `a`.`months_price`)                                                 AS `fee_months`,
       ((ifnull(`c`.`total_paid_amount`, 0) -
         (`a`.`months_price` * (ifnull(`c`.`total_paid_amount`, 0) DIV `a`.`months_price`))) DIV
        `a`.`days_price`)                                                                                          AS `fee_days`,
       ((`a`.`charge_date` + interval (ifnull(`c`.`total_paid_amount`, 0) DIV `a`.`months_price`) month) + interval (
               (ifnull(`c`.`total_paid_amount`, 0) -
                (`a`.`months_price` * (ifnull(`c`.`total_paid_amount`, 0) DIV `a`.`months_price`))) DIV
               `a`.`days_price`) day)                                                                              AS `exp_date`
from ((`pms_product`.`t_house_vs_fee` `a` left join `pms_product`.`t_owner_vs_room_id` `b` on ((`a`.`room_id` = `b`.`room_id`)))
         left join `pms_product`.`v_room_fee_total` `c` on ((`a`.`room_id` = `c`.`room_id`)));

-- comment on column v_room_property_fee_info.build_id not supported: 楼盘ID

-- comment on column v_room_property_fee_info.build_name not supported: 楼盘名称

-- comment on column v_room_property_fee_info.community_id not supported: 小区ID

-- comment on column v_room_property_fee_info.community_name not supported: 小区名称

-- comment on column v_room_property_fee_info.storied_build_id not supported: 所属楼栋ID

-- comment on column v_room_property_fee_info.storied_build_name not supported: 楼栋名称

-- comment on column v_room_property_fee_info.unit_id not supported: 单元ID

-- comment on column v_room_property_fee_info.unit_name not supported: 单元名称

-- comment on column v_room_property_fee_info.room_id not supported: 房间ID

-- comment on column v_room_property_fee_info.room_no not supported: 房间号

-- comment on column v_room_property_fee_info.build_area not supported: 建筑面积

-- comment on column v_room_property_fee_info.within_area not supported: 套内面积

-- comment on column v_room_property_fee_info.room_state not supported: 房间状态 0未售1交房2接房3入住4出租

-- comment on column v_room_property_fee_info.room_type not supported: 房间类型 0高层1洋房2别墅

-- comment on column v_room_property_fee_info.make_room_date not supported: 收房日期（地产通知收房的日期）

-- comment on column v_room_property_fee_info.charge_date not supported: 收费开始时间

-- comment on column v_room_property_fee_info.charge_state not supported: 是否开始出账（1：开始出账；0：不出账）

-- comment on column v_room_property_fee_info.owner_id not supported: 业主ID

-- comment on column v_room_property_fee_info.owner_name not supported: 业主姓名

-- comment on column v_room_property_fee_info.card_id not supported: 身份证号

-- comment on column v_room_property_fee_info.phone not supported: 手机号

-- comment on column v_room_property_fee_info.sex not supported: 性别

-- comment on column v_room_property_fee_info.birth_date not supported: 出生日期

