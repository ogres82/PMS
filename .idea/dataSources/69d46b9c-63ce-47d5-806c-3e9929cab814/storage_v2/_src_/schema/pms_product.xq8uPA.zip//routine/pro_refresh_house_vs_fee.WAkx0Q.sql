create
    definer = pms_admin@`%` procedure pro_refresh_house_vs_fee()
BEGIN
DELETE FROM t_house_vs_fee;
INSERT INTO t_house_vs_fee
select 
(case when a.room_type  = '2' then CONCAT(a.community_name,a.room_no) else CONCAT(a.community_name,a.unit_name,a.room_no) end
)as room_addrs,
a.build_id,
a.build_name,
a.community_id,
a.community_name,
a.belong_sb_id as storied_build_id,
a.storied_build_name,
a.unit_id,
a.unit_name,
a.room_id,
a.room_no,
a.lz_id as room_lz_id, 
a.build_area,
a.within_area,
a.room_state,
(select code_detail_name from dir_directorydetail q where a.room_state = q.code_detail and q.`code`='room_state') as room_state_name,
a.room_type,
(select code_detail_name from dir_directorydetail q where a.room_type = q.code_detail and q.`code`='room_type') as room_type_name,
a.make_room_date,
b.charge_date,
b.charge_type_no,
c.charge_price,
c.charge_type_name,
b.charge_state,
case when b.charge_state = '1' then '开始计费'
else '未计费'
end as charge_state_name,
c.charge_price*a.build_area as months_price,
ROUND((c.charge_price*a.build_area)/30,2) AS days_price
from t_house_property a
LEFT JOIN t_charge_type_room_rela b
on a.room_id = b.room_id
LEFT JOIN t_charge_type_setting c
on b.charge_type_no = c.charge_type_no
order by a.community_name,a.unit_name,a.room_no;
END;

