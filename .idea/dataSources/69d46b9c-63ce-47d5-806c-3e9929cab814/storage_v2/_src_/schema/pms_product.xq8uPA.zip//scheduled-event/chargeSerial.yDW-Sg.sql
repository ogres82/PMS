create definer = pms_admin@`%` event chargeSerial on schedule
    every '1' DAY
        starts '2019-07-14 03:00:00'
    on completion preserve
    enable
    do
    CALL pro_createSerial(NULL,NULL,NULL,NULL);

