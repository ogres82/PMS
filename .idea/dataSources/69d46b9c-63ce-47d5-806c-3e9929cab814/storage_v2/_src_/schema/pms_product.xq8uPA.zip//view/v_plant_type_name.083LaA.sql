create view v_plant_type_name as
select `a`.`plant_id`                                                                   AS `plant_id`,
       `a`.`plant_name`                                                                 AS `plant_name`,
       `a`.`plant_mtn_standard`                                                         AS `plant_mtn_standard`,
       `a`.`plant_type`                                                                 AS `plant_type`,
       `a`.`remark`                                                                     AS `remark`,
       (select `pms_product`.`dir_directorydetail`.`code_detail_name`
        from `pms_product`.`dir_directorydetail`
        where ((`pms_product`.`dir_directorydetail`.`code` = 'plant_type') and
               (`pms_product`.`dir_directorydetail`.`code_detail` = `a`.`plant_type`))) AS `plant_type_name`
from `pms_product`.`t_environment_plant` `a`;

-- comment on column v_plant_type_name.plant_id not supported: 植被ID

-- comment on column v_plant_type_name.plant_name not supported: 植被名称

-- comment on column v_plant_type_name.plant_mtn_standard not supported: 养护标准

-- comment on column v_plant_type_name.plant_type not supported: 植被类别（0乔木1草坪2观赏花3其他）

-- comment on column v_plant_type_name.remark not supported: 备注

