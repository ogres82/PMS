create
    definer = pms_admin@`%` procedure pro_change_owner_phone(IN in_room_id varchar(50), IN in_oper_id varchar(50),
                                                             IN in_oper_type varchar(2))
BEGIN
   -- in_oper_type : 1为更换号码；2：为更换业主
	START TRANSACTION;-- 整个存储过程指定为一个事务
		SELECT
			a.owner_id as ownerId,
			a.owner_identity as ownerIdentity,
			a.phone as phone,
			b.room_id as roomId,			
			b.lz_id as lzId
		FROM
			t_property_owner a
			LEFT JOIN t_house_owner b ON a.owner_id = b.owner_id and b.is_del = '0'
		WHERE
			b.room_id = in_room_id
			order by a.owner_identity desc ;
	COMMIT;-- 语句1。必须主动提交

END;

