create definer = pms_admin@`%` trigger up_charge_setting_refresh
    after update
    on t_charge_type_setting
    for each row
begin
call pro_refresh_house_vs_fee();
end;

