create view v_t_advertise_position as
select `p`.`adv_pos_id`                                                                         AS `adv_pos_id`,
       `p`.`adv_pos_code`                                                                       AS `adv_pos_code`,
       `p`.`adv_position`                                                                       AS `adv_position`,
       `p`.`adv_pos_size`                                                                       AS `adv_pos_size`,
       `p`.`adv_pos_status`                                                                     AS `adv_pos_status`,
       (select `d`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `d`
        where ((`d`.`code` = 'adv_pos_status') and (`d`.`code_detail` = `p`.`adv_pos_status`))) AS `status_name`,
       `p`.`adv_pos_type`                                                                       AS `adv_pos_type`,
       `p`.`adv_memo`                                                                           AS `adv_memo`,
       `p`.`create_by`                                                                          AS `create_by`,
       `p`.`create_time`                                                                        AS `create_time`,
       (select `d`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `d`
        where ((`d`.`code` = 'adv_pos_type') and (`d`.`code_detail` = `p`.`adv_pos_type`)))     AS `type_name`
from `pms_product`.`t_advertise_position` `p`;

-- comment on column v_t_advertise_position.adv_pos_id not supported: 广告位ID

-- comment on column v_t_advertise_position.adv_pos_code not supported: 广告位编号

-- comment on column v_t_advertise_position.adv_position not supported: 广告位位置

-- comment on column v_t_advertise_position.adv_pos_size not supported: 广告位大小

-- comment on column v_t_advertise_position.adv_pos_status not supported: 状态

-- comment on column v_t_advertise_position.adv_pos_type not supported: 广告位类别

