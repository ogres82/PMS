create view v_bdf2_user as
select `a`.`USERNAME_`      AS `USERNAME_`,
       `a`.`ADDRESS_`       AS `ADDRESS_`,
       `a`.`ADMINISTRATOR_` AS `ADMINISTRATOR_`,
       `a`.`BIRTHDAY_`      AS `BIRTHDAY_`,
       `a`.`CNAME_`         AS `CNAME_`,
       `a`.`COMPANY_ID_`    AS `COMPANY_ID_`,
       `a`.`CREATE_DATE_`   AS `CREATE_DATE_`,
       `a`.`EMAIL_`         AS `EMAIL_`,
       `a`.`ENABLED_`       AS `ENABLED_`,
       `a`.`ENAME_`         AS `ENAME_`,
       `a`.`MALE_`          AS `MALE_`,
       `a`.`MOBILE_`        AS `MOBILE_`,
       `a`.`PASSWORD_`      AS `PASSWORD_`,
       `a`.`SALT_`          AS `SALT_`,
       `d`.`ID_`            AS `dept_id`,
       `d`.`NAME_`          AS `dept_name`,
       `e`.`ID_`            AS `position_id`,
       `e`.`NAME_`          AS `position_name`
from ((((`pms_product`.`bdf2_user` `a` left join `pms_product`.`bdf2_user_position` `b` on ((`a`.`USERNAME_` = `b`.`USERNAME_`))) left join `pms_product`.`bdf2_user_dept` `c` on ((`a`.`USERNAME_` = `c`.`USERNAME_`))) left join `pms_product`.`bdf2_dept` `d` on ((`d`.`ID_` = `c`.`DEPT_ID_`)))
         left join `pms_product`.`bdf2_position` `e` on ((`e`.`ID_` = `b`.`POSITION_ID_`)));

