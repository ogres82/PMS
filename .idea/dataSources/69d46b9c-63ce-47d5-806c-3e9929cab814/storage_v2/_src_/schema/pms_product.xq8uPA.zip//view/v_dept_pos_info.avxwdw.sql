create view v_dept_pos_info as
select concat(`a`.`ID_`, `b`.`ID_`) AS `id`,
       `a`.`ID_`                    AS `dept_id`,
       `a`.`NAME_`                  AS `dept_name`,
       `b`.`ID_`                    AS `pos_id`,
       `b`.`NAME_`                  AS `pos_name`
from (`pms_product`.`bdf2_dept` `a`
         join `pms_product`.`bdf2_position` `b`)
where (`a`.`NAME_` = `b`.`DESC_`)
order by `a`.`ID_`, `b`.`ID_`;

