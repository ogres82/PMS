create view v_emp_blessing_info as
select `pms_product`.`t_emp`.`emp_name`  AS `empName`,
       `pms_product`.`t_emp`.`emp_phone` AS `empPhone`,
       0                                 AS `empYear`,
       '01'                              AS `smsType`
from `pms_product`.`t_emp`
where ((date_format(`pms_product`.`t_emp`.`emp_birth`, '%m%d') = date_format(curdate(), '%m%d')) and
       (isnull(`pms_product`.`t_emp`.`emp_quit_time`) = 1))
union all
select `pms_product`.`t_emp`.`emp_name`                                       AS `empName`,
       `pms_product`.`t_emp`.`emp_phone`                                      AS `empPhone`,
       timestampdiff(YEAR, `pms_product`.`t_emp`.`emp_entry_time`, curdate()) AS `empYear`,
       '02'                                                                   AS `smsType`
from `pms_product`.`t_emp`
where ((date_format(`pms_product`.`t_emp`.`emp_entry_time`, '%m%d') = date_format(curdate(), '%m%d')) and
       (timestampdiff(YEAR, `pms_product`.`t_emp`.`emp_entry_time`, curdate()) >= 1) and
       (isnull(`pms_product`.`t_emp`.`emp_quit_time`) = 1));

