create view v_room_billing_info as
select `v_room_property_fee_info`.`build_id`                                                            AS `build_id`,
       `v_room_property_fee_info`.`build_name`                                                          AS `build_name`,
       `v_room_property_fee_info`.`community_id`                                                        AS `community_id`,
       `v_room_property_fee_info`.`community_name`                                                      AS `community_name`,
       `v_room_property_fee_info`.`storied_build_id`                                                    AS `storied_build_id`,
       `v_room_property_fee_info`.`storied_build_name`                                                  AS `storied_build_name`,
       `v_room_property_fee_info`.`unit_id`                                                             AS `unit_id`,
       `v_room_property_fee_info`.`unit_name`                                                           AS `unit_name`,
       `v_room_property_fee_info`.`room_id`                                                             AS `room_id`,
       `v_room_property_fee_info`.`room_no`                                                             AS `room_no`,
       `v_room_property_fee_info`.`room_lz_id`                                                          AS `room_lz_id`,
       `v_room_property_fee_info`.`build_area`                                                          AS `build_area`,
       `v_room_property_fee_info`.`within_area`                                                         AS `within_area`,
       `v_room_property_fee_info`.`room_state`                                                          AS `room_state`,
       `v_room_property_fee_info`.`room_state_name`                                                     AS `room_state_name`,
       `v_room_property_fee_info`.`room_type`                                                           AS `room_type`,
       `v_room_property_fee_info`.`room_type_name`                                                      AS `room_type_name`,
       `v_room_property_fee_info`.`make_room_date`                                                      AS `make_room_date`,
       `v_room_property_fee_info`.`charge_date`                                                         AS `charge_date`,
       `v_room_property_fee_info`.`charge_type_no`                                                      AS `charge_type_no`,
       `v_room_property_fee_info`.`charge_price`                                                        AS `charge_price`,
       `v_room_property_fee_info`.`charge_type_name`                                                    AS `charge_type_name`,
       `v_room_property_fee_info`.`charge_state`                                                        AS `charge_state`,
       `v_room_property_fee_info`.`charge_state_name`                                                   AS `charge_state_name`,
       `v_room_property_fee_info`.`months_price`                                                        AS `months_price`,
       `v_room_property_fee_info`.`days_price`                                                          AS `days_price`,
       `v_room_property_fee_info`.`owner_id`                                                            AS `owner_id`,
       `v_room_property_fee_info`.`owner_name`                                                          AS `owner_name`,
       `v_room_property_fee_info`.`card_id`                                                             AS `card_id`,
       `v_room_property_fee_info`.`phone`                                                               AS `phone`,
       `v_room_property_fee_info`.`sex`                                                                 AS `sex`,
       `v_room_property_fee_info`.`birth_date`                                                          AS `birth_date`,
       `v_room_property_fee_info`.`total_paid_amount`                                                   AS `total_paid_amount`,
       `v_room_property_fee_info`.`fee_months`                                                          AS `fee_months`,
       `v_room_property_fee_info`.`fee_days`                                                            AS `fee_days`,
       `v_room_property_fee_info`.`exp_date`                                                            AS `exp_date`,
       `v_room_property_fee_info`.`room_addrs`                                                          AS `room_addrs`,
       timestampdiff(MONTH, `v_room_property_fee_info`.`exp_date`,
                     curdate())                                                                         AS `dely_months`,
       timestampdiff(DAY, `v_room_property_fee_info`.`exp_date`, curdate())                             AS `dely_days`,
       (case when isnull(`v_room_property_fee_info`.`exp_date`) then NULL else last_day(curdate()) end) AS `end_date`,
       if(isnull(`v_room_property_fee_info`.`charge_date`), NULL,
          if((`v_room_property_fee_info`.`exp_date` >= curdate()), '未欠费',
             '欠费'))                                                                                     AS `arrears_state`,
       (case
            when ((timestampdiff(DAY, last_day(curdate()), `v_room_property_fee_info`.`exp_date`) *
                   `v_room_property_fee_info`.`days_price`) >= 0) then (
                    timestampdiff(DAY, last_day(curdate()), `v_room_property_fee_info`.`exp_date`) *
                    `v_room_property_fee_info`.`days_price`)
            else 0 end)                                                                                 AS `amount`,
       abs((case
                when ((timestampdiff(DAY, last_day(curdate()), `v_room_property_fee_info`.`exp_date`) *
                       `v_room_property_fee_info`.`days_price`) < 0) then (
                        timestampdiff(DAY, last_day(curdate()), `v_room_property_fee_info`.`exp_date`) *
                        `v_room_property_fee_info`.`days_price`)
                else 0 end))                                                                            AS `arr_amount`
from `pms_product`.`v_room_property_fee_info`;

-- comment on column v_room_billing_info.build_id not supported: 楼盘ID

-- comment on column v_room_billing_info.build_name not supported: 楼盘名称

-- comment on column v_room_billing_info.community_id not supported: 小区ID

-- comment on column v_room_billing_info.community_name not supported: 小区名称

-- comment on column v_room_billing_info.storied_build_id not supported: 所属楼栋ID

-- comment on column v_room_billing_info.storied_build_name not supported: 楼栋名称

-- comment on column v_room_billing_info.unit_id not supported: 单元ID

-- comment on column v_room_billing_info.unit_name not supported: 单元名称

-- comment on column v_room_billing_info.room_id not supported: 房间ID

-- comment on column v_room_billing_info.room_no not supported: 房间号

-- comment on column v_room_billing_info.build_area not supported: 建筑面积

-- comment on column v_room_billing_info.within_area not supported: 套内面积

-- comment on column v_room_billing_info.room_state not supported: 房间状态 0未售1交房2接房3入住4出租

-- comment on column v_room_billing_info.room_type not supported: 房间类型 0高层1洋房2别墅

-- comment on column v_room_billing_info.make_room_date not supported: 收房日期（地产通知收房的日期）

-- comment on column v_room_billing_info.charge_date not supported: 收费开始时间

-- comment on column v_room_billing_info.charge_state not supported: 是否开始出账（1：开始出账；0：不出账）

-- comment on column v_room_billing_info.owner_id not supported: 业主ID

-- comment on column v_room_billing_info.owner_name not supported: 业主姓名

-- comment on column v_room_billing_info.card_id not supported: 身份证号

-- comment on column v_room_billing_info.phone not supported: 手机号

-- comment on column v_room_billing_info.sex not supported: 性别

-- comment on column v_room_billing_info.birth_date not supported: 出生日期

