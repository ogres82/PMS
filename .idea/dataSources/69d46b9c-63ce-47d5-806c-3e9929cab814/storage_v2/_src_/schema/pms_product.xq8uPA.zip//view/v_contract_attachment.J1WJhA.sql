create view v_contract_attachment as
select `a`.`contract_id`      AS `contract_id`,
       `b`.`file_id`          AS `file_id`,
       `b`.`file_name`        AS `file_name`,
       `b`.`file_upload_time` AS `file_upload_time`,
       `b`.`file_path`        AS `file_path`
from (`pms_product`.`t_contract_attachment` `b`
         left join `pms_product`.`t_contract_attach_rela` `a` on ((`b`.`file_id` = `a`.`file_id`)));

-- comment on column v_contract_attachment.contract_id not supported: 合同ID

-- comment on column v_contract_attachment.file_id not supported: 文件ID

-- comment on column v_contract_attachment.file_name not supported: 文件名称

-- comment on column v_contract_attachment.file_upload_time not supported: 上传时间

-- comment on column v_contract_attachment.file_path not supported: 文件路径

