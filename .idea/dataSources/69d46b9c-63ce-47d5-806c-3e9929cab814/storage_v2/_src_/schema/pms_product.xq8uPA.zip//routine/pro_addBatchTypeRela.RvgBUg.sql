create
    definer = pms_admin@`%` procedure pro_addBatchTypeRela(IN areaId varchar(50), IN buildId varchar(50),
                                                           IN chargeTypeId varchar(50), IN chargeTypeNo varchar(50),
                                                           IN oper varchar(100), IN typeFlag varchar(10))
BEGIN
#Routine body goes here...
	DECLARE v_room_id VARCHAR(50);
	DECLARE v_room_no VARCHAR(50);
	DECLARE v_owner_id VARCHAR(50);
	DECLARE done INT DEFAULT FALSE;
  -- 游标 应收记录中查询还没有收款的
  DECLARE cur CURSOR FOR SELECT r.room_id, r.room_no, r.owner_id FROM v_area_build_house_owner_rela r 
		WHERE r.room_state=2 AND r.community_id=areaId AND r.storied_build_id=buildId;

	-- 将结束标志绑定到游标
  DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' BEGIN SET done = TRUE; SELECT 11; END;
	-- 将结束标志绑定到游标
  DECLARE CONTINUE HANDLER FOR 1062 BEGIN SELECT 11; END;
	declare exit handler for sqlexception rollback; 
	#手动提交事务
  SET autocommit=0;
	start transaction;

	OPEN cur;
  -- 开始循环
  read_loop: LOOP
    -- 提取游标里的数据
    FETCH cur INTO v_room_id, v_room_no, v_owner_id;
    -- 声明结束的时候
    IF done THEN
      LEAVE read_loop;
    END IF;
		
		BEGIN
			INSERT INTO t_charge_type_room_rela(room_id,charge_type_id,charge_type_no,update_date, update_emp_id,type_flag)
				VALUES(v_room_id, chargeTypeId, chargeTypeNo, SYSDATE(),oper,typeFlag );
		END;

  END LOOP read_loop;
	
	#Routine body goes here...
	/*
	IF ISNULL(buildId) || LENGTH(trim(buildId))<1 THEN
		INSERT INTO t_charge_type_room_rela(room_id, room_no,owner_id,charge_type_id,charge_type_no,update_date, update_emp_id)
		SELECT r.room_id, r.room_no, r.owner_id, chargeTypeId, chargeTypeNo, SYSDATE(),oper FROM v_area_build_house_owner_rela r 
		WHERE r.room_state=2 AND r.community_id=areaId;
	ELSE
		INSERT INTO t_charge_type_room_rela(room_id, room_no,owner_id,charge_type_id,charge_type_no,update_date, update_emp_id)
		SELECT r.room_id, r.room_no, r.owner_id, chargeTypeId, chargeTypeNo, SYSDATE(),oper FROM v_area_build_house_owner_rela r 
		WHERE r.room_state=2 AND r.community_id=areaId AND r.storied_build_id=buildId;
	END IF;
	*/

	COMMIT;
END;

