create view v_t_building_property as
select `c`.`build_id`                                                                       AS `build_id`,
       `c`.`build_name`                                                                     AS `build_name`,
       `c`.`lz_id`                                                                          AS `lz_build_id`,
       `a`.`build_floors`                                                                   AS `build_floors`,
       `b`.`community_id`                                                                   AS `community_id`,
       `b`.`community_name`                                                                 AS `community_name`,
       `b`.`lz_id`                                                                          AS `lz_comm_id`,
       `a`.`storied_build_id`                                                               AS `storied_build_id`,
       `a`.`storied_build_name`                                                             AS `storied_build_name`,
       `a`.`lz_id`                                                                          AS `lz_id`,
       `a`.`storied_type`                                                                   AS `storied_type`,
       `a`.`house_type_id`                                                                  AS `house_type_id`,
       `d`.`type_name`                                                                      AS `house_type_name`,
       `a`.`belong_comm_id`                                                                 AS `belong_comm_id`,
       `a`.`remark`                                                                         AS `remark`,
       (select `t`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `t`
        where ((`t`.`code` = 'storied_type') and (`t`.`code_detail` = `a`.`storied_type`))) AS `storied_type_name`
from (((`pms_product`.`t_building_property` `a` left join `pms_product`.`t_area_property` `b` on ((`a`.`belong_comm_id` = `b`.`community_id`))) left join `pms_product`.`t_all_area` `c` on ((`c`.`build_id` = `b`.`belong_build_id`)))
         left join `pms_product`.`t_building_housetype` `d` on ((`a`.`house_type_id` = `d`.`type_id`)));

-- comment on column v_t_building_property.build_id not supported: 楼盘ID

-- comment on column v_t_building_property.build_name not supported: 楼盘名称  例：乐湾国际城一期

-- comment on column v_t_building_property.community_id not supported: 小区ID

-- comment on column v_t_building_property.community_name not supported: 小区名称 例：西湖御景、依山云墅

-- comment on column v_t_building_property.storied_build_id not supported: 楼栋ID

-- comment on column v_t_building_property.storied_build_name not supported: 楼栋名称 例：独栋、001栋

-- comment on column v_t_building_property.storied_type not supported: 楼宇类别

-- comment on column v_t_building_property.house_type_id not supported: 户型id

-- comment on column v_t_building_property.house_type_name not supported: 户型名称

-- comment on column v_t_building_property.belong_comm_id not supported: 所属小区ID

-- comment on column v_t_building_property.remark not supported: 备注

