create view v_event_report as
select count(1) AS `num`, substring_index(`t1`.`address`, '-', 1) AS `area`, substr(`t1`.`rpt_id`, 1, 2) AS `type`
from `pms_product`.`t_r_maintain` `t1`
where (`t1`.`event_state` <> 0)
group by substring_index(`t1`.`address`, '-', 1), substr(`t1`.`rpt_id`, 1, 2)
union all
select count(1)                                     AS `num`,
       substring_index(`h1`.`user_address`, '-', 1) AS `area`,
       substr(`h1`.`event_no`, 1, 2)                AS `type`
from `pms_product`.`t_housework_event` `h1`
where (`h1`.`event_state` <> 0)
group by substring_index(`h1`.`user_address`, '-', 1), substr(`h1`.`event_no`, 1, 2);

