create view v_t_housework as
select `t`.`event_no`                                                                                              AS `event_no`,
       `t`.`event_title`                                                                                           AS `event_title`,
       `t`.`call_phone`                                                                                            AS `call_phone`,
       `t`.`accept_time`                                                                                           AS `accept_time`,
       `t`.`event_from`                                                                                            AS `event_from`,
       (select `d`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `d`
        where ((`d`.`code_detail` = `t`.`event_from`) and
               (`d`.`code` = 'main_event_source')))                                                                AS `event_source_name`,
       `t`.`pre_time`                                                                                              AS `pre_time`,
       `t`.`record_id`                                                                                             AS `record_id`,
       `t`.`bpm_processId`                                                                                         AS `bpm_processId`,
       (select `u`.`owner_name`
        from `pms_product`.`t_property_owner` `u`
        where (`u`.`owner_id` = `t`.`link_man`))                                                                   AS `rpt_name`,
       `t`.`event_content`                                                                                         AS `event_content`,
       `t`.`verify_oper_id`                                                                                        AS `verify_oper_id`,
       `t`.`user_address`                                                                                          AS `user_address`,
       `t`.`id`                                                                                                    AS `id`,
       `t`.`link_man_name`                                                                                         AS `link_man_name`,
       (select `u`.`CNAME_`
        from `pms_product`.`bdf2_user` `u`
        where (`u`.`USERNAME_` = `t`.`verify_oper_id`))                                                            AS `verify_oper_name`,
       `t`.`event_state`                                                                                           AS `event_state`,
       `t`.`other`                                                                                                 AS `other`
from `pms_product`.`t_housework_event` `t`
where (`t`.`event_state` = 0)
order by `t`.`accept_time` desc;

