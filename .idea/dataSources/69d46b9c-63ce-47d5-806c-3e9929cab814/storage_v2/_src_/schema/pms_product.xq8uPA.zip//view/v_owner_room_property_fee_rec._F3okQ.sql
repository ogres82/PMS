create view v_owner_room_property_fee_rec as
select `t`.`serial_id`                                                                       AS `serialId`,
       `t`.`serial_no`                                                                       AS `serialNo`,
       `t`.`charge_info_id`                                                                  AS `chargeId`,
       `t`.`room_id`                                                                         AS `roomId`,
       `t`.`owner_id`                                                                        AS `ownerId`,
       `t`.`community_name`                                                                  AS `communityName`,
       `t`.`storied_build_name`                                                              AS `storiedName`,
       `t`.`room_no`                                                                         AS `roomNo`,
       `t`.`room_type`                                                                       AS `roomType`,
       `t`.`owner_name`                                                                      AS `ownerName`,
       (case `t`.`charge_type_name` when '押金' then '押金转预存' else `t`.`charge_type_name` end)  AS `chargeTypeName`,
       `t`.`charge_type_no`                                                                  AS `chargeTypeNo`,
       `t`.`paid_amount`                                                                     AS `paidAmount`,
       `t`.`paid_date`                                                                       AS `paidDate`,
       `t`.`update_date`                                                                     AS `updateDate`,
       year(`t`.`paid_date`)                                                                 AS `paidYear`,
       (select `a`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `a`
        where ((`a`.`code_detail` = `t`.`paid_mode`) and (`a`.`code` = 'charge_paid_mode'))) AS `paidModeName`,
       `t`.`receipt_id`                                                                      AS `receiptId`,
       `t`.`remark`                                                                          AS `remark`,
       ifnull((select `a`.`CNAME_` from `pms_product`.`bdf2_user` `a` where (`a`.`USERNAME_` = `t`.`oper_emp_id`)),
              `t`.`oper_emp_id`)                                                             AS `operEmpName`
from `pms_product`.`t_charge_serial_info` `t`
where ((`t`.`paid_mode` <> '01') and (`t`.`charge_type` in ('03', '05')) and (`t`.`is_del` = '0'))
union
select `a`.`serial_id`                                                                       AS `serial_id`,
       `a`.`serial_no`                                                                       AS `serial_no`,
       `c`.`charge_id`                                                                       AS `charge_id`,
       `a`.`room_id`                                                                         AS `room_id`,
       `a`.`owner_id`                                                                        AS `owner_id`,
       `a`.`community_name`                                                                  AS `community_name`,
       `a`.`storied_build_name`                                                              AS `storied_build_name`,
       `a`.`room_no`                                                                         AS `room_no`,
       `a`.`room_type`                                                                       AS `room_type`,
       `a`.`owner_name`                                                                      AS `owner_name`,
       (case `c`.`charge_type_name` when '押金' then '押金转预存' else `c`.`charge_type_name` end)  AS `charge_type_name`,
       `c`.`charge_type_no`                                                                  AS `charge_type_no`,
       `c`.`paid_amount`                                                                     AS `paid_amount`,
       `c`.`paid_date`                                                                       AS `paid_date`,
       `a`.`update_date`                                                                     AS `update_date`,
       year(`c`.`paid_date`)                                                                 AS `paidYear`,
       (select `a`.`code_detail_name`
        from `pms_product`.`dir_directorydetail` `a`
        where ((`a`.`code_detail` = `c`.`paid_mode`) and (`a`.`code` = 'charge_paid_mode'))) AS `paidModeName`,
       `a`.`receipt_id`                                                                      AS `receipt_id`,
       `a`.`remark`                                                                          AS `remark`,
       ifnull((select `a`.`CNAME_` from `pms_product`.`bdf2_user` `a` where (`a`.`USERNAME_` = `c`.`oper_emp_id`)),
              `c`.`oper_emp_id`)                                                             AS `operEmpName`
from (((`pms_product`.`t_charge_serial_info` `a` join `pms_product`.`t_charge_serial_detail` `b`) join `pms_product`.`t_charge_info` `c`)
         join `pms_product`.`t_charge_type_setting` `d`)
where ((`a`.`serial_id` = `b`.`charge_serial_id`) and (`b`.`charge_id` = `c`.`charge_id`) and
       (`c`.`charge_type_no` = `d`.`charge_type_no`) and (`c`.`paid_mode` <> '01') and
       (`d`.`charge_cycle_unit` = '03') and (`d`.`type_flag` = '01') and (`a`.`is_del` = '0'));

