create view v_chare_and_serial as
select `a`.`charge_id`          AS `charge_id`,
       '账单记录'                   AS `charge_name`,
       `a`.`community_name`     AS `community_name`,
       `a`.`storied_build_name` AS `storied_build_name`,
       `a`.`room_type`          AS `room_type`,
       `a`.`room_id`            AS `room_id`,
       `a`.`room_no`            AS `room_no`,
       `a`.`charge_type_name`   AS `charge_type_name`,
       `a`.`charge_type_no`     AS `charge_type_no`,
       `a`.`owner_id`           AS `owner_id`,
       `a`.`owner_name`         AS `owner_name`,
       `a`.`begin_time`         AS `begin_time`,
       `a`.`end_time`           AS `end_time`,
       `a`.`oper_emp_id`        AS `oper_emp_id`,
       `a`.`receive_amount`     AS `receive_amount`,
       `a`.`paid_mode`          AS `paid_mode`,
       `a`.`state`              AS `state`,
       ''                       AS `receipt_id`,
       `a`.`paid_date`          AS `paid_date`,
       `a`.`update_date`        AS `update_date`
from `pms_product`.`t_charge_info` `a`
where (`a`.`is_del` = '0')
union all
select `pms_product`.`t_charge_serial_info`.`serial_id`          AS `serial_id`,
       '收费记录'                                                    AS `charge_name`,
       `pms_product`.`t_charge_serial_info`.`community_name`     AS `community_name`,
       `pms_product`.`t_charge_serial_info`.`storied_build_name` AS `storied_build_name`,
       `pms_product`.`t_charge_serial_info`.`room_type`          AS `room_type`,
       `pms_product`.`t_charge_serial_info`.`room_id`            AS `room_id`,
       `pms_product`.`t_charge_serial_info`.`room_no`            AS `room_no`,
       `pms_product`.`t_charge_serial_info`.`charge_type_name`   AS `charge_type_name`,
       `pms_product`.`t_charge_serial_info`.`charge_type_no`     AS `charge_type_no`,
       `pms_product`.`t_charge_serial_info`.`owner_id`           AS `owner_id`,
       `pms_product`.`t_charge_serial_info`.`owner_name`         AS `owner_name`,
       `pms_product`.`t_charge_serial_info`.`begin_date`         AS `begin_date`,
       `pms_product`.`t_charge_serial_info`.`end_date`           AS `end_date`,
       `pms_product`.`t_charge_serial_info`.`oper_emp_id`        AS `oper_emp_id`,
       `pms_product`.`t_charge_serial_info`.`receive_amount`     AS `receive_amount`,
       `pms_product`.`t_charge_serial_info`.`paid_mode`          AS `paid_mode`,
       `pms_product`.`t_charge_serial_info`.`state`              AS `state`,
       `pms_product`.`t_charge_serial_info`.`receipt_id`         AS `receipt_id`,
       `pms_product`.`t_charge_serial_info`.`paid_date`          AS `paid_date`,
       `pms_product`.`t_charge_serial_info`.`update_date`        AS `update_date`
from `pms_product`.`t_charge_serial_info`
where ((`pms_product`.`t_charge_serial_info`.`is_del` = '0') and (`pms_product`.`t_charge_serial_info`.`state` = '01'));

