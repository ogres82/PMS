create view v_bbs_topic_user as
select `a`.`topic_id`                                                    AS `topic_id`,
       `a`.`topic_post_time`                                             AS `topic_post_time`,
       `a`.`topic_title`                                                 AS `topic_title`,
       `a`.`topic_content`                                               AS `topic_content`,
       `a`.`topic_post_mark`                                             AS `topic_post_mark`,
       `b`.`mapping_user_id`                                             AS `mapping_user_id`,
       `b`.`user_nickname`                                               AS `user_nickname`,
       `e`.`owner_head_img`                                              AS `owner_head_img`,
       (select count(1)
        from `pms_product`.`t_bbs_reply`
        where (`pms_product`.`t_bbs_reply`.`topic_id` = `a`.`topic_id`)) AS `topic_comment_times`,
       `a`.`topic_view_times`                                            AS `topic_view_times`,
       `a`.`topic_zan_times`                                             AS `topic_zan_times`,
       `a`.`topic_elite`                                                 AS `topic_elite`,
       `a`.`topic_top`                                                   AS `topic_top`,
       `a`.`topic_del_mark`                                              AS `topic_del_mark`,
       `a`.`last_update_time`                                            AS `last_update_time`,
       group_concat(`c`.`img_url` separator ',')                         AS `img_url`
from (((`pms_product`.`t_bbs_topic` `a` left join `pms_product`.`t_bbs_user` `b` on ((`a`.`topic_user_id` = `b`.`mapping_user_id`))) left join `pms_product`.`t_bbs_img` `c` on ((`a`.`topic_id` = `c`.`topic_id`)))
         left join `pms_product`.`t_property_owner` `e` on ((`a`.`topic_user_id` = `e`.`owner_id`)))
group by `a`.`topic_id`;

-- comment on column v_bbs_topic_user.owner_head_img not supported: 业主头像

