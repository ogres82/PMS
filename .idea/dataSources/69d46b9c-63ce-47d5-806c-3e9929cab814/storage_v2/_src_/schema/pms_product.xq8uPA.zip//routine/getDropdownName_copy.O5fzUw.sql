create
    definer = pms_admin@`%` function getDropdownName_copy(v_code varchar(100), v_code_detail varchar(50)) returns varchar(100)
BEGIN
	#Routine body goes here...
	DECLARE v_code_detail_name VARCHAR(100) DEFAULT '';

	SELECT ifnull(t.code_detail_name,'--') INTO v_code_detail_name from dir_directorydetail t
						WHERE t.`code`=v_code and t.code_detail=v_code_detail;  
	
	RETURN v_code_detail_name;
END;

