create view v_t_parking as
select `d`.`build_id`                                                                       AS `build_id`,
       `d`.`build_name`                                                                     AS `build_name`,
       `c`.`community_id`                                                                   AS `community_id`,
       `c`.`community_name`                                                                 AS `community_name`,
       `b`.`park_name`                                                                      AS `park_name`,
       `a`.`carport_id`                                                                     AS `carport_id`,
       `a`.`belong_com_id`                                                                  AS `belong_com_id`,
       `a`.`belong_park_no`                                                                 AS `belong_park_no`,
       `a`.`carport_no`                                                                     AS `carport_no`,
       `a`.`carport_status`                                                                 AS `carport_status`,
       `a`.`carport_floor`                                                                  AS `carport_floor`,
       `a`.`carport_type`                                                                   AS `carport_type`,
       `a`.`license_plate_no`                                                               AS `license_plate_no`,
       `a`.`remark`                                                                         AS `remark`,
       `f`.`owner_id`                                                                       AS `owner_id`,
       `f`.`owner_name`                                                                     AS `owner_name`,
       `f`.`phone`                                                                          AS `phone`,
       `f`.`room_no`                                                                        AS `room_no`,
       (select `pms_product`.`dir_directorydetail`.`code_detail_name`
        from `pms_product`.`dir_directorydetail`
        where ((`pms_product`.`dir_directorydetail`.`code` = 'carport_status') and
               (`pms_product`.`dir_directorydetail`.`code_detail` = `a`.`carport_status`))) AS `carport_status_name`
from (((((`pms_product`.`t_parking` `a` left join `pms_product`.`t_parking_area` `b` on ((`a`.`belong_park_no` = `b`.`park_id`))) left join `pms_product`.`t_area_property` `c` on ((`b`.`belong_com_id` = `c`.`community_id`))) left join `pms_product`.`t_all_area` `d` on ((`c`.`belong_build_id` = `d`.`build_id`))) left join `pms_product`.`t_parking_owner` `e` on ((`a`.`carport_id` = `e`.`carport_id`)))
         left join `pms_product`.`v_area_build_house_owner_rela` `f` on ((`e`.`owner_id` = `f`.`owner_id`)));

-- comment on column v_t_parking.build_id not supported: 楼盘ID

-- comment on column v_t_parking.build_name not supported: 楼盘名称  例：乐湾国际城一期

-- comment on column v_t_parking.community_id not supported: 小区ID

-- comment on column v_t_parking.community_name not supported: 小区名称 例：西湖御景、依山云墅

-- comment on column v_t_parking.park_name not supported: 区域名称

-- comment on column v_t_parking.carport_id not supported: 车位ID

-- comment on column v_t_parking.belong_com_id not supported: 所属小区ID

-- comment on column v_t_parking.belong_park_no not supported: 所属区域编号

-- comment on column v_t_parking.carport_status not supported: 状态

-- comment on column v_t_parking.license_plate_no not supported: 车牌号

-- comment on column v_t_parking.remark not supported: 备注

-- comment on column v_t_parking.owner_id not supported: 业主ID

-- comment on column v_t_parking.owner_name not supported: 业主姓名

-- comment on column v_t_parking.phone not supported: 手机号

-- comment on column v_t_parking.room_no not supported: 房间号

