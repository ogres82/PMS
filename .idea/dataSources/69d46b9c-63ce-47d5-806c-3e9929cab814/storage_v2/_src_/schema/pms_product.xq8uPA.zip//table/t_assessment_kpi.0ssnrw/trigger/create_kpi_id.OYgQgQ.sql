create definer = pms_admin@`%` trigger create_kpi_id
    before insert
    on t_assessment_kpi
    for each row
begin 
  if(new.kpi_lv=0) then
		if(seq_currval('kpi_lv0')=99) then
		 update sequence set current_val = 0 where seq_name = 'kpi_lv0'; 
		end if;
		set new.kpi_id=CONCAT(REPLACE(curdate(),'-',''),LPAD(seq_nextval('kpi_lv0'),2,'0'));
  else if(new.kpi_lv=1) then 
			if(seq_currval('kpi_lv1')=9999)then
			 update sequence set current_val = 0 where seq_name = 'kpi_lv1';
			end if;
			set new.kpi_id=CONCAT(new.kpi_parent_id,LPAD(seq_nextval('kpi_lv1'),4,'0'));
		else 
			if(seq_currval('kpi_lv2')=9999) then
				 update sequence set current_val = 0 where seq_name = 'kpi_lv2';
			end if;
			set new.kpi_id=CONCAT(new.kpi_parent_id,LPAD(seq_nextval('kpi_lv2'),4,'0'));	
		end if;
  end if;
end;

