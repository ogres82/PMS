create view v_audit_property_rep as
select `pms_product`.`t_audit_property_rep`.`community_name`                         AS `community_name`,
       sum(`pms_product`.`t_audit_property_rep`.`CHARGE_MONTHS`)                     AS `CHARGE_MONTHS`,
       sum(`pms_product`.`t_audit_property_rep`.`CUR_YEAR_AMOUNT_TAX`)               AS `CUR_YEAR_AMOUNT_TAX`,
       sum(`pms_product`.`t_audit_property_rep`.`CUR_GIVE_MONTH`)                    AS `CUR_GIVE_MONTH`,
       sum(`pms_product`.`t_audit_property_rep`.`CUR_GIVE_AMOUNT`)                   AS `CUR_GIVE_AMOUNT`,
       sum(`pms_product`.`t_audit_property_rep`.`ROOM_OPEN_AMOUNT`)                  AS `ROOM_OPEN_AMOUNT`,
       sum(`pms_product`.`t_audit_property_rep`.`CUR_YEAR_AMOUNT`)                   AS `CUR_YEAR_AMOUNT`,
       sum(`pms_product`.`t_audit_property_rep`.`CUR_YEAR_PRO_MONTH`)                AS `CUR_YEAR_PRO_MONTH`,
       sum(`pms_product`.`t_audit_property_rep`.`CUR_YEAR_PRO_AMOUNT`)               AS `CUR_YEAR_PRO_AMOUNT`,
       `pms_product`.`t_audit_property_rep`.`PAID_YEAR`                              AS `PAID_YEAR`,
       (sum(`pms_product`.`t_audit_property_rep`.`CUR_YEAR_PRO_AMOUNT`) -
        sum(`pms_product`.`t_audit_property_rep`.`CUR_GIVE_AMOUNT`))                 AS `TMP_AMOUNT`,
       if(((sum(`pms_product`.`t_audit_property_rep`.`CUR_YEAR_PRO_AMOUNT`) -
            sum(`pms_product`.`t_audit_property_rep`.`CUR_GIVE_AMOUNT`)) < 0), abs(
                  (sum(`pms_product`.`t_audit_property_rep`.`CUR_YEAR_PRO_AMOUNT`) -
                   sum(`pms_product`.`t_audit_property_rep`.`CUR_GIVE_AMOUNT`))), 0) AS `END_YEAR_AMOUNT`,
       if(((sum(`pms_product`.`t_audit_property_rep`.`CUR_YEAR_PRO_AMOUNT`) -
            sum(`pms_product`.`t_audit_property_rep`.`CUR_GIVE_AMOUNT`)) > 0),
          (sum(`pms_product`.`t_audit_property_rep`.`CUR_YEAR_PRO_AMOUNT`) -
           sum(`pms_product`.`t_audit_property_rep`.`CUR_GIVE_AMOUNT`)), 0)          AS `END_YEAR_PRO_AMOUNT`,
       if(((sum(`pms_product`.`t_audit_property_rep`.`CUR_YEAR_PRO_AMOUNT`) -
            sum(`pms_product`.`t_audit_property_rep`.`CUR_GIVE_AMOUNT`)) < 0),
          sum(`pms_product`.`t_audit_property_rep`.`CUR_YEAR_PRO_AMOUNT`),
          sum(`pms_product`.`t_audit_property_rep`.`CUR_YEAR_AMOUNT`))               AS `Name_exp_14`
from `pms_product`.`t_audit_property_rep`
group by `pms_product`.`t_audit_property_rep`.`community_name`;

-- comment on column v_audit_property_rep.community_name not supported: 小区名称

