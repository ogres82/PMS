create view v_owner_room_basic_info as
select `a`.`owner_id`                                                                      AS `owner_id`,
       `a`.`owner_name`                                                                    AS `owner_name`,
       `a`.`sex`                                                                           AS `sex`,
       `a`.`phone`                                                                         AS `phone`,
       `a`.`tel_phone`                                                                     AS `tel_phone`,
       `a`.`card_id`                                                                       AS `card_id`,
       `a`.`birth_date`                                                                    AS `birth_date`,
       `a`.`car_id`                                                                        AS `car_id`,
       `a`.`owner_type`                                                                    AS `owner_type`,
       (case when (isnull(`a`.`password`) or (`a`.`password` = '')) then '0' else '1' end) AS `reg_state`,
       (select `pms_product`.`dir_directorydetail`.`code_detail_name`
        from `pms_product`.`dir_directorydetail`
        where ((`a`.`owner_type` = `pms_product`.`dir_directorydetail`.`code_detail`) and
               (`pms_product`.`dir_directorydetail`.`code` = 'owner_type')))               AS `owner_type_name`,
       `a`.`owner_identity`                                                                AS `owner_identity`,
       (select `pms_product`.`dir_directorydetail`.`code_detail_name`
        from `pms_product`.`dir_directorydetail`
        where ((`a`.`owner_identity` = `pms_product`.`dir_directorydetail`.`code_detail`) and
               (`pms_product`.`dir_directorydetail`.`code` = 'owner_identity')))           AS `owner_identity_name`,
       `c`.`owner_name`                                                                    AS `parent_name`,
       `a`.`remark`                                                                        AS `remark`,
       `a`.`owner_head_img`                                                                AS `owner_head_img`,
       `a`.`owner_hk_id`                                                                   AS `owner_hk_id`,
       `a`.`emergency_contact`                                                             AS `emergency_contact`,
       `a`.`emergency_contact_phone`                                                       AS `emergency_contact_phone`,
       `a`.`is_del`                                                                        AS `is_del`,
       group_concat(concat(`e`.`community_name`,
                           (case when (`e`.`room_type` in ('2', '3', '4')) then '' else `e`.`storied_build_name` end),
                           `e`.`room_no`) separator ',')                                   AS `room_addrs`,
       `e`.`room_id`                                                                       AS `room_id`,
       `e`.`lz_id`                                                                         AS `room_lz_id`
from (((`pms_product`.`t_property_owner` `a` left join `pms_product`.`t_house_owner` `b` on ((`a`.`owner_id` = `b`.`owner_id`))) left join `pms_product`.`t_property_owner` `c` on ((`a`.`parent_id` = `c`.`owner_id`)))
         left join `pms_product`.`t_house_property` `e` on ((`b`.`room_id` = `e`.`room_id`)))
group by `a`.`owner_id`;

-- comment on column v_owner_room_basic_info.owner_id not supported: 业主ID

-- comment on column v_owner_room_basic_info.owner_name not supported: 业主姓名

-- comment on column v_owner_room_basic_info.sex not supported: 性别

-- comment on column v_owner_room_basic_info.phone not supported: 手机号

-- comment on column v_owner_room_basic_info.tel_phone not supported: 联系电话

-- comment on column v_owner_room_basic_info.card_id not supported: 身份证号

-- comment on column v_owner_room_basic_info.birth_date not supported: 出生日期

-- comment on column v_owner_room_basic_info.car_id not supported: 车辆ID

-- comment on column v_owner_room_basic_info.owner_type not supported: 业主类型（0一般 1重要）

-- comment on column v_owner_room_basic_info.owner_identity not supported: 身份（业主、家属、租客、游客）

-- comment on column v_owner_room_basic_info.parent_name not supported: 业主姓名

-- comment on column v_owner_room_basic_info.remark not supported: 备注

-- comment on column v_owner_room_basic_info.owner_head_img not supported: 业主头像

-- comment on column v_owner_room_basic_info.owner_hk_id not supported: 海康人员id

-- comment on column v_owner_room_basic_info.emergency_contact not supported: 紧急联系人及电话

-- comment on column v_owner_room_basic_info.emergency_contact_phone not supported: 紧急人联系电话

-- comment on column v_owner_room_basic_info.is_del not supported: 逻辑删除 0为正常 1为删除

-- comment on column v_owner_room_basic_info.room_id not supported: 房间ID

