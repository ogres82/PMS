create
    definer = pms_admin@`%` function getDropdownName(v_code varchar(100), v_code_detail varchar(50)) returns varchar(100)
BEGIN
	#Routine body goes here...
	DECLARE v_code_detail_name VARCHAR(100) DEFAULT '';
		-- 遍历数据结束标志
  DECLARE done INT DEFAULT FALSE;
	-- 将结束标志绑定到
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

	SELECT t.code_detail_name INTO v_code_detail_name from dir_directorydetail t
						WHERE t.`code`=v_code and t.code_detail=v_code_detail;
  
	IF done THEN
     RETURN '--';
  END IF;
	
	RETURN v_code_detail_name;
END;

