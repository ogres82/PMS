create
    definer = pms_admin@`%` procedure pro111()
BEGIN 
DECLARE i INT DEFAULT 0;
DECLARE	v_room_id VARCHAR (10000);
DECLARE	v_room_no VARCHAR (10000) ;
DECLARE	v_owner_id VARCHAR (10000);
DECLARE	v_owner_name VARCHAR (10000);

loop_label : LOOP 
SET i = i + 1;
set v_room_id = UUID();
set v_owner_id = UUID();
set v_room_no = CONCAT('test',LPAD(i,4,'0'));
set v_owner_name = CONCAT('徐磊',LPAD(i,4,'0'));

INSERT INTO t_house_property(room_id,room_no,belong_sb_id,house_type,build_area,within_area,room_type,room_state,charge_object)
 VALUES(v_room_id,v_room_no,'2c986881522e866e01522e893c7a0000','A户型',120,108,0,2,0);

 INSERT INTO t_property_owner(owner_id,room_id,room_no,owner_name,phone) 
 VALUES(v_owner_id,v_room_id,v_room_no,v_owner_name,'13655555555');

-- SELECT v_room_id,v_room_no;
-- SELECT v_owner_id,v_room_id,v_room_no,v_owner_name;

IF i >= 9999 THEN LEAVE loop_label;

END IF;

END LOOP;

END;

