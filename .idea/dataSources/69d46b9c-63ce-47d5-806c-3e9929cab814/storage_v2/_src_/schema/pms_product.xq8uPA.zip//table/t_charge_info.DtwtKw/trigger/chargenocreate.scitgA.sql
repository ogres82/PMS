create definer = pms_admin@`%` trigger chargeNoCreate
    before insert
    on t_charge_info
    for each row
begin
set new.charge_no=CONCAT('ZD',DATE_FORMAT(now(),'%Y%m%d'),LPAD(seq_nextval('charge_seq'),6,'0'));
end;

