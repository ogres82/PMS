create
    definer = pms_admin@`%` procedure test1(IN in_onwer_name varchar(100))
begin

  DECLARE str_room_id varchar(50);
  DECLARE str_charge_date date;
	
	select room_id,charge_date into str_room_id,str_charge_date from v_house_vs_owner where owner_name = in_onwer_name and community_name = '溪湖御景';
	
	select str_room_id,str_charge_date,begin_time from t_charge_info where room_id =str_room_id  and charge_type_name like '%物业费%' order by begin_time;

end;

