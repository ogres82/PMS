create definer = root@localhost trigger ins_room_refresh
    after insert
    on t_house_property
    for each row
begin
call pro_refresh_house_vs_fee();
end;

