create view v_charge_vs_type as
select `a`.`charge_id`        AS `charge_id`,
       `a`.`arrearage_amount` AS `arrearage_amount`,
       `a`.`begin_time`       AS `begin_time`,
       `a`.`charge_no`        AS `charge_no`,
       `a`.`charge_type_name` AS `charge_type_name`,
       `a`.`charge_type_no`   AS `charge_type_no`,
       `a`.`count`            AS `count`,
       `a`.`delete_id`        AS `delete_id`,
       `a`.`end_time`         AS `end_time`,
       `a`.`oper_emp_id`      AS `oper_emp_id`,
       `a`.`owner_id`         AS `owner_id`,
       `a`.`owner_name`       AS `owner_name`,
       `a`.`paid_amount`      AS `paid_amount`,
       `a`.`paid_date`        AS `paid_date`,
       `a`.`paid_mode`        AS `paid_mode`,
       `a`.`price`            AS `price`,
       `a`.`rate`             AS `rate`,
       `a`.`receive_amount`   AS `receive_amount`,
       `a`.`remark`           AS `remark`,
       `a`.`room_id`          AS `room_id`,
       `a`.`room_no`          AS `room_no`,
       `a`.`update_date`      AS `update_date`,
       `a`.`state`            AS `state`,
       `a`.`data_from`        AS `data_from`,
       `b`.`charge_mode`      AS `charge_mode`,
       `b`.`charge_type`      AS `charge_type`,
       `b`.`charge_way`       AS `charge_way`
from (`pms_product`.`t_charge_info` `a`
         left join `pms_product`.`t_charge_type_setting` `b` on ((`a`.`charge_type_no` = `b`.`charge_type_no`)))
where (`a`.`is_del` = '0');

-- comment on column v_charge_vs_type.state not supported: 01:未收 02已收， 03欠费

-- comment on column v_charge_vs_type.data_from not supported: 01:系统自动，02手动

